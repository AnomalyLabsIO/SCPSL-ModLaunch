param([string] $Configuration = "Release")
$ErrorActionPreference = "Stop"
$sourceRoot = Join-Path $PSScriptRoot "source"
Push-Location $sourceRoot
try {
    dotnet build "Il2CppInterop.Generator/Il2CppInterop.Generator.csproj" -c $Configuration -f netstandard2.1 --no-self-contained -v minimal "-p:GeneratePackageOnBuild=false" "-p:NuGetAudit=false" "-p:RestoreIgnoreFailedSources=true" "-p:AssemblyVersion=1.5.1.0" "-p:FileVersion=1.5.3.0" "-p:InformationalVersion=1.5.3+455c42a6f35fd272c2ab3023208defa593fb1d70" "-p:IncludeSourceRevisionInInformationalVersion=false" "-p:EnableSourceControlManagerQueries=false" "-p:PathMap=$sourceRoot=/_/Il2CppInterop"
    if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE" }
} finally { Pop-Location }

