[CmdletBinding()]
param([string]$NuGetSource, [string]$SourceRevision)
$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$stage = Join-Path $repoRoot ('artifacts/cli-package/' + [guid]::NewGuid().ToString('N'))
$binaryStage = Join-Path $stage 'binary'
$output = Join-Path $repoRoot 'artifacts/cli-release'
New-Item -ItemType Directory -Path $binaryStage,$output -Force | Out-Null
if (-not $SourceRevision) {
    $SourceRevision = (& git --git-dir="$repoRoot/.git" rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Supply -SourceRevision when building an exported source archive.' }
}
if ($SourceRevision -cnotmatch '^[0-9a-fA-F]{40}$') { throw 'SourceRevision must be a full Git commit hash.' }
$args = @('publish', (Join-Path $repoRoot 'SCPSL.ModPatch.Cli/SCPSL.ModPatch.Cli.csproj'), '-c','Release','-r','win-x64',
    '--self-contained','false','-o',$binaryStage,'-p:PublishSingleFile=true','-p:DebugType=None','-p:DebugSymbols=false',
    '-p:IncludeNativeLibrariesForSelfExtract=true','-p:UseSharedCompilation=false','-p:NuGetAudit=false')
if ($NuGetSource) { $args += "-p:RestoreSources=$NuGetSource" }
& dotnet @args
if ($LASTEXITCODE -ne 0) { throw 'ModPatch CLI publish failed.' }

Add-Type -AssemblyName System.IO.Compression.FileSystem
function Write-Archive([string]$Root, [string[]]$Files, [string]$Destination) {
    $stream = [IO.File]::Open($Destination, [IO.FileMode]::Create, [IO.FileAccess]::Write)
    try {
        $zip = [IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
        try {
            foreach ($file in ($Files | Sort-Object)) {
                $relative = [IO.Path]::GetRelativePath($Root,$file).Replace('\','/')
                if ($relative.StartsWith('../')) { throw 'Archive input escaped source root.' }
                $entry = $zip.CreateEntry($relative,[IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = [DateTimeOffset]::new(1980,1,1,0,0,0,[TimeSpan]::Zero)
                $input = [IO.File]::OpenRead($file); $target = $entry.Open()
                try { $input.CopyTo($target) } finally { $target.Dispose(); $input.Dispose() }
            }
        } finally { $zip.Dispose() }
    } finally { $stream.Dispose() }
}
$sourceFiles = foreach ($folder in @('SCPSL ModPatch','SCPSL.ModPatch.Cli','Shared_Files','tests','scripts')) {
    Get-ChildItem -LiteralPath (Join-Path $repoRoot $folder) -Recurse -File |
        Where-Object { $_.FullName -notmatch '[\\/](bin|obj|artifacts|Build_Binaries)[\\/]' } | Select-Object -ExpandProperty FullName
}
$sourceFiles += @((Join-Path $repoRoot 'LICENSE'),(Join-Path $repoRoot 'README.md'),(Join-Path $repoRoot 'SCPSL ModPatch.sln'))
$sourceZip = Join-Path $output 'SCPSL-ModPatch.Cli-sources.zip'
Write-Archive $repoRoot $sourceFiles $sourceZip
Copy-Item -LiteralPath (Join-Path $repoRoot 'LICENSE') -Destination (Join-Path $binaryStage 'LICENSE-ModPatch.txt')
foreach ($file in (Get-ChildItem -LiteralPath (Join-Path $repoRoot 'Shared_Files/clean_launchers') -Recurse -File -Filter 'SCPSL.exe')) {
    $relative = [IO.Path]::GetRelativePath((Join-Path $repoRoot 'Shared_Files'),$file.FullName)
    $destination = Join-Path $binaryStage ([IO.Path]::ChangeExtension($relative,'.bin'))
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $destination
}
$files = @(Get-ChildItem -LiteralPath $binaryStage -Recurse -File | ForEach-Object {
    @{relativePath=[IO.Path]::GetRelativePath($binaryStage,$_.FullName).Replace('\','/');sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
})
$identity = @{schemaVersion=1;sourceRepository='AnomalyLabsIO/SCPSL-ModPatch';sourceRevision=$SourceRevision;
    sourceSha256=(Get-FileHash -LiteralPath $sourceZip -Algorithm SHA256).Hash;files=$files}
[IO.File]::WriteAllText((Join-Path $binaryStage 'bundle.json'),($identity|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$binaryZip = Join-Path $output 'SCPSL-ModPatch.Cli-win-x64.zip'
Write-Archive $binaryStage @(Get-ChildItem -LiteralPath $binaryStage -Recurse -File | Select-Object -ExpandProperty FullName) $binaryZip
foreach ($archive in @($sourceZip,$binaryZip)) {
    $hash=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText(($archive+'.sha256'),"$hash  $([IO.Path]::GetFileName($archive))`n",[Text.UTF8Encoding]::new($false))
}
Write-Host "CLI packages: $output"
