namespace SCPSL_ModPatch
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the console application.
        /// </summary>
        static int Main(string[] args)
        {
            return CommandLine.HeadlessCommand.Run(args);
        }
    }
}
