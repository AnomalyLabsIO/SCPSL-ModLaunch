using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Il2CppDumper;
using Newtonsoft.Json;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

internal static class RealBinaryQualification
{
    public static int Run(string[] args)
    {
        if (args.Length != 4 || args[0] != "--qualify")
        {
            Console.Error.WriteLine("Usage: --qualify AUDIT_INDEX PATTERN_MANIFEST OUTPUT_JSON");
            return 2;
        }
        string indexPath = Path.GetFullPath(args[1]);
        string manifestPath = Path.GetFullPath(args[2]);
        string outputPath = Path.GetFullPath(args[3]);
        var protectedInputs = new HashSet<string>(new[] { indexPath, manifestPath }, StringComparer.OrdinalIgnoreCase);
        if (protectedInputs.Contains(outputPath) || !Path.GetExtension(outputPath).Equals(".json", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Qualification output cannot overwrite an input.");
        string manifestHash = HashFile(manifestPath);
        string indexHash = HashFile(indexPath);
        PatchInfo feed = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(manifestPath))!;
        PatchTargetResolver.Validate(feed);
        using JsonDocument index = JsonDocument.Parse(File.ReadAllText(indexPath));
        var results = new List<object>();
        int passed = 0, rejected = 0, skipped = 0;
        foreach (JsonElement row in index.RootElement.EnumerateArray())
        {
            string manifestId = ReadString(row, "manifestId") ?? "local";
            string? observedVersion = ReadString(row, "verifiedVersion");
            string? explicitRange = ReadString(row, "explicitRange");
            string? reportPath = ReadString(row, "reportPath");
            if (string.IsNullOrEmpty(reportPath))
            {
                results.Add(new { ManifestId = manifestId, Status = "Skipped", Reason = "No completed audit report is available." });
                skipped++;
                continue;
            }
            string? assemblyPath = null;
            string? originalHash = null;
            string? afterHash = null;
            string? selectedLabel = null;
            try
            {
                protectedInputs.Add(Path.GetFullPath(reportPath));
                using JsonDocument report = JsonDocument.Parse(File.ReadAllText(reportPath));
                JsonElement details = report.RootElement;
                assemblyPath = ReadString(details, "AssemblyPath") ?? throw new InvalidDataException("Audit has no assembly path.");
                string scriptPath = ReadString(details, "ScriptPath") ?? throw new InvalidDataException("Audit has no symbol path.");
                protectedInputs.Add(Path.GetFullPath(assemblyPath));
                protectedInputs.Add(Path.GetFullPath(scriptPath));
                string? mapPath = ReadString(details, "MapProvenancePath");
                if (mapPath != null) protectedInputs.Add(Path.GetFullPath(mapPath));
                if (details.TryGetProperty("MapProvenance", out JsonElement provenance) && provenance.ValueKind == JsonValueKind.Object)
                {
                    string? metadataPath = ReadString(provenance, "MetadataPath");
                    if (metadataPath != null) protectedInputs.Add(Path.GetFullPath(metadataPath));
                }
                originalHash = HashFile(assemblyPath);
                if (!string.Equals(originalHash, ReadString(details, "AssemblySha256"), StringComparison.OrdinalIgnoreCase) ||
                    !string.Equals(HashFile(scriptPath), ReadString(details, "ScriptSha256"), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Audit assembly/symbol hashes do not match current disk inputs.");
                if (!details.TryGetProperty("Version", out JsonElement auditedVersion) ||
                    !string.Equals(ReadString(auditedVersion, "VerifiedVersion"), observedVersion, StringComparison.Ordinal))
                    throw new InvalidDataException("Index version does not match the completed audit's verified version.");
                if (observedVersion != null && explicitRange != null)
                    throw new InvalidDataException("An index row must choose observed-version or explicit-range selection.");
                byte[] original = File.ReadAllBytes(assemblyPath);
                string loadedHash = PatchTargetResolver.ComputeSha256(original);
                if (!string.Equals(loadedHash, originalHash, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("The assembly changed while loading the private qualification buffer.");
                VersionRangeInfo selected;
                if (explicitRange != null)
                {
                    VersionRangeInfo[] ranges = feed.versionRanges.Where(range => range.versionRange == explicitRange).ToArray();
                    if (ranges.Length != 1)
                        throw new InvalidDataException($"Explicit inspection identifies {ranges.Length} pattern manifest profiles.");
                    selected = ranges[0];
                }
                else if (observedVersion != null)
                    selected = PatchTargetResolver.Resolve(feed, loadedHash, Version.Parse(observedVersion));
                else
                {
                    VersionRangeInfo? hashTarget = PatchTargetResolver.ResolveHash(feed, loadedHash);
                    if (hashTarget == null)
                    {
                        results.Add(new { ManifestId = manifestId, Status = "Skipped", Reason = "No verified version or matching assembly-hash target is available." });
                        skipped++;
                        continue;
                    }
                    selected = hashTarget;
                }
                selectedLabel = selected.versionRange;
                byte[] patched = (byte[])original.Clone();
                ScriptJson symbols = JsonConvert.DeserializeObject<ScriptJson>(File.ReadAllText(scriptPath))
                    ?? throw new InvalidDataException("Symbol map is null.");
                using var parserStream = new MemoryStream((byte[])original.Clone(), writable: true);
                var manager = new Il2cppManager(patched);
                Set(manager, "_il2Cpp", new PE(parserStream));
                Set(manager, "_scriptJson", symbols);
                Set(manager, "_methodsDictionary", symbols.ScriptMethod.GroupBy(method => method.Name).ToDictionary(group => group.Key, group => group.First()));
                new Patcher(assemblyPath, patched, manager, selected).PatchGameAssembly();
                // Match the patcher's condition and missing-method skips when reporting actual writes.
                PatchMethodInfo[] applicable = selected.methods.patchMethods.Where(patch =>
                    (string.IsNullOrEmpty(patch.patchifnotexists) || !manager.MethodsDictionary.ContainsKey(patch.patchifnotexists)) &&
                    manager.MethodsDictionary.ContainsKey(patch.name)).ToArray();
                int changedBytes = 0;
                for (int position = 0; position < original.Length; position++)
                    if (original[position] != patched[position]) changedBytes++;
                afterHash = HashFile(assemblyPath);
                if (originalHash != afterHash)
                    throw new InvalidDataException("Assembly disk input changed during qualification.");
                results.Add(new
                {
                    ManifestId = manifestId, Status = "Passed", ObservedVersion = observedVersion,
                    VersionVerified = observedVersion != null, RangeSelection = explicitRange != null ? "explicit profile inspection; automatic target selection bypassed" : "shared resolver: original SHA-256 and observed version when available",
                    SelectedRange = selectedLabel,
                    AssemblyPath = assemblyPath, OriginalAssemblySha256 = originalHash, OriginalAssemblySha256After = afterHash,
                    CloneOutputSha256 = Convert.ToHexString(SHA256.HashData(patched)), ChangedByteCount = changedBytes,
                    PatternPatchCount = applicable.Count(patch => patch.patchPattern != null),
                    ConfiguredPatternPatchCount = selected.methods.patchMethods.Count(patch => patch.patchPattern != null),
                    LegacyEntryPatchCount = applicable.Count(patch => patch.patchPattern == null),
                    ConfiguredLegacyEntryPatchCount = selected.methods.patchMethods.Count(patch => patch.patchPattern == null),
                    SourceKind = ReadString(details, "SourceKind"),
                    Validation = "Actual Patcher.PatchGameAssembly on a private byte clone; each applicable pattern must match exactly once inside its resolved native method. No save or launcher operation called."
                });
                passed++;
                Console.WriteLine($"PASS {manifestId}: {observedVersion ?? "release version unverified"}, {selectedLabel}, {changedBytes} changed clone bytes");
            }
            catch (Exception error)
            {
                if (assemblyPath != null && File.Exists(assemblyPath)) afterHash = HashFile(assemblyPath);
                results.Add(new { ManifestId = manifestId, Status = "Rejected", ObservedVersion = observedVersion,
                    VersionVerified = observedVersion != null, RangeSelection = explicitRange != null ? "explicit profile inspection; automatic target selection bypassed" : "shared resolver: original SHA-256 and observed version when available", SelectedRange = selectedLabel,
                    AssemblyPath = assemblyPath, OriginalAssemblySha256 = originalHash, OriginalAssemblySha256After = afterHash,
                    OriginalInputUnchanged = originalHash != null && originalHash == afterHash, Error = error.ToString() });
                rejected++;
                Console.WriteLine($"REJECT {manifestId}: {error.Message}");
            }
        }
        if (protectedInputs.Contains(outputPath))
            throw new ArgumentException("Qualification output cannot overwrite an assembly, map, metadata, or audit input.");
        if (manifestHash != HashFile(manifestPath) || indexHash != HashFile(indexPath))
            throw new InvalidDataException("The manifest or audit index changed during qualification.");
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        File.WriteAllText(outputPath, System.Text.Json.JsonSerializer.Serialize(new
        {
            CreatedUtc = DateTimeOffset.UtcNow, AuditIndexPath = indexPath, AuditIndexSha256 = indexHash,
            PatternManifestPath = manifestPath, PatternManifestSha256 = manifestHash, ManifestAndIndexUnchanged = true,
            Passed = passed, Rejected = rejected, Skipped = skipped, Results = results,
            Acceptance = "Static application to memory clones only. No patched DLL was saved or loaded, and no game startup, authentication, network, or gameplay behavior is established."
        }, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine);
        Console.WriteLine($"Qualification: {passed} passed, {rejected} rejected, {skipped} skipped; {outputPath}");
        return rejected == 0 ? 0 : 1;
    }

    private static string? ReadString(JsonElement element, string name)
    {
        foreach (JsonProperty property in element.EnumerateObject())
            if (property.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return property.Value.ValueKind == JsonValueKind.String ? property.Value.GetString() : null;
        return null;
    }

    private static string HashFile(string path)
    {
        using var stream = File.OpenRead(path);
        using var hasher = SHA256.Create();
        return Convert.ToHexString(hasher.ComputeHash(stream));
    }

    private static void Set(object instance, string field, object value) =>
        instance.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(instance, value);
}
