using System.Buffers.Binary;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using SCPSL_ModPatch.CommandLine;
using SCPSL_ModPatch.PatchUtils;

internal static class HeadlessCliTests
{
    private static readonly TimeSpan ProcessTimeout = TimeSpan.FromSeconds(15);

    public static void Register(Action<string, Action> run)
    {
        run("CLI options default to executable-adjacent patchinfo.json from an unrelated working directory", () =>
        {
            using var fixture = new Fixture();
            string originalDirectory = Directory.GetCurrentDirectory();
            try
            {
                Directory.SetCurrentDirectory(fixture.Root);
                CliOptions options = CliOptions.Parse(new[] { "patch", "--game-dir", fixture.Game, "--result", fixture.Result });
                Check(options.PatchInfoPath == Path.Combine(AppContext.BaseDirectory, "patchinfo.json"),
                    "Default manifest name or location depends on the caller's working directory.");
            }
            finally
            {
                Directory.SetCurrentDirectory(originalDirectory);
            }
        });
        run("GUI executable CLI defaults to adjacent patchinfo.json from an unrelated working directory", () => DefaultManifest(FindExecutable()));
        run("console CLI defaults to adjacent patchinfo.json from an unrelated working directory", () => DefaultManifest(FindConsoleExecutable()));
        run("CLI rejects unknown metadata modes", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments().Concat(new[] { "--metadata-mode", "invalid" }), 2);
        });
        run("CLI rejects unknown manifest fields before loading or writing", () =>
        {
            using var fixture = new Fixture();
            JsonNode manifest = JsonNode.Parse(File.ReadAllText(fixture.Manifest))!;
            manifest["versionRanges"]![0]!["unknownSelector"] = true;
            File.WriteAllText(fixture.Manifest, manifest.ToJsonString());
            fixture.RememberInputs();
            JsonElement report = AssertFailure(fixture, fixture.Arguments(), 1);
            Check(report.GetProperty("stage").GetString() == "preflight", "Unknown field reached the parser.");
        });
        run("Unity bootstrap uses shared parser settings without selecting final version range", () =>
        {
            var a = new VersionRangeInfo { versionFrom = "14.1.0", cleanLauncherPath = "clean_launchers/6000.0.43f1/SCPSL.exe", metadataVersion = 31 };
            var b = new VersionRangeInfo { versionFrom = "14.2.0", cleanLauncherPath = a.cleanLauncherPath, metadataVersion = 31 };
            var info = new PatchInfo { versionRanges = new[] { a, b } };
            Check(ReferenceEquals(PatchSession.ResolveUnityBootstrap(info, "6000.0.43f1"), a), "Equivalent parser settings were rejected.");
            Check(PatchSession.ResolveUnityBootstrap(info, "6000.0.99f1") == null, "Unknown Unity matched a parser.");
            b.metadataVersion = 29;
            try { PatchSession.ResolveUnityBootstrap(info, "6000.0.43f1"); }
            catch (InvalidDataException) { return; }
            throw new InvalidOperationException("Conflicting parser settings were accepted.");
        });
        run("CLI help exits with stdin held open and no visible windows", () =>
        {
            using var fixture = new Fixture();
            Invocation result = Invoke(fixture, new[] { "--help" });
            Check(result.ExitCode == 0, result.Describe());
            Check(result.Output.Contains("--game-dir", StringComparison.Ordinal), "Help omitted game directory parameter.");
            Check(result.Output.Contains("--result", StringComparison.Ordinal), "Help omitted result parameter.");
        });
        run("CLI patch help does not require patch inputs", () =>
        {
            using var fixture = new Fixture();
            Check(Invoke(fixture, new[] { "patch", "--help" }).ExitCode == 0, "Patch help failed.");
        });
        run("CLI unknown command writes a syntax-error result without opening GUI", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, new[] { "unknown", "--result", fixture.Result }, 2);
        });
        run("CLI unknown parameter writes a syntax-error result", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments().Concat(new[] { "--unknown", "value" }), 2);
        });
        run("CLI missing option value exits without reading stdin", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, new[] { "patch", "--result", fixture.Result, "--game-dir" }, 2);
        });
        run("CLI missing game-dir writes a syntax-error result", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, new[] { "patch", "--result", fixture.Result }, 2);
        });
        run("CLI requires a JSON result destination", () =>
        {
            using var fixture = new Fixture();
            Invocation result = Invoke(fixture, new[] { "patch", "--game-dir", fixture.Game });
            Check(result.ExitCode == 2, result.Describe());
            Check(!File.Exists(fixture.Result), "Missing --result unexpectedly produced a report.");
            fixture.AssertInputsUnchanged();
        });
        run("CLI duplicate parameters are rejected", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments().Concat(new[] { "--game-dir", fixture.Game }), 2);
        });
        run("CLI unexpected positional arguments are rejected", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments().Concat(new[] { "unexpected" }), 2);
        });
        run("CLI missing game directory reports operation failure", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments(game: Path.Combine(fixture.Root, "missing game")), 1);
        });
        run("CLI missing patch manifest reports operation failure", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments(manifest: Path.Combine(fixture.Root, "missing manifest.json")), 1);
        });
        run("CLI malformed JSON manifest reports operation failure", () =>
        {
            using var fixture = new Fixture();
            File.WriteAllText(fixture.Manifest, "{ invalid JSON");
            fixture.RememberInputs();
            AssertFailure(fixture, fixture.Arguments(), 1);
        });
        run("CLI empty manifest rejects without an interactive profile picker", () =>
        {
            using var fixture = new Fixture();
            File.WriteAllText(fixture.Manifest, "{\"versionRanges\":[]}");
            fixture.RememberInputs();
            AssertFailure(fixture, fixture.Arguments(), 1);
        });
        run("CLI unknown explicit profile rejects without opening a picker", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments().Concat(new[] { "--profile", "missing profile" }), 1);
        });
        run("CLI missing local launcher fails before modifying game inputs", () =>
        {
            using var fixture = new Fixture();
            AssertFailure(fixture, fixture.Arguments(launcher: Path.Combine(fixture.Root, "missing launcher.exe")), 1);
        });
        run("CLI absent metadata reports failure without modifying game inputs", () =>
        {
            using var fixture = new Fixture();
            File.Delete(fixture.Metadata);
            fixture.RememberInputs();
            AssertFailure(fixture, fixture.Arguments(), 1);
            Check(!File.Exists(fixture.Metadata), "Headless failure created absent metadata.");
        });
        run("CLI corrupt metadata reports failure without prompts or writes", () =>
        {
            using var fixture = new Fixture();
            JsonElement report = AssertFailure(fixture, fixture.Arguments(), 1);
            Check(report.GetProperty("stage").GetString() == "load", "Corrupt metadata did not reach the loader.");
        });
        run("CLI protected PE reports failure without starting an unpacker or asking for addresses", () =>
        {
            using var fixture = new Fixture(validMetadata: true);
            JsonElement report = AssertFailure(fixture, fixture.Arguments(), 1);
            Check(report.GetProperty("stage").GetString() == "load", "Protected fixture did not reach the loader.");
            Check(report.GetProperty("error").GetProperty("message").GetString()!
                .Contains("protect", StringComparison.OrdinalIgnoreCase), "Fixture did not exercise protected-PE rejection.");
        });
        run("CLI failed result write returns dedicated exit code without waiting", () =>
        {
            using var fixture = new Fixture();
            Directory.CreateDirectory(fixture.Result);
            Invocation result = Invoke(fixture, fixture.Arguments());
            Check(result.ExitCode == 3, result.Describe());
            Check(Directory.Exists(fixture.Result), "Result write failure replaced the destination directory.");
            fixture.AssertInputsUnchanged();
        });
        foreach (string input in new[] { "assembly", "metadata", "manifest", "launcher", "clean launcher" })
        {
            string captured = input;
            run($"CLI JSON destination cannot overwrite {input} input", () =>
            {
                using var fixture = new Fixture();
                string destination = captured switch
                {
                    "assembly" => fixture.Assembly,
                    "metadata" => fixture.Metadata,
                    "manifest" => fixture.Manifest,
                    "launcher" => fixture.Launcher,
                    _ => fixture.CleanLauncher
                };
                Invocation result = Invoke(fixture, fixture.Arguments(result: destination));
                Check(result.ExitCode == 2, "Aliased report destination did not return a syntax error. " + result.Describe());
                fixture.AssertInputsUnchanged();
            });
        }
        foreach (bool missingGameArgument in new[] { false, true })
        {
            bool captured = missingGameArgument;
            run($"CLI manifest launcher/report alias is rejected before {(captured ? "missing game-dir parsing" : "unknown profile validation")}", () =>
            {
                using var fixture = new Fixture();
                var arguments = new List<string> { "patch", "--patch-info", fixture.Manifest, "--result", fixture.CleanLauncher };
                if (!captured) arguments.AddRange(new[] { "--game-dir", fixture.Game, "--profile", "missing profile" });
                Invocation result = Invoke(fixture, arguments);
                Check(result.ExitCode == 2, "Manifest launcher/report alias did not return a syntax error. " + result.Describe());
                fixture.AssertInputsUnchanged();
            });
        }
        run("CLI JSON destination cannot overwrite GameAssembly through a directory junction", () =>
        {
            using var fixture = new Fixture();
            string alias = Path.Combine(fixture.Root, "game directory junction");
            try
            {
                CreateJunction(alias, fixture.Game);
                string aliasedAssembly = Path.Combine(alias, "GameAssembly.dll");
                Check(File.Exists(aliasedAssembly), "Junction did not resolve the fixture assembly.");
                Invocation result = Invoke(fixture, fixture.Arguments(result: aliasedAssembly));
                Check(result.ExitCode == 2, "Junction-aliased report destination did not return a syntax error. " + result.Describe());
                fixture.AssertInputsUnchanged();
            }
            finally
            {
                // Remove the link before its target. Recursive fixture cleanup must
                // not encounter a junction whose target it has already removed.
                if (Directory.Exists(alias)) Directory.Delete(alias, recursive: false);
            }
        });
        run("GUI no-argument startup still displays and closes the main form", GuiStartup);
        string? realGame = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_GAME_DIR");
        if (!string.IsNullOrWhiteSpace(realGame))
        {
            string sourceGame = Path.GetFullPath(realGame);
            run("CLI real offline files patch successfully with stdin held open", () => RealOfflineQualification(sourceGame, failPatch: false));
            run("CLI preserves runtime metadata and automatically selects parser from Unity", () =>
                RealOfflineQualification(sourceGame, failPatch: false, preserveMetadata: true));
            run("CLI real offline missing required method fails without changing staged inputs", () => RealOfflineQualification(sourceGame, failPatch: true));
            run("CLI real offline directory at launcher destination fails before modifying DLL or metadata",
                () => RealOfflineQualification(sourceGame, failPatch: false, launcherDirectory: true));
        }
    }

    private static JsonElement AssertFailure(Fixture fixture, IEnumerable<string> arguments, int exitCode, TimeSpan? timeout = null)
    {
        Invocation result = Invoke(fixture, arguments, timeout);
        Check(result.ExitCode == exitCode, result.Describe());
        Check(File.Exists(fixture.Result), "CLI did not create its requested JSON result. " + result.Describe());
        using JsonDocument json = JsonDocument.Parse(File.ReadAllText(fixture.Result));
        JsonElement report = json.RootElement;
        Check(report.GetProperty("schemaVersion").GetInt32() == 1, "Unexpected JSON result schema.");
        Check(!report.GetProperty("success").GetBoolean(), "Failed command was reported successful.");
        Check(report.GetProperty("exitCode").GetInt32() == exitCode, "Process and JSON exit codes disagree.");
        Check(report.TryGetProperty("command", out _), "JSON omitted command.");
        Check(!string.IsNullOrWhiteSpace(report.GetProperty("stage").GetString()), "JSON omitted failure stage.");
        JsonElement error = report.GetProperty("error");
        Check(error.ValueKind == JsonValueKind.Object, "JSON omitted error details.");
        Check(!string.IsNullOrWhiteSpace(error.GetProperty("type").GetString()), "JSON omitted error type.");
        Check(!string.IsNullOrWhiteSpace(error.GetProperty("message").GetString()), "JSON omitted error message.");
        Check(report.GetProperty("modifiedFiles").GetArrayLength() == 0, "Failure unexpectedly reported modified files.");
        Check(report.GetProperty("patches").ValueKind == JsonValueKind.Array, "JSON patches is not an array.");
        Check(report.GetProperty("warnings").ValueKind == JsonValueKind.Array, "JSON warnings is not an array.");
        Check(report.TryGetProperty("gameVersion", out _), "JSON omitted gameVersion.");
        Check(report.TryGetProperty("profile", out _), "JSON omitted profile.");
        fixture.AssertInputsUnchanged();
        return report.Clone();
    }

    private static Invocation Invoke(Fixture fixture, IEnumerable<string> arguments, TimeSpan? timeout = null, string? executable = null)
    {
        TimeSpan limit = timeout ?? ProcessTimeout;
        using Process process = Start(executable ?? FindExecutable(), fixture.Root, arguments);
        Task<string> stdout = process.StandardOutput.ReadToEndAsync();
        Task<string> stderr = process.StandardError.ReadToEndAsync();
        bool sawWindow = false;
        var timer = Stopwatch.StartNew();
        // Deliberately do not write to or close StandardInput. ReadLine would block here;
        // tests that immediately close stdin only prove EOF handling and miss that bug.
        while (!process.WaitForExit(10))
        {
            sawWindow |= VisibleWindows(process.Id).Count != 0;
            if (timer.Elapsed <= limit) continue;
            process.Kill(entireProcessTree: true);
            process.WaitForExit(3000);
            throw new InvalidOperationException($"CLI exceeded {limit.TotalSeconds} seconds with stdin still open; possible input wait or modal dialog. " +
                string.Join(" ", arguments));
        }
        Check(!sawWindow, "CLI displayed a visible window or modal dialog.");
        Check(Task.WaitAll(new Task[] { stdout, stderr }, 3000), "CLI left an output pipe open after exit.");
        return new Invocation(process.ExitCode, stdout.Result, stderr.Result);
    }

    private static void RealOfflineQualification(string sourceGame, bool failPatch, bool launcherDirectory = false, bool preserveMetadata = false)
    {
        string sourceAssembly = Path.Combine(sourceGame, "GameAssembly.dll");
        string sourceMetadata = Path.Combine(sourceGame, "SCPSL_Data", "il2cpp_data", "Metadata", "global-metadata.dat");
        string sourceManifest = FindProductionManifest();
        foreach (string required in new[] { sourceAssembly, sourceMetadata, sourceManifest })
            Check(File.Exists(required), $"Opt-in offline qualification input is absent: {required}");
        Dictionary<string, string> sourceHashes = Snapshot(sourceAssembly, sourceMetadata, sourceManifest);
        try
        {
            using var fixture = new Fixture();
            File.Copy(sourceAssembly, fixture.Assembly, overwrite: true);
            File.Copy(sourceMetadata, fixture.Metadata, overwrite: true);
            if (preserveMetadata)
                File.Copy(Path.Combine(sourceGame, "UnityPlayer.dll"), Path.Combine(fixture.Game, "UnityPlayer.dll"));
            File.Copy(sourceManifest, fixture.Manifest, overwrite: true);
            PatchInfo manifest = Newtonsoft.Json.JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(fixture.Manifest))
                ?? throw new InvalidDataException("Offline qualification manifest is null.");
            string profile = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_PROFILE") ??
                manifest.versionRanges.Last(target => target.metadataVersion == 31 && target.gameAssemblySha256 == null).ToString();
            PatchTargetResolver.Validate(manifest);
            Check(manifest.versionRanges.Count(target => target.ToString() == profile) == 1,
                $"Offline qualification profile does not identify exactly one entry: {profile}");
            if (failPatch)
            {
                // Append to every profile so a more specific final target cannot avoid the
                // deliberate required-method failure after real IL2CPP loading completes.
                JsonNode feed = JsonNode.Parse(File.ReadAllText(fixture.Manifest))!;
                foreach (JsonNode? target in feed["versionRanges"]!.AsArray())
                    target!["methods"]!["patchMethods"]!.AsArray().Add(new JsonObject
                    {
                        ["name"] = "HeadlessCliTests.DeliberatelyMissingRequiredType$$MissingMethod",
                        ["patchOffset"] = 0,
                        ["patchData"] = "[RET]",
                        ["patchSize"] = 1
                    });
                File.WriteAllText(fixture.Manifest, feed.ToJsonString());
            }
            if (launcherDirectory)
            {
                File.Delete(fixture.Launcher);
                Directory.CreateDirectory(fixture.Launcher);
                File.WriteAllText(Path.Combine(fixture.Launcher, "preserve.txt"), "launcher destination directory fixture");
            }
            fixture.RememberInputs();
            Dictionary<string, string> before = Snapshot(new[] { fixture.Assembly, fixture.Metadata, fixture.Launcher,
                fixture.Manifest, fixture.CleanLauncher }.Where(File.Exists).ToArray());
            byte[] originalMetadata = File.ReadAllBytes(fixture.Metadata);
            string[] arguments = fixture.Arguments().Concat(preserveMetadata
                ? new[] { "--metadata-mode", "preserve" } : new[] { "--profile", profile }).ToArray();
            TimeSpan realLoadTimeout = TimeSpan.FromSeconds(120);
            if (launcherDirectory)
            {
                JsonElement failure = AssertFailure(fixture, arguments, 1, realLoadTimeout);
                Check(failure.GetProperty("stage").GetString() is "save" or "preflight", "Launcher directory did not fail in destination preflight.");
                Check(failure.GetProperty("error").GetProperty("message").GetString()!
                    .Contains("directory", StringComparison.OrdinalIgnoreCase), "Launcher directory failure did not identify its destination conflict.");
                Check(Directory.Exists(fixture.Launcher) &&
                    File.ReadAllText(Path.Combine(fixture.Launcher, "preserve.txt")) == "launcher destination directory fixture",
                    "CLI replaced or modified the directory at its launcher destination.");
                return;
            }
            if (failPatch)
            {
                JsonElement failure = AssertFailure(fixture, arguments, 1, realLoadTimeout);
                Check(failure.GetProperty("stage").GetString() == "patch", "Required missing method failed before reaching the real patch stage.");
                Check(failure.GetProperty("error").GetProperty("message").GetString()!
                    .Contains("MissingMethod", StringComparison.Ordinal), "Failure did not name the required missing method.");
                return;
            }

            Invocation execution = Invoke(fixture, arguments, realLoadTimeout);
            Check(execution.ExitCode == 0, execution.Describe());
            Check(File.Exists(fixture.Result), "Successful real CLI execution omitted its JSON report.");
            using JsonDocument json = JsonDocument.Parse(File.ReadAllText(fixture.Result));
            JsonElement report = json.RootElement;
            Check(report.GetProperty("schemaVersion").GetInt32() == 1, "Unexpected real CLI result schema.");
            Check(report.GetProperty("success").GetBoolean() && report.GetProperty("exitCode").GetInt32() == 0,
                "Successful real CLI execution was not reported successful.");
            Check(report.GetProperty("command").GetString() == "patch" && report.GetProperty("stage").GetString() == "complete",
                "Successful real CLI execution did not reach completion.");
            Check(report.GetProperty("error").ValueKind == JsonValueKind.Null, "Successful real CLI result contains an error.");
            string? version = report.GetProperty("gameVersion").GetString();
            Check(Version.TryParse(version, out Version? numericVersion) && numericVersion.Build >= 0,
                "Real CLI result did not identify a three-component game version.");
            VersionRangeInfo selected = PatchTargetResolver.Resolve(manifest, before[fixture.Assembly], numericVersion);
            Check(report.GetProperty("profile").GetString() == selected.ToString(), "Real CLI result reported the wrong final patch profile.");

            JsonElement patches = report.GetProperty("patches");
            Check(patches.GetArrayLength() == selected.methods.patchMethods.Length, "Real CLI result omitted configured patch outcomes.");
            int applied = 0;
            for (int index = 0; index < patches.GetArrayLength(); index++)
            {
                JsonElement outcome = patches[index];
                PatchMethodInfo configured = selected.methods.patchMethods[index];
                Check(outcome.GetProperty("name").GetString() == configured.name, "Real CLI patch outcome order/name differs from its manifest.");
                string? status = outcome.GetProperty("status").GetString();
                if (status == "applied") applied++;
                else Check(status == "skipped-fallback" && !string.IsNullOrEmpty(configured.patchifnotexists) ||
                    status == "skipped-optional" && configured.nowarning, "Real CLI reported an unapplied required patch.");
            }
            Check(applied > 0, "Real CLI did not report any patches applied.");

            byte[] normalized = (byte[])originalMetadata.Clone();
            if (!preserveMetadata) BinaryPrimitives.WriteInt32LittleEndian(normalized.AsSpan(4, 4), selected.metadataVersion);
            Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(normalized), "CLI metadata normalization changed more than its schema header.");
            Check(report.GetProperty("metadataMode").GetString() == (preserveMetadata ? "preserve" : "write"), "Metadata mode missing from result.");
            Check(report.GetProperty("metadataVersion").GetInt32() == selected.metadataVersion, "Parser version missing from result.");
            Check(HashFile(fixture.Assembly) != before[fixture.Assembly], "Real CLI left GameAssembly.dll unchanged.");
            Check(File.ReadAllBytes(fixture.Launcher).SequenceEqual(File.ReadAllBytes(fixture.CleanLauncher)), "Real CLI did not copy the supplied clean launcher.");
            Check(HashFile(fixture.Manifest) == before[fixture.Manifest] && HashFile(fixture.CleanLauncher) == before[fixture.CleanLauncher],
                "Real CLI modified its manifest or clean-launcher input.");
            Dictionary<string, string> changed = before.Where(pair => HashFile(pair.Key) != pair.Value)
                .ToDictionary(pair => pair.Key, pair => HashFile(pair.Key), StringComparer.OrdinalIgnoreCase);
            JsonElement changes = report.GetProperty("modifiedFiles");
            Check(changes.GetArrayLength() == changed.Count, "Real CLI JSON modification count differs from disk hashes.");
            var reported = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (JsonElement change in changes.EnumerateArray())
            {
                string path = change.GetProperty("path").GetString()!;
                Check(reported.Add(path) && changed.ContainsKey(path), "Real CLI reported a duplicate or unchanged file.");
                Check(change.GetProperty("beforeSha256").GetString() == before[path] &&
                    change.GetProperty("afterSha256").GetString() == changed[path], "Real CLI JSON file hashes differ from disk.");
            }
            Check(report.GetProperty("warnings").GetArrayLength() == 0, "Successful real CLI execution reported unexpected warnings.");
            Check(!Directory.Exists(Path.Combine(fixture.Root, "il2cppdumper")), "Real CLI left its dump in the caller's working directory.");
            Console.WriteLine($"  Offline CLI: game {version}, {applied} applied patches, {changes.GetArrayLength()} changed staged files; source files unchanged.");
        }
        finally
        {
            foreach ((string path, string expected) in sourceHashes)
                Check(File.Exists(path) && HashFile(path) == expected, $"Offline qualification modified a source input: {path}");
        }
    }

    private static string FindProductionManifest()
    {
        string? explicitPath = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_PATCH_INFO");
        if (!string.IsNullOrWhiteSpace(explicitPath)) return Path.GetFullPath(explicitPath);
        for (DirectoryInfo? directory = new(Path.GetDirectoryName(FindExecutable())!); directory != null; directory = directory.Parent)
        {
            string path = Path.Combine(directory.FullName, "Shared_Files", "patchinfo.json");
            if (File.Exists(path)) return path;
        }
        throw new InvalidOperationException("Could not locate the production patchinfo.json; set SCPSL_MODPATCH_TEST_PATCH_INFO.");
    }

    private static void DefaultManifest(string originalExecutable)
    {
        using var fixture = new Fixture();
        string appDirectory = Path.Combine(fixture.Root, "isolated application");
        Directory.CreateDirectory(appDirectory);
        foreach (string source in Directory.EnumerateFiles(Path.GetDirectoryName(originalExecutable)!))
        {
            if (Path.GetFileName(source).StartsWith("patchinfo", StringComparison.OrdinalIgnoreCase)) continue;
            File.Copy(source, Path.Combine(appDirectory, Path.GetFileName(source)));
        }
        string manifest = Path.Combine(appDirectory, "patchinfo.json");
        File.Copy(fixture.Manifest, manifest);
        string expectedHash = HashFile(manifest);
        string callerManifest = Path.Combine(fixture.Root, "patchinfo.json");
        File.WriteAllText(callerManifest, "{ invalid caller manifest");
        string callerHash = HashFile(callerManifest);
        string executable = Path.Combine(appDirectory, Path.GetFileName(originalExecutable));
        Invocation execution = Invoke(fixture, new[] { "patch", "--game-dir", fixture.Game,
            "--clean-launcher", fixture.CleanLauncher, "--result", fixture.Result }, executable: executable);
        Check(execution.ExitCode == 1, execution.Describe());
        Check(File.Exists(fixture.Result), "Default manifest test omitted the requested result.");
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(fixture.Result));
        JsonElement report = document.RootElement;
        Check(report.GetProperty("stage").GetString() == "load",
            "CLI did not load the valid executable-adjacent manifest before reaching the corrupt metadata fixture.");
        Check(report.GetProperty("modifiedFiles").GetArrayLength() == 0, "Default manifest test reported changed inputs.");
        Check(HashFile(manifest) == expectedHash && HashFile(callerManifest) == callerHash,
            "CLI modified an executable-adjacent or caller manifest.");
        fixture.AssertInputsUnchanged();
    }

    private static Dictionary<string, string> Snapshot(params string[] paths) =>
        paths.ToDictionary(path => path, HashFile, StringComparer.OrdinalIgnoreCase);

    private static string HashFile(string path)
    {
        using FileStream file = File.OpenRead(path);
        using var hash = SHA256.Create();
        return Convert.ToHexString(hash.ComputeHash(file));
    }

    private static void CreateJunction(string alias, string target)
    {
        // Native PowerShell junction creation does not require symbolic-link privileges.
        // These paths are generated inside one private fixture; no shell deletes anything.
        static string Quote(string value) => "'" + value.Replace("'", "''") + "'";
        string script = "$ErrorActionPreference = 'Stop'" + Environment.NewLine + "New-Item -ItemType Junction -Path " + Quote(alias) +
            " -Target " + Quote(target) + " | Out-Null";
        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
        string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
            "WindowsPowerShell", "v1.0", "powershell.exe");
        using Process process = Start(powershell, Path.GetDirectoryName(alias)!,
            new[] { "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded });
        Task<string> stdout = process.StandardOutput.ReadToEndAsync();
        Task<string> stderr = process.StandardError.ReadToEndAsync();
        if (!process.WaitForExit(10000))
        {
            process.Kill(entireProcessTree: true);
            process.WaitForExit(3000);
            throw new InvalidOperationException("Private test junction creation timed out.");
        }
        Check(Task.WaitAll(new Task[] { stdout, stderr }, 3000), "Junction creation left an output pipe open.");
        Check(process.ExitCode == 0, "Private test junction creation failed: " + stderr.Result);
    }

    private static Process Start(string executable, string workingDirectory, IEnumerable<string> arguments)
    {
        var start = new ProcessStartInfo(executable)
        {
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        foreach (string argument in arguments) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Could not start existing application executable.");
    }

    private static void GuiStartup()
    {
        using var fixture = new Fixture();
        string appDirectory = Path.Combine(fixture.Root, "isolated GUI");
        Directory.CreateDirectory(appDirectory);
        string originalExecutable = FindExecutable();
        foreach (string source in Directory.EnumerateFiles(Path.GetDirectoryName(originalExecutable)!))
            File.Copy(source, Path.Combine(appDirectory, Path.GetFileName(source)));
        File.Copy(fixture.Manifest, Path.Combine(appDirectory, "patchinfo.json"), overwrite: true);
        File.WriteAllText(Path.Combine(appDirectory, "config.json"),
            "{\"AutoUpdatePatchInfo\":false,\"CustomPatchInfoEnable\":false}");
        string executable = Path.Combine(appDirectory, Path.GetFileName(originalExecutable));
        using Process process = Start(executable, appDirectory, Array.Empty<string>());
        Task<string> stdout = process.StandardOutput.ReadToEndAsync();
        Task<string> stderr = process.StandardError.ReadToEndAsync();
        try
        {
            var timer = Stopwatch.StartNew();
            IntPtr form = IntPtr.Zero;
            while (timer.Elapsed < ProcessTimeout && !process.HasExited)
            {
                form = VisibleWindows(process.Id).FirstOrDefault(handle => WindowTitle(handle) == "SCPSL ModPatch");
                if (form != IntPtr.Zero) break;
                Thread.Sleep(20);
            }
            Check(form != IntPtr.Zero, "No-argument startup did not display the existing main form.");
            Check(PostMessage(form, 0x0010, IntPtr.Zero, IntPtr.Zero), "Could not close GUI smoke-test form."); // WM_CLOSE
            Check(process.WaitForExit(5000), "Main form did not close within five seconds.");
            Check(process.ExitCode == 0, "GUI exited with an error.");
            Check(Task.WaitAll(new Task[] { stdout, stderr }, 3000), "GUI left an output pipe open.");
            Check(!Directory.Exists(Path.Combine(appDirectory, "il2cppdumper")), "GUI startup unexpectedly began dumping game files.");
        }
        finally
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
                process.WaitForExit(3000);
            }
        }
    }

    private static string FindExecutable()
    {
        string? explicitPath = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_EXE");
        if (!string.IsNullOrWhiteSpace(explicitPath))
        {
            Check(File.Exists(explicitPath), "SCPSL_MODPATCH_TEST_EXE does not exist.");
            return Path.GetFullPath(explicitPath);
        }
        for (DirectoryInfo? directory = new(AppContext.BaseDirectory); directory != null; directory = directory.Parent)
        {
            if (!File.Exists(Path.Combine(directory.FullName, "SCPSL ModPatch.sln"))) continue;
            string path = Path.Combine(directory.FullName, "SCPSL ModPatch", "bin", "Release", "net6.0-windows", "SCPSL ModPatch.exe");
            Check(File.Exists(path), "Build the Release application before running the CLI process tests.");
            return path;
        }
        throw new InvalidOperationException("Could not locate solution; set SCPSL_MODPATCH_TEST_EXE to the existing WinExe.");
    }

    private static string FindConsoleExecutable()
    {
        for (DirectoryInfo? directory = new(AppContext.BaseDirectory); directory != null; directory = directory.Parent)
        {
            if (!File.Exists(Path.Combine(directory.FullName, "SCPSL ModPatch.sln"))) continue;
            string path = Path.Combine(directory.FullName, "SCPSL.ModPatch.Cli", "bin", "Release", "net6.0", "SCPSL.ModPatch.Cli.exe");
            Check(File.Exists(path), "Build the Release console application before running the CLI default-manifest test.");
            return path;
        }
        throw new InvalidOperationException("Could not locate the console application.");
    }

    private static List<IntPtr> VisibleWindows(int processId)
    {
        var result = new List<IntPtr>();
        EnumWindows((handle, _) =>
        {
            GetWindowThreadProcessId(handle, out uint owner);
            if (owner == processId && IsWindowVisible(handle)) result.Add(handle);
            return true;
        }, IntPtr.Zero);
        return result;
    }

    private static string WindowTitle(IntPtr handle)
    {
        var title = new StringBuilder(512);
        GetWindowText(handle, title, title.Capacity);
        return title.ToString();
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed record Invocation(int ExitCode, string Output, string Error)
    {
        public string Describe() => $"CLI exit {ExitCode}. stdout: {Output} stderr: {Error}";
    }

    private sealed class Fixture : IDisposable
    {
        private static readonly string FixtureBase = Path.GetFullPath(
            string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_WORK_DIR"))
                ? Path.Combine(Path.GetTempPath(), "SCPSL-ModPatch-headless-tests")
                : Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_WORK_DIR")!);
        public string Root { get; } = Path.Combine(FixtureBase, Guid.NewGuid().ToString("N"));
        public string Game => Path.Combine(Root, "game folder ü");
        public string Assembly => Path.Combine(Game, "GameAssembly.dll");
        public string Metadata => Path.Combine(Game, "SCPSL_Data", "il2cpp_data", "Metadata", "global-metadata.dat");
        public string Launcher => Path.Combine(Game, "SCPSL.exe");
        public string Manifest => Path.Combine(Root, "fixture manifest.json");
        public string CleanLauncher => Path.Combine(Root, "clean launcher.exe");
        public string Result => Path.Combine(Root, "result.json");
        private Dictionary<string, string> _original = new();

        public Fixture(bool validMetadata = false)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Metadata)!);
            var pe = new SyntheticPe();
            pe.Image[2] = 0x90; // Il2CppDumper recognizes the conventional DOS stub magic.
            File.WriteAllBytes(Assembly, pe.Image);
            byte[] metadata = new byte[0x200];
            if (validMetadata)
            {
                BinaryPrimitives.WriteUInt32LittleEndian(metadata.AsSpan(0, 4), 0xFAB11BAF);
                BinaryPrimitives.WriteInt32LittleEndian(metadata.AsSpan(4, 4), 24);
            }
            File.WriteAllBytes(Metadata, metadata);
            File.WriteAllText(Launcher, "original fixture launcher; never executed");
            File.WriteAllText(CleanLauncher, "replacement fixture launcher; never executed");
            File.WriteAllText(Manifest, JsonSerializer.Serialize(new
            {
                versionRanges = new[] { new
                {
                    versionRange = "fixture profile", gameAssemblySha256 = Hash(Assembly),
                    metadataVersion = 24, cleanLauncherPath = Path.GetFileName(CleanLauncher),
                    methods = new { patchMethods = Array.Empty<object>() }
                } }
            }));
            // A CLI must ignore GUI settings, including automatic online updates.
            File.WriteAllText(Path.Combine(Root, "config.json"), "{\"AutoUpdatePatchInfo\":true}");
            RememberInputs();
        }

        public string[] Arguments(string? game = null, string? manifest = null, string? launcher = null, string? result = null) =>
            new[] { "patch", "--game-dir", game ?? Game, "--patch-info", manifest ?? Manifest,
                "--clean-launcher", launcher ?? CleanLauncher, "--result", result ?? Result };

        public void RememberInputs() => _original = new[] { Assembly, Metadata, Launcher, Manifest, CleanLauncher }
            .Where(File.Exists).ToDictionary(path => path, Hash, StringComparer.OrdinalIgnoreCase);

        public void AssertInputsUnchanged()
        {
            foreach ((string path, string expectedHash) in _original)
                Check(File.Exists(path) && Hash(path) == expectedHash, $"Failure modified an input: {path}");
            Check(!Directory.Exists(Path.Combine(Root, "il2cppdumper")), "CLI dumped into the caller's working directory.");
        }

        public void Dispose()
        {
            string allowed = Path.TrimEndingDirectorySeparator(FixtureBase) + Path.DirectorySeparatorChar;
            string target = Path.GetFullPath(Root);
            Check(target.StartsWith(allowed, StringComparison.OrdinalIgnoreCase), "Refusing to remove a fixture outside its private test directory.");
            if (Directory.Exists(target)) Directory.Delete(target, recursive: true);
        }

        private static string Hash(string path)
        {
            using FileStream file = File.OpenRead(path);
            using var hash = SHA256.Create();
            return Convert.ToHexString(hash.ComputeHash(file));
        }
    }

    private delegate bool EnumWindowsCallback(IntPtr handle, IntPtr parameter);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool EnumWindows(EnumWindowsCallback callback, IntPtr parameter);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWindowVisible(IntPtr handle);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr handle, out uint processId);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr handle, StringBuilder text, int maximumCount);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool PostMessage(IntPtr handle, uint message, IntPtr wParam, IntPtr lParam);
}
