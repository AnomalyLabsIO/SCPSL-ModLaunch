using System.Buffers.Binary;
using System.Reflection;
using System.Text;
using Il2CppDumper;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

internal sealed class SyntheticPe
{
    public const int TextRaw = 0x200;
    public const int TextRva = 0x1000;
    public const int TextSize = 0x4000;
    public const int PdataRaw = TextRaw + TextSize;
    public const int PdataRva = TextRva + TextSize;
    public const int OptionalHeader = 0x98;
    public const int SectionHeaders = OptionalHeader + 0xF0;
    public const string A = "Fixture.A$$Run";
    public const string B = "Fixture.B$$Run";
    public const string C = "Fixture.C$$Run";
    public byte[] Image { get; }
    private readonly Method[] _methods;

    public sealed record Method(string Name, int Start, int Length, ulong? AddressOverride = null);

    public SyntheticPe(params Method[] methods)
    {
        _methods = methods.Length == 0
            ? new[] { new Method(A, 0, 0x40), new Method(B, 0x40, 0x40), new Method(C, 0x80, 0x40) }
            : methods;
        Method[] entries = _methods.GroupBy(method => method.Start).Select(group => group.First()).OrderBy(method => method.Start).ToArray();
        Image = new byte[PdataRaw + 0x200];
        Image.AsSpan(TextRaw, TextSize).Fill(0xCC);
        Write16(0, 0x5A4D);
        Write32(0x3C, 0x80);
        Write32(0x80, 0x00004550);
        Write16(0x84, 0x8664);
        Write16(0x86, 2);
        Write16(0x94, 0xF0);
        Write16(0x96, 0x2022);
        Write16(OptionalHeader, 0x20B);
        Write32(OptionalHeader + 4, TextSize);
        Write32(OptionalHeader + 8, 0x200);
        Write32(OptionalHeader + 16, TextRva);
        Write32(OptionalHeader + 20, TextRva);
        Write64(OptionalHeader + 24, 0x180000000);
        Write32(OptionalHeader + 32, 0x1000);
        Write32(OptionalHeader + 36, 0x200);
        Write16(OptionalHeader + 40, 6);
        Write16(OptionalHeader + 48, 6);
        Write32(OptionalHeader + 56, 0x6000);
        Write32(OptionalHeader + 60, TextRaw);
        Write16(OptionalHeader + 68, 3);
        Write64(OptionalHeader + 72, 0x100000);
        Write64(OptionalHeader + 80, 0x1000);
        Write64(OptionalHeader + 88, 0x100000);
        Write64(OptionalHeader + 96, 0x1000);
        Write32(OptionalHeader + 108, 16);
        Write32(OptionalHeader + 112 + 3 * 8, PdataRva);
        Write32(OptionalHeader + 112 + 3 * 8 + 4, entries.Length * 12);
        WriteSection(SectionHeaders, ".text", TextSize, TextRva, TextSize, TextRaw, 0x60000020);
        WriteSection(SectionHeaders + 40, ".pdata", 0x200, PdataRva, 0x200, PdataRaw, 0x40000040);
        for (int index = 0; index < entries.Length; index++)
        {
            Write32(PdataRaw + index * 12, TextRva + entries[index].Start);
            Write32(PdataRaw + index * 12 + 4, TextRva + entries[index].Start + entries[index].Length);
            Write32(PdataRaw + index * 12 + 8, UnwindInfoRva(index));
            Image[UnwindInfoRaw(index)] = 1; // UNWIND_INFO version 1, no flags or codes.
        }
    }

    public void Put(int methodOffset, params byte[] bytes) => bytes.CopyTo(Image, TextRaw + methodOffset);

    public static int UnwindInfoRaw(int recordIndex) => PdataRaw + 0x100 + recordIndex * 0x20;
    public static int UnwindInfoRva(int recordIndex) => PdataRva + 0x100 + recordIndex * 0x20;

    public void Chain(int childRecord, int parentRecord, bool oddCodeCount = false)
    {
        int info = UnwindInfoRaw(childRecord);
        Image[info] = 0x21; // Version 1 with UNW_FLAG_CHAININFO.
        Image[info + 2] = oddCodeCount ? (byte)1 : (byte)0;
        if (oddCodeCount)
        {
            Image[info + 1] = 1; // One-byte prologue.
            Image[info + 4] = 1; // One unwind code: UWOP_PUSH_NONVOL RBP.
            Image[info + 5] = 0x50;
        }
        int trailer = info + (oddCodeCount ? 8 : 4);
        Image.AsSpan(PdataRaw + parentRecord * 12, 12).CopyTo(Image.AsSpan(trailer, 12));
    }

    public void Apply(params PatchMethodInfo[] patches)
    {
        var info = new VersionRangeInfo { methods = new MethodsInfo { patchMethods = patches } };
        CreatePatcher(info).PatchGameAssembly();
    }

    public Patcher CreatePatcher(VersionRangeInfo profile, string path = "unused-synthetic-GameAssembly.dll")
    {
        // Reflection belongs to this fixture only: production receives these values from Il2CppDumper.
        var manager = new Il2cppManager(Image);
        var script = new ScriptJson
        {
            ScriptMethod = _methods.Select(method => new ScriptMethod
            {
                Name = method.Name,
                Address = method.AddressOverride ?? (ulong)(TextRva + method.Start)
            }).ToList()
        };
        // Il2CppDumper's BinaryStream creates a BinaryWriter even for these read-only lookups.
        SetField(manager, "_il2Cpp", new PE(new MemoryStream((byte[])Image.Clone(), writable: true)));
        SetField(manager, "_scriptJson", script);
        SetField(manager, "_methodsDictionary", script.ScriptMethod.GroupBy(method => method.Name).ToDictionary(group => group.Key, group => group.First()));
        return new Patcher(path, Image, manager, profile);
    }

    public void Write16(int offset, ushort value) => BinaryPrimitives.WriteUInt16LittleEndian(Image.AsSpan(offset, 2), value);
    public void Write32(int offset, int value) => BinaryPrimitives.WriteInt32LittleEndian(Image.AsSpan(offset, 4), value);
    public void Write64(int offset, ulong value) => BinaryPrimitives.WriteUInt64LittleEndian(Image.AsSpan(offset, 8), value);

    private void WriteSection(int offset, string name, int virtualSize, int rva, int rawSize, int raw, int characteristics)
    {
        Encoding.ASCII.GetBytes(name).CopyTo(Image, offset);
        Write32(offset + 8, virtualSize);
        Write32(offset + 12, rva);
        Write32(offset + 16, rawSize);
        Write32(offset + 20, raw);
        Write32(offset + 36, characteristics);
    }

    private static void SetField(object instance, string name, object value) =>
        instance.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(instance, value);
}
