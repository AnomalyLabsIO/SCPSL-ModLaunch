using System.Buffers.Binary;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Il2CppDumper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SCPSL_ModPatch;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

/// <summary>Exercises the production version reader without patching, changing versions, saving, or loading game code.</summary>
internal static class VersionReaderAudit
{
    public static int Run(string[] args)
    {
        if (args.Length != 4 || args[0] != "--audit-version-readers")
        {
            Console.Error.WriteLine("Usage: --audit-version-readers AUDIT_INDEX PATTERN_MANIFEST OUTPUT_JSON");
            return 2;
        }
        string indexPath = Path.GetFullPath(args[1]);
        string manifestPath = Path.GetFullPath(args[2]);
        string outputPath = Path.GetFullPath(args[3]);
        string indexHash = HashFile(indexPath), manifestHash = HashFile(manifestPath);
        var protectedInputs = new HashSet<string>(new[] { indexPath, manifestPath }, StringComparer.OrdinalIgnoreCase);
        if (protectedInputs.Contains(outputPath) || !Path.GetExtension(outputPath).Equals(".json", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Version-reader output cannot overwrite an input and must be JSON.");
        PatchInfo feed = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(manifestPath))
            ?? throw new InvalidDataException("The supplied feed is null.");
        PatchTargetResolver.Validate(feed);
        using JsonDocument index = JsonDocument.Parse(File.ReadAllText(indexPath));
        var results = new List<Result>();
        foreach (JsonElement row in index.RootElement.EnumerateArray())
        {
            var result = new Result { ManifestId = ReadString(row, "manifestId") ?? "local" };
            byte[]? readerBuffer = null;
            MemoryStream? legacyMetadataStream = null;
            string? assemblyPath = null;
            GameVersionMethodInfo? versionMethod = null;
            try
            {
                string reportPath = Path.GetFullPath(ReadString(row, "reportPath")
                    ?? throw new InvalidDataException("Index row has no completed survey report."));
                protectedInputs.Add(reportPath);
                result.SurveyReportPath = reportPath;
                result.SurveyReportSha256 = HashFile(reportPath);
                using JsonDocument report = JsonDocument.Parse(File.ReadAllText(reportPath));
                JsonElement details = report.RootElement;
                JsonElement surveyedVersion = Property(details, "Version");
                result.DecodedVersion = ReadString(surveyedVersion, "VerifiedVersion")
                    ?? throw new InvalidDataException("Survey has no verified numeric version.");
                result.DecodedTypeByte = ReadInt(surveyedVersion, "VersionTypeByte");
                if (ReadString(row, "verifiedVersion") != result.DecodedVersion)
                    throw new InvalidDataException("Index version differs from the completed survey's verified version.");
                result.SurveyReader = ReadString(surveyedVersion, "Reader");
                if (TryProperty(surveyedVersion, "Location", out JsonElement location))
                    result.SurveyVersionLocation = location.Clone();
                assemblyPath = Path.GetFullPath(ReadString(details, "AssemblyPath")
                    ?? throw new InvalidDataException("Survey has no assembly path."));
                string scriptPath = Path.GetFullPath(ReadString(details, "ScriptPath")
                    ?? throw new InvalidDataException("Survey has no symbol map path."));
                foreach (string input in new[] { assemblyPath, scriptPath }) protectedInputs.Add(input);
                result.AssemblyPath = assemblyPath;
                result.AssemblySha256 = HashFile(assemblyPath);
                result.ScriptSha256 = HashFile(scriptPath);
                RequireEqualHash(result.AssemblySha256, ReadString(details, "AssemblySha256"), "assembly");
                RequireEqualHash(result.ScriptSha256, ReadString(details, "ScriptSha256"), "script");
                string? metadataPath = ReadString(details, "MetadataPath");
                if (metadataPath != null)
                {
                    metadataPath = Path.GetFullPath(metadataPath);
                    protectedInputs.Add(metadataPath);
                    result.MetadataPath = metadataPath;
                    result.MetadataSha256 = HashFile(metadataPath);
                    RequireEqualHash(result.MetadataSha256, ReadString(details, "MetadataSha256"), "metadata");
                }
                string? mapPath = ReadString(details, "MapProvenancePath");
                if (mapPath != null) protectedInputs.Add(Path.GetFullPath(mapPath));
                Version observed = Version.Parse(result.DecodedVersion);
                byte[] original = File.ReadAllBytes(assemblyPath);
                string loadedHash = PatchTargetResolver.ComputeSha256(original);
                RequireEqualHash(loadedHash, result.AssemblySha256, "loaded assembly");
                VersionRangeInfo selected = PatchTargetResolver.Resolve(feed, loadedHash, observed);
                // AutoFindGameVersionOffsets mutates this object. Every row gets a complete private profile copy.
                VersionRangeInfo profile = JsonConvert.DeserializeObject<VersionRangeInfo>(JsonConvert.SerializeObject(selected))!;
                result.SelectedRange = profile.versionRange;
                versionMethod = profile.methods.gameVersionMethod;
                result.ConfiguredMethod = versionMethod?.name;
                result.AutoFindConfigured = versionMethod?.autoFindOffsets ?? false;
                result.ConfiguredOffsets = Snapshot(versionMethod);
                readerBuffer = (byte[])original.Clone();
                ScriptJson symbols = JsonConvert.DeserializeObject<ScriptJson>(File.ReadAllText(scriptPath))
                    ?? throw new InvalidDataException("Symbol map is null.");
                using var parserStream = new MemoryStream((byte[])original.Clone(), writable: true);
                var binary = new PE(parserStream);
                var manager = new Il2cppManager(readerBuffer);
                Set(manager, "_il2Cpp", binary);
                Set(manager, "_scriptJson", symbols);
                Set(manager, "_methodsDictionary", symbols.ScriptMethod.GroupBy(method => method.Name)
                    .ToDictionary(group => group.Key, group => group.First()));
                if (versionMethod != null)
                {
                    ulong[] addresses = symbols.ScriptMethod.Where(method => method.Name == versionMethod.name)
                        .Select(method => method.Address).Distinct().ToArray();
                    result.MethodAddressCount = addresses.Length;
                    if (addresses.Length > 1) throw new InvalidDataException("Configured version method has ambiguous symbol addresses.");
                    if (addresses.Length == 1)
                    {
                        int raw = checked((int)binary.MapVATR(checked(binary.ImageBase + addresses[0])));
                        NativeMethodRange range = new NativeMethodMap(original).GetMethodRange(raw);
                        result.MethodBounds = new Bounds(versionMethod.name, addresses[0], range.Offset, range.Length, range.FragmentCount);
                        if (TryProperty(surveyedVersion, "Location", out location) &&
                            ReadString(location, "Method") == versionMethod.name)
                            result.BoundsMatchSurvey = ReadInt(location, "RawOffset") == range.Offset &&
                                ReadInt(location, "Length") == range.Length;
                        else result.BoundsMatchSurvey = false;
                    }
                }
                var candidates = new List<int[]>();
                if (TryProperty(surveyedVersion, "Candidates", out JsonElement candidateArray))
                    foreach (JsonElement candidate in candidateArray.EnumerateArray())
                        if (ReadString(candidate, "Version") == result.DecodedVersion &&
                            ReadInt(candidate, "Type") == result.DecodedTypeByte &&
                            TryProperty(candidate, "ValueOffsets", out JsonElement values))
                            candidates.Add(values.EnumerateArray().Select(value => value.GetInt32()).ToArray());
                result.DecodedCandidateCount = candidates.Count;
                if (candidates.Count == 1 && candidates[0].Length == 4) result.DecodedValueOffsets = candidates[0];
                var patcher = new Patcher(assemblyPath, readerBuffer, manager, profile);
                result.UsesLegacyVersionReader = patcher.UsesLegacyVersionReader;
                if (result.UsesLegacyVersionReader)
                {
                    if (metadataPath == null) throw new InvalidDataException("Legacy version proof requires matching metadata.");
                    int schema = ReadInt(Property(details, "MapProvenance"), "configuredMetadataVersion")
                        ?? throw new InvalidDataException("Legacy version proof has no successful metadata schema.");
                    byte[] metadataBytes = File.ReadAllBytes(metadataPath);
                    RequireEqualHash(Convert.ToHexString(SHA256.HashData(metadataBytes)), result.MetadataSha256, "loaded metadata");
                    if (metadataBytes.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(metadataBytes) != 0xFAB11BAF)
                        throw new InvalidDataException("The bound legacy metadata header is invalid.");
                    // Same parser normalization as Survey, in a private buffer with no filesystem backing.
                    BinaryPrimitives.WriteInt32LittleEndian(metadataBytes.AsSpan(4, 4), schema);
                    legacyMetadataStream = new MemoryStream(metadataBytes, writable: true);
                    Set(manager, "_metadata", new Metadata(legacyMetadataStream));
                    result.LegacyMetadataSchema = schema;
                }
                try
                {
                    if (result.AutoFindConfigured)
                    {
                        result.AutoFindCalled = true;
                        patcher.AutoFindGameVersionOffsets();
                    }
                    result.GetGameVersionCalled = true;
                    GameVersion actual = patcher.GetGameVersion();
                    result.ProductionVersion = actual.ToString();
                    result.ProductionTypeByte = actual.type.HasValue ? (byte)actual.type.Value : null;
                    if (result.UsesLegacyVersionReader)
                    {
                        LegacyReleaseVersionReader.Result legacy = patcher.GetLegacyReleaseVersion();
                        result.LegacyReaderMatchesSurvey = legacy.Reader == result.SurveyReader;
                        result.LegacyLocationMatchesSurvey = Equivalent(legacy.Location, Property(surveyedVersion, "Location"));
                        result.LegacyEvidenceMatchesSurvey = Equivalent(legacy.LegacyEvidence, Property(surveyedVersion, "LegacyEvidence"));
                        result.LegacyLabelsMatchSurvey = legacy.ReleaseLabel == ReadString(surveyedVersion, "ReleaseLabel") &&
                            legacy.ReleaseQualifier == ReadString(surveyedVersion, "ReleaseQualifier") &&
                            legacy.NetworkVersionTuple == ReadString(surveyedVersion, "NetworkVersionTuple");
                        result.LegacyTypeUnknown = !actual.type.HasValue && !legacy.VersionTypeByte.HasValue && !result.DecodedTypeByte.HasValue;
                        var bounds = new List<Bounds>();
                        var native = new NativeMethodMap(original);
                        foreach ((string name, string key) in new[] { ("CustomNetworkManager$$.cctor", "Constructor"), ("Misc$$ParseVersion", "Parser") })
                        {
                            ulong[] addresses = symbols.ScriptMethod.Where(method => method.Name == name)
                                .Select(method => method.Address).Distinct().ToArray();
                            if (addresses.Length != 1) throw new InvalidDataException("Legacy version method has absent or ambiguous symbol addresses.");
                            int raw = checked((int)binary.MapVATR(checked(binary.ImageBase + addresses[0])));
                            NativeMethodRange range = native.GetMethodRange(raw);
                            bounds.Add(new Bounds(name, addresses[0], range.Offset, range.Length, range.FragmentCount));
                            JsonElement evidence = Property(Property(surveyedVersion, "Location"), key);
                            if (ReadString(evidence, "Method") != name || Property(evidence, "Rva").GetUInt64() != addresses[0] ||
                                ReadInt(evidence, "RawOffset") != range.Offset || ReadInt(evidence, "Length") != range.Length ||
                                ReadInt(evidence, "FragmentCount") != range.FragmentCount)
                                throw new InvalidDataException("Legacy method bounds differ from the bound survey proof.");
                        }
                        result.LegacyMethodBounds = bounds.ToArray();
                        result.BoundsMatchSurvey = true;
                    }
                }
                catch (Exception error) { result.Error = error.ToString(); }
                result.EffectiveOffsets = Snapshot(versionMethod);
                if (result.MethodBounds != null && result.ConfiguredOffsets != null && result.EffectiveOffsets != null)
                {
                    result.ConfiguredOffsetsInsideMethod = result.ConfiguredOffsets.Values.All(offset => offset >= 0 && offset < result.MethodBounds.Length);
                    result.EffectiveOffsetsInsideMethod = result.EffectiveOffsets.Values.All(offset => offset >= 0 && offset < result.MethodBounds.Length);
                    if (result.DecodedValueOffsets != null)
                    {
                        result.ConfiguredOffsetsExactlyMatchDecodedStores = result.ConfiguredOffsets.Values.SequenceEqual(result.DecodedValueOffsets);
                        result.EffectiveOffsetsExactlyMatchDecodedStores = result.EffectiveOffsets.Values.SequenceEqual(result.DecodedValueOffsets);
                    }
                }
                result.NumericIdentityMatches = result.ProductionVersion != null && result.ProductionVersion == result.DecodedVersion;
                result.TypeByteMatches = result.DecodedTypeByte.HasValue && result.ProductionTypeByte.HasValue
                    ? result.DecodedTypeByte == result.ProductionTypeByte : null;
                result.Status = result.UsesLegacyVersionReader ?
                    result.Error != null ? "ReaderError" :
                    result.BoundsMatchSurvey != true || result.LegacyLocationMatchesSurvey != true ? "UnboundedOrOutsideMethod" :
                    result.LegacyReaderMatchesSurvey != true || result.LegacyEvidenceMatchesSurvey != true || result.LegacyLabelsMatchSurvey != true ? "LegacyEvidenceMismatch" :
                    !result.NumericIdentityMatches || result.LegacyTypeUnknown != true ? "IdentityMismatch" : "Passed" :
                    result.Error != null ? "ReaderError" :
                    result.EffectiveOffsetsInsideMethod != true || result.BoundsMatchSurvey != true ? "UnboundedOrOutsideMethod" :
                    result.EffectiveOffsetsExactlyMatchDecodedStores != true ? "OffsetMismatch" :
                    !result.NumericIdentityMatches || result.TypeByteMatches != true ? "IdentityMismatch" : "Passed";
                RequireEqualHash(HashFile(scriptPath), result.ScriptSha256, "unchanged script");
                RequireEqualHash(HashFile(reportPath), result.SurveyReportSha256, "unchanged survey report");
            }
            catch (Exception error) { result.Status = "AuditError"; result.Error = error.ToString(); }
            finally
            {
                legacyMetadataStream?.Dispose();
                result.EffectiveOffsets ??= Snapshot(versionMethod);
                if (assemblyPath != null && File.Exists(assemblyPath))
                {
                    result.AssemblySha256After = HashFile(assemblyPath);
                    result.AssemblyUnchanged = result.AssemblySha256 == result.AssemblySha256After;
                }
                if (readerBuffer != null)
                    result.ReaderBufferUnchanged = Convert.ToHexString(SHA256.HashData(readerBuffer)) == result.AssemblySha256;
                if (result.MetadataPath != null && File.Exists(result.MetadataPath))
                    result.MetadataUnchanged = HashFile(result.MetadataPath) == result.MetadataSha256;
                if (result.AssemblyUnchanged == false || result.ReaderBufferUnchanged == false || result.MetadataUnchanged == false)
                    result.Status = "InputChanged";
            }
            results.Add(result);
            Console.WriteLine($"{result.Status} {result.ManifestId}: decoded {result.DecodedVersion}/{result.DecodedTypeByte}, production {result.ProductionVersion}/{result.ProductionTypeByte}, auto={result.AutoFindConfigured}");
        }
        if (protectedInputs.Contains(outputPath)) throw new ArgumentException("Version-reader output cannot overwrite a source, metadata, map, or report input.");
        if (HashFile(indexPath) != indexHash || HashFile(manifestPath) != manifestHash)
            throw new InvalidDataException("The index or feed changed during the version-reader audit.");
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        File.WriteAllText(outputPath, System.Text.Json.JsonSerializer.Serialize(new
        {
            CreatedUtc = DateTimeOffset.UtcNow, AuditIndexPath = indexPath, AuditIndexSha256 = indexHash,
            PatternManifestPath = manifestPath, PatternManifestSha256 = manifestHash, ManifestAndIndexUnchanged = true,
            Total = results.Count, Passed = results.Count(result => result.Status == "Passed"),
            StatusCounts = results.GroupBy(result => result.Status).ToDictionary(group => group.Key, group => group.Count()),
            Acceptance = "Actual production AutoFindGameVersionOffsets when configured, then GetGameVersion, on private buffers and deep-cloned per-row profiles. No patching, ChangeGameVersion, saving, launcher changes, metadata writes, modal dialogs, or game-code execution.",
            Results = results
        }, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine);
        return results.All(result => result.Status == "Passed") ? 0 : 1;
    }

    private sealed record Bounds(string Method, ulong Rva, int RawOffset, int Length, int FragmentCount);
    private sealed record Offsets(int Major, int Minor, int Revision, int Type)
    {
        [System.Text.Json.Serialization.JsonIgnore] public int[] Values => new[] { Major, Minor, Revision, Type };
    }
    private sealed class Result
    {
        public string ManifestId { get; set; } = "local";
        public string Status { get; set; } = "AuditError";
        public string? SurveyReportPath { get; set; }
        public string? SurveyReportSha256 { get; set; }
        public string? AssemblyPath { get; set; }
        public string? AssemblySha256 { get; set; }
        public string? AssemblySha256After { get; set; }
        public string? ScriptSha256 { get; set; }
        public string? MetadataPath { get; set; }
        public string? MetadataSha256 { get; set; }
        public string? SelectedRange { get; set; }
        public string? ConfiguredMethod { get; set; }
        public string? SurveyReader { get; set; }
        public JsonElement? SurveyVersionLocation { get; set; }
        public int MethodAddressCount { get; set; }
        public Bounds? MethodBounds { get; set; }
        public bool? BoundsMatchSurvey { get; set; }
        public bool AutoFindConfigured { get; set; }
        public bool AutoFindCalled { get; set; }
        public bool GetGameVersionCalled { get; set; }
        public bool UsesLegacyVersionReader { get; set; }
        public int? LegacyMetadataSchema { get; set; }
        public Bounds[]? LegacyMethodBounds { get; set; }
        public bool? LegacyReaderMatchesSurvey { get; set; }
        public bool? LegacyLocationMatchesSurvey { get; set; }
        public bool? LegacyEvidenceMatchesSurvey { get; set; }
        public bool? LegacyLabelsMatchSurvey { get; set; }
        public bool? LegacyTypeUnknown { get; set; }
        public Offsets? ConfiguredOffsets { get; set; }
        public Offsets? EffectiveOffsets { get; set; }
        public int DecodedCandidateCount { get; set; }
        public int[]? DecodedValueOffsets { get; set; }
        public bool? ConfiguredOffsetsInsideMethod { get; set; }
        public bool? EffectiveOffsetsInsideMethod { get; set; }
        public bool? ConfiguredOffsetsExactlyMatchDecodedStores { get; set; }
        public bool? EffectiveOffsetsExactlyMatchDecodedStores { get; set; }
        public string? DecodedVersion { get; set; }
        public int? DecodedTypeByte { get; set; }
        public string? ProductionVersion { get; set; }
        public int? ProductionTypeByte { get; set; }
        public bool NumericIdentityMatches { get; set; }
        public bool? TypeByteMatches { get; set; }
        public bool? AssemblyUnchanged { get; set; }
        public bool? ReaderBufferUnchanged { get; set; }
        public bool? MetadataUnchanged { get; set; }
        public string? Error { get; set; }
    }
    private static Offsets? Snapshot(GameVersionMethodInfo? value) => value == null ? null : new(value.majorOffset, value.minorOffset, value.revisionOffset, value.typeOffset);
    private static bool TryProperty(JsonElement value, string name, out JsonElement result)
    {
        if (value.ValueKind == JsonValueKind.Object)
            foreach (JsonProperty property in value.EnumerateObject())
                if (property.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) { result = property.Value; return true; }
        result = default; return false;
    }
    private static JsonElement Property(JsonElement value, string name) => TryProperty(value, name, out JsonElement result) ? result :
        throw new InvalidDataException($"Missing report field {name}.");
    private static string? ReadString(JsonElement value, string name) => TryProperty(value, name, out JsonElement result) && result.ValueKind == JsonValueKind.String ? result.GetString() : null;
    private static int? ReadInt(JsonElement value, string name) => TryProperty(value, name, out JsonElement result) && result.ValueKind == JsonValueKind.Number && result.TryGetInt32(out int number) ? number : null;
    private static string HashFile(string path) { using var input = File.OpenRead(path); using var hash = SHA256.Create(); return Convert.ToHexString(hash.ComputeHash(input)); }
    private static void RequireEqualHash(string actual, string? expected, string input)
    {
        if (!string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"{input} hash does not match its bound evidence.");
    }
    private static bool Equivalent(object? actual, JsonElement expected) => JToken.DeepEquals(
        JToken.Parse(System.Text.Json.JsonSerializer.Serialize(actual)), JToken.Parse(expected.GetRawText()));
    private static void Set(object instance, string field, object value) => instance.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(instance, value);
}
