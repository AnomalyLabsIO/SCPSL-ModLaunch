using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class LegacyReleaseVersionTests
{
    public static void Register(Action<string, Action> run)
    {
        foreach ((string label, byte revision, string expected) in new[]
        {
            ("10.1.0", (byte)0, "10.1.0"),
            ("10.1.1", (byte)2, "10.1.2"),
            ("10.1.2", (byte)3, "10.1.3")
        })
        {
            run($"legacy native reader verifies {expected} independently of stale compatible label", () =>
            {
                var fixture = new LegacyFixture(label, revision);
                byte[] before = (byte[])fixture.Pe.Image.Clone();
                LegacyReleaseVersionReader.Result actual = fixture.Read();
                Check(actual.VerifiedVersion == expected && actual.Reader == "LegacyCompatibleVersions", "Wrong legacy release identity or reader.");
                Check(actual.VersionTypeByte == null, "Legacy beta flags were promoted to the modern version enum.");
                Check(actual.Location != null && actual.LegacyEvidence != null, "Legacy identity has no native evidence.");
                Check(fixture.Pe.Image.SequenceEqual(before), "The read-only legacy reader changed its input.");
            });
        }

        run("legacy native reader rejects ambiguous metadata strings", () =>
        {
            var fixture = new LegacyFixture();
            fixture.Strings.Add(LegacyFixture.Literal + 8, "10.9.9");
            fixture.RipAt(0x10, new byte[] { 0x4C, 0x8B, 0x05 }, LegacyFixture.Literal + 8);
            RejectUnchanged(fixture);
        });
        run("legacy native reader rejects duplicate native revision stores", () =>
        {
            var fixture = new LegacyFixture();
            fixture.EmitNetworkStoreAt(0x160, 0x48, 3);
            RejectUnchanged(fixture);
        });
        run("legacy native reader rejects a publication bound to another type", () =>
        {
            var fixture = new LegacyFixture();
            fixture.RipAt(fixture.PublicationTypeLoad, new byte[] { 0x48, 0x8B, 0x05 }, LegacyFixture.NetworkType + 8);
            RejectUnchanged(fixture);
        });
        run("legacy native reader rejects a mismatched indexed parse call", () =>
        {
            var fixture = new LegacyFixture();
            fixture.RelativeAt(fixture.MinorParseCall, 0xE8, LegacyFixture.TryParse + 8);
            RejectUnchanged(fixture);
        });
        run("legacy native reader rejects implausible native revision", () => RejectUnchanged(new LegacyFixture(revision: 100)));
        run("legacy native reader rejects truncated native instruction", () =>
        {
            var fixture = new LegacyFixture();
            fixture.Pe.Put(0x3FF, 0x0F);
            RejectUnchanged(fixture);
        });
        run("legacy native reader rejects absent and ambiguous type identities", () =>
        {
            var absent = new LegacyFixture();
            absent.Labels.Remove(LegacyFixture.NetworkType);
            RejectUnchanged(absent);
            var ambiguous = new LegacyFixture();
            ambiguous.Labels.Add(LegacyFixture.NetworkType + 8, new() { "CustomNetworkManager_TypeInfo" });
            RejectUnchanged(ambiguous);
        });

        run("production version reader keeps an existing modern method authoritative", () =>
        {
            var fixture = new SyntheticPe(new("GameCore.Version$$.cctor", 0, 0x40), new("CustomNetworkManager$$.cctor", 0x40, 0x40));
            fixture.Put(0x10, 11, 2, 0, 0);
            GameVersion actual = fixture.CreatePatcher(Profile(0x10, 0x11, 0x12, 0x13)).GetGameVersion();
            Check(actual.ToString() == "11.2.0" && actual.type == GameVersion.VersionType.Release, "Modern version was replaced by legacy detection.");
        });
        run("production version reader does not fall through after an existing modern method fails", () =>
        {
            var fixture = new SyntheticPe(new("GameCore.Version$$.cctor", 0, 0x40), new("CustomNetworkManager$$.cctor", 0x40, 0x40));
            Patcher patcher = fixture.CreatePatcher(Profile(int.MaxValue, 0, 0, 0));
            try { patcher.GetGameVersion(); }
            catch (IndexOutOfRangeException) { return; }
            throw new Exception("An invalid existing modern method did not retain its original read failure.");
        });
        run("production version reader does not substitute legacy data for a missing custom method", () =>
        {
            var fixture = new LegacyFixture();
            VersionRangeInfo profile = Profile();
            profile.methods.gameVersionMethod!.name = "Fixture.CustomVersion$$.cctor";
            try { fixture.Pe.CreatePatcher(profile).GetGameVersion(); }
            catch (GameVersionNotFoundException) { return; }
            throw new Exception("A missing custom version method unexpectedly fell through to the default legacy reader.");
        });
        run("legacy numeric identities retain an unknown modern enum type", () =>
        {
            var actual = new GameVersion(10, 1, 2);
            Check(actual.ToString() == "10.1.2" && actual.type == null, "A legacy numeric identity fabricated a modern version type.");
        });
        run("legacy ChangeGameVersion rejects before changing native bytes", () =>
        {
            var fixture = new LegacyFixture();
            byte[] before = (byte[])fixture.Pe.Image.Clone();
            try { fixture.Pe.CreatePatcher(Profile()).ChangeGameVersion(new GameVersion(10, 1, 2, 0)); }
            catch (NotSupportedException)
            {
                Check(fixture.Pe.Image.SequenceEqual(before), "Legacy version editing partially wrote the input.");
                return;
            }
            throw new Exception("Legacy version editing was not rejected.");
        });
    }

    private static VersionRangeInfo Profile(int major = 0, int minor = 1, int revision = 2, int type = 3) => new()
    {
        methods = new() { gameVersionMethod = new() { majorOffset = major, minorOffset = minor, revisionOffset = revision, typeOffset = type } }
    };

    private static void RejectUnchanged(LegacyFixture fixture)
    {
        byte[] before = (byte[])fixture.Pe.Image.Clone();
        try { fixture.Read(); }
        catch (InvalidDataException)
        {
            Check(fixture.Pe.Image.SequenceEqual(before), "Rejected legacy evidence changed the native image.");
            return;
        }
        throw new Exception("Malformed or ambiguous legacy version evidence was accepted.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }

    /// <summary>Invented bounded instructions, labels and metadata; never loads or reads a game file.</summary>
    private sealed class LegacyFixture
    {
        public const ulong NetworkType = 0x9000, Literal = 0x9100, Split = 0x9200, TryParse = 0x9300;
        private const string Constructor = "CustomNetworkManager$$.cctor", Parser = "Misc$$ParseVersion";
        public SyntheticPe Pe { get; } = new(new(Constructor, 0, 0x200), new(Parser, 0x200, 0x200));
        public Dictionary<ulong, List<string>> Labels { get; } = new()
        {
            [NetworkType] = new() { "CustomNetworkManager_TypeInfo" },
            [Split] = new() { "System.String$$Split" }, [TryParse] = new() { "System.Byte$$TryParse" }
        };
        public Dictionary<ulong, string> Strings { get; } = new();
        public int PublicationTypeLoad { get; }
        public int MinorParseCall { get; }
        private int _position;

        public LegacyFixture(string label = "10.1.1", byte revision = 2)
        {
            Pe.Image.AsSpan(SyntheticPe.TextRaw, 0x400).Fill(0x90);
            Strings[Literal] = label;
            _position = 0x20;
            Rip(new byte[] { 0x4C, 0x8B, 0x05 }, Literal);
            Emit("48 8D 4B 20 49 8B D0 4C 89 01");
            PublicationTypeLoad = _position;
            Rip(new byte[] { 0x48, 0x8B, 0x05 }, NetworkType);
            Emit("48 8B D3 48 8B 88 B8 00 00 00 48 83 C1 40 48 89 19");
            NetworkStore(0x48, revision);
            NetworkStore(0x3A, 0);
            NetworkStore(0x3C, 0);
            Rip(new byte[] { 0x48, 0x8B, 0x05 }, NetworkType);
            Emit("48 8B 88 B8 00 00 00 48 8D 51 51 48 83 C1 50");
            Relative(0xE9, SyntheticPe.TextRva + 0x200);

            _position = 0x200;
            Emit("48 8B FA 48 8B F1");
            Rip(new byte[] { 0x48, 0x8B, 0x05 }, NetworkType);
            Emit("48 8B 80 B8 00 00 00 48 8B 48 40 48 8B 59 20 B9 2E 00 00 00 66 89 48 20");
            Relative(0xE8, Split);
            Emit("48 8B D8 45 33 C0 48 8B D6 48 8B 4B 20");
            Relative(0xE8, TryParse);
            Emit("45 33 C0 48 8B D7 48 8B 4B 28");
            MinorParseCall = _position;
            Relative(0xE8, TryParse);
            Emit("C3");
        }

        public LegacyReleaseVersionReader.Result Read() => LegacyReleaseVersionReader.Read(Pe.Image, Labels, Strings, new HashSet<ulong>(), name =>
            name switch
            {
                Constructor => new(name, SyntheticPe.TextRva, new(SyntheticPe.TextRaw, 0x200)),
                Parser => new(name, SyntheticPe.TextRva + 0x200, new(SyntheticPe.TextRaw + 0x200, 0x200)),
                _ => throw new InvalidDataException("Unknown synthetic method.")
            }, new[] { "CompatibleVersions", "SyncedRevision", "Major", "Minor", "PrivateBeta", "PublicBeta" });

        public void EmitNetworkStoreAt(int offset, byte field, byte value)
        {
            _position = offset;
            NetworkStore(field, value);
        }

        private void NetworkStore(byte field, byte value)
        {
            Rip(new byte[] { 0x48, 0x8B, 0x05 }, NetworkType);
            Emit("48 8B 88 B8 00 00 00");
            Pe.Put(_position, 0xC6, 0x41, field, value);
            _position += 4;
        }
        private void Emit(string bytes)
        {
            byte[] value = Convert.FromHexString(bytes.Replace(" ", ""));
            Pe.Put(_position, value);
            _position += value.Length;
        }
        private void Rip(byte[] opcode, ulong target)
        {
            RipAt(_position, opcode, target);
            _position += 7;
        }
        public void RipAt(int offset, byte[] opcode, ulong target)
        {
            Pe.Put(offset, opcode);
            Pe.Write32(SyntheticPe.TextRaw + offset + 3, checked((int)((long)target - (SyntheticPe.TextRva + offset + 7))));
        }
        private void Relative(byte opcode, ulong target)
        {
            RelativeAt(_position, opcode, target);
            _position += 5;
        }
        public void RelativeAt(int offset, byte opcode, ulong target)
        {
            Pe.Put(offset, opcode);
            Pe.Write32(SyntheticPe.TextRaw + offset + 1, checked((int)((long)target - (SyntheticPe.TextRva + offset + 5))));
        }
    }
}
