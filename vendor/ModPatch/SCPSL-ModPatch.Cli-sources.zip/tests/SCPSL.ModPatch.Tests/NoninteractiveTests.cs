using System.Buffers.Binary;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using Il2CppDumper;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

internal static class NoninteractiveTests
{
    public static void Register(Action<string, Action> run)
    {
        foreach (bool pattern in new[] { false, true })
        {
            bool usePattern = pattern;
            run($"headless missing required {(pattern ? "pattern" : "legacy")} method fails before applying any patch", () =>
            {
                var fixture = new SyntheticPe();
                byte[] original = (byte[])fixture.Image.Clone();
                PatchMethodInfo missing = Patch("Fixture.Missing$$Run");
                if (usePattern) missing.patchPattern = "DE AD BE EF";
                Patcher patcher = CreatePatcher(fixture, Profile(Patch(SyntheticPe.A), missing));

                Expect<InvalidDataException>(patcher.PatchGameAssembly, "Couldn't find (Fixture.Missing$$Run)");

                Check(fixture.Image.SequenceEqual(original), "A required missing method left a partial patch.");
                Check(patcher.PatchOutcomes.Count == 0, "A failed operation reported applied patches.");
            });
        }

        run("headless outcomes distinguish applied optional and fallback methods", () =>
        {
            var fixture = new SyntheticPe();
            byte[] expected = (byte[])fixture.Image.Clone();
            expected[SyntheticPe.TextRaw] = 0xC3;
            expected[SyntheticPe.TextRaw + 0x80] = 0xC3;
            PatchMethodInfo optional = Patch("Fixture.Optional$$Run");
            optional.nowarning = true;
            PatchMethodInfo optionalPattern = Patch("Fixture.OptionalPattern$$Run");
            optionalPattern.patchPattern = "DE AD BE EF";
            optionalPattern.nowarning = true;
            PatchMethodInfo unnecessaryFallback = Patch(SyntheticPe.B);
            unnecessaryFallback.patchifnotexists = SyntheticPe.A;
            PatchMethodInfo necessaryFallback = Patch(SyntheticPe.C);
            necessaryFallback.patchifnotexists = "Fixture.NewerImplementation$$Run";
            Patcher patcher = CreatePatcher(fixture,
                Profile(Patch(SyntheticPe.A), optional, optionalPattern, unnecessaryFallback, necessaryFallback));

            patcher.PatchGameAssembly();

            Check(fixture.Image.SequenceEqual(expected), "Optional or unnecessary fallback methods changed bytes.");
            Check(patcher.PatchOutcomes.Select(outcome => outcome.Name).SequenceEqual(new[]
            {
                SyntheticPe.A, optional.name, optionalPattern.name, SyntheticPe.B, SyntheticPe.C
            }), "Outcomes lost method identity or feed order.");
            Check(patcher.PatchOutcomes.Select(outcome => outcome.Status).SequenceEqual(new[]
            {
                "applied", "skipped-optional", "skipped-optional", "skipped-fallback", "applied"
            }), "Outcomes do not describe the methods actually applied or skipped.");
            Check(patcher.PatchOutcomes.All(outcome => !string.IsNullOrWhiteSpace(outcome.Message)),
                "An outcome has no human-readable explanation.");
        });

        run("headless preparation failure publishes no applied outcomes and preserves every byte", () =>
        {
            var fixture = new SyntheticPe();
            byte[] original = (byte[])fixture.Image.Clone();
            PatchMethodInfo failing = Patch(SyntheticPe.B);
            failing.patchPattern = "DE AD BE EF";
            Patcher patcher = CreatePatcher(fixture, Profile(Patch(SyntheticPe.A), failing));

            Expect<InvalidDataException>(patcher.PatchGameAssembly, "Couldn't prepare patch");

            Check(fixture.Image.SequenceEqual(original), "Preparation failure wrote an earlier planned method.");
            Check(patcher.PatchOutcomes.Count == 0, "Preparation failure reported applied patches.");
        });

        run("headless invalid launcher path throws without a dialog", () =>
        {
            var fixture = new SyntheticPe();
            VersionRangeInfo profile = Profile();
            profile.cleanLauncherPath = "invalid\0launcher.exe";
            Expect<InvalidDataException>(() => CreatePatcher(fixture, profile).ReplaceLauncher(Path.GetTempPath()),
                "Invalid launcher path");
        });

        run("headless missing launcher rejects the download path without a dialog", () =>
        {
            var fixture = new SyntheticPe();
            VersionRangeInfo profile = Profile();
            profile.cleanLauncherPath = Path.Combine(Path.GetTempPath(), $"SCPSL.ModPatch.Missing-{Guid.NewGuid():N}.exe");
            profile.cleanLauncherUrl = "https://example.invalid/launcher.exe";
            Expect<FileNotFoundException>(() => CreatePatcher(fixture, profile).ReplaceLauncher(Path.GetTempPath()),
                "A local clean launcher is required");
            Check(!File.Exists(profile.cleanLauncherPath), "A missing launcher test created or downloaded a launcher.");
        });

        run("headless fat Mach-O rejects platform keyboard selection", () => ProbeWorker("fat"));

        run("headless ELF dump rejects the dump-address input branch", () => ProbeWorker("elf"));

        run("headless registration discovery failure rejects manual address input", () => ProbeWorker("manual"));
    }

    internal static int RunWorkerProbe(string[] args)
    {
        try
        {
            if (args.Length != 2) throw new ArgumentException("A worker probe branch is required.");
            switch (args[1])
            {
                case "fat":
                    foreach (uint magic in new[] { 0xCAFEBABEu, 0xBEBAFECAu })
                    {
                        byte[] image = new byte[8];
                        BinaryPrimitives.WriteUInt32LittleEndian(image, magic);
                        Expect<NotSupportedException>(() => Init(image, new Config()), "interactive platform selection");
                    }
                    break;
                case "elf":
                    Expect<NotSupportedException>(() => Init(Elf64(), new Config { ForceDump = true }),
                        "interactive dump address");
                    break;
                case "manual":
                    Expect<InvalidDataException>(() => Init(Macho64(), new Config()),
                        "Manual registration addresses require interactive mode");
                    break;
                default:
                    throw new ArgumentException($"Unknown worker probe branch: {args[1]}");
            }
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    private static void ProbeWorker(string branch)
    {
        var start = new ProcessStartInfo
        {
            FileName = Path.Combine(AppContext.BaseDirectory, "SCPSL.ModPatch.Tests.exe"),
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        start.ArgumentList.Add("--probe-noninteractive-worker");
        start.ArgumentList.Add(branch);
        using var process = Process.Start(start) ?? throw new Exception("Could not start the worker input probe.");
        // Keep stdin open and provide no bytes. A regressed ReadLine must hang the child,
        // not appear safe merely because redirected stdin immediately returned EOF.
        Task<string> output = process.StandardOutput.ReadToEndAsync();
        Task<string> error = process.StandardError.ReadToEndAsync();
        Task finished = Task.WhenAll(process.WaitForExitAsync(), output, error);
        try
        {
            finished.WaitAsync(TimeSpan.FromSeconds(10)).GetAwaiter().GetResult();
        }
        catch (TimeoutException)
        {
            try
            {
                process.Kill(entireProcessTree: true);
                process.WaitForExit(5000);
            }
            catch (InvalidOperationException) { }
            throw new Exception($"Worker {branch} probe did not exit within 10 seconds with stdin held open.");
        }
        Check(process.ExitCode == 0,
            $"Worker {branch} probe failed (exit {process.ExitCode}). stdout: {output.GetAwaiter().GetResult()} stderr: {error.GetAwaiter().GetResult()}");
    }

    private static Patcher CreatePatcher(SyntheticPe fixture, VersionRangeInfo profile)
    {
        // Reuse the fixture's real PE mapping and method table; only the CLI policy differs.
        Patcher interactive = fixture.CreatePatcher(profile);
        var manager = (Il2cppManager)typeof(Patcher).GetField("_il2cppManager", BindingFlags.Instance | BindingFlags.NonPublic)!
            .GetValue(interactive)!;
        return new Patcher("unused-headless-GameAssembly.dll", fixture.Image, manager, profile, interactive: false);
    }

    private static VersionRangeInfo Profile(params PatchMethodInfo[] methods) =>
        new() { methods = new MethodsInfo { patchMethods = methods } };

    private static PatchMethodInfo Patch(string name) => new() { name = name, patchData = "C3" };

    private static void Init(byte[] image, Config config)
    {
        // A valid empty metadata v29 header keeps the test on the binary/input path.
        byte[] metadata = new byte[512];
        BinaryPrimitives.WriteUInt32LittleEndian(metadata, 0xFAB11BAF);
        BinaryPrimitives.WriteInt32LittleEndian(metadata.AsSpan(4), 29);
        Il2CppDumperWorker.Init(image, metadata, config, out _, out _, interactive: false);
    }

    private static byte[] Elf64()
    {
        // ELF64 with one empty PT_DYNAMIC segment is sufficient to load, then ForceDump
        // reaches the real worker's dump-address decision before registration discovery.
        byte[] image = new byte[256];
        BinaryPrimitives.WriteUInt32LittleEndian(image, 0x464C457F);
        image[4] = 2; // ELFCLASS64
        image[5] = 1; // ELFDATA2LSB
        image[6] = 1; // EV_CURRENT
        BinaryPrimitives.WriteUInt16LittleEndian(image.AsSpan(16), 3); // ET_DYN
        BinaryPrimitives.WriteUInt16LittleEndian(image.AsSpan(18), 62); // EM_X86_64
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(20), 1);
        BinaryPrimitives.WriteUInt64LittleEndian(image.AsSpan(32), 64); // e_phoff
        BinaryPrimitives.WriteUInt16LittleEndian(image.AsSpan(52), 64); // e_ehsize
        BinaryPrimitives.WriteUInt16LittleEndian(image.AsSpan(54), 56); // e_phentsize
        BinaryPrimitives.WriteUInt16LittleEndian(image.AsSpan(56), 1); // e_phnum
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(64), 2); // PT_DYNAMIC
        BinaryPrimitives.WriteUInt64LittleEndian(image.AsSpan(72), 128); // p_offset
        return image;
    }

    private static byte[] Macho64()
    {
        // An empty initialization section lets all real automatic discovery strategies
        // return false, reaching the worker's manual-registration decision.
        byte[] image = new byte[184];
        BinaryPrimitives.WriteUInt32LittleEndian(image, 0xFEEDFACF);
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(16), 1); // ncmds
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(20), 152); // sizeofcmds
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(32), 25); // LC_SEGMENT_64
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(36), 152); // cmdsize
        Encoding.ASCII.GetBytes("__DATA").CopyTo(image, 40);
        BinaryPrimitives.WriteUInt32LittleEndian(image.AsSpan(96), 1); // nsects
        Encoding.ASCII.GetBytes("__mod_init_func").CopyTo(image, 104);
        Encoding.ASCII.GetBytes("__DATA").CopyTo(image, 120);
        return image;
    }

    private static void Expect<TException>(Action action, string message) where TException : Exception
    {
        try { action(); }
        catch (TException ex)
        {
            Check(ex.Message.Contains(message, StringComparison.Ordinal), $"Unexpected failure: {ex}");
            return;
        }
        throw new Exception($"Expected {typeof(TException).Name}: {message}");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}
