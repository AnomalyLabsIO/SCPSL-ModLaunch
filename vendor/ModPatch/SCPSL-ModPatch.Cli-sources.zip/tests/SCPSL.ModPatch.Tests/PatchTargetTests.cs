using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class PatchTargetTests
{
    private static readonly Version Release = new(10, 1, 1);
    private static readonly string Hash = new('A', 64);
    private static readonly string OtherHash = new('B', 64);

    public static void Register(Action<string, Action> run)
    {
        run("target selectors survive both production JSON loaders", () =>
        {
            const string json = @"{""versionRanges"":[
                {""versionRange"":""range"",""versionFrom"":""10.0.0"",""versionTo"":""11.0.0"",""metadataVersion"":24,""cleanLauncherPath"":""range.exe"",""methods"":{""patchMethods"":[]}},
                {""versionRange"":""exact"",""version"":""10.1.1"",""metadataVersion"":29,""cleanLauncherPath"":""exact.exe"",""methods"":{""patchMethods"":[]}},
                {""versionRange"":""hash"",""gameAssemblySha256"":""aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"",""metadataVersion"":31,""cleanLauncherPath"":""hash.exe"",""methods"":{""patchMethods"":[]}}
            ]}";
            PatchInfo first = JsonConvert.DeserializeObject<PatchInfo>(json)!;
            PatchInfo second = System.Text.Json.JsonSerializer.Deserialize<PatchInfo>(json, MainForm.JsonOptions)!;
            foreach (PatchInfo feed in new[] { first, second })
            {
                PatchTargetResolver.Validate(feed);
                Check(feed.versionRanges.Length == 3, "A target disappeared during deserialization.");
                Check(feed.versionRanges[0].version == null && feed.versionRanges[0].gameAssemblySha256 == null,
                    "Legacy range acquired another selector.");
                Check(feed.versionRanges[1].version == "10.1.1" && feed.versionRanges[1].versionFrom == string.Empty,
                    "Exact version fields changed.");
                Check(feed.versionRanges[2].gameAssemblySha256 == Hash.ToLowerInvariant(), "SHA-256 fields changed.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, Hash, Release), feed.versionRanges[2]),
                    "Deserialized hash did not select its complete profile.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, Release), feed.versionRanges[1]),
                    "Deserialized exact version did not override the range.");
            }
        });

        run("target specificity is hash then exact then range independent of order", () =>
        {
            VersionRangeInfo range = Range();
            VersionRangeInfo exact = Exact();
            VersionRangeInfo hash = Hashed();
            foreach (VersionRangeInfo[] order in new[]
            {
                new[] { range, exact, hash }, new[] { hash, exact, range }, new[] { exact, range, hash },
                new[] { range, hash, exact }, new[] { exact, hash, range }, new[] { hash, range, exact }
            })
            {
                PatchInfo feed = Feed(order);
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, Hash, Release), hash), "Hash lost precedence.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, Release), exact), "Exact version lost precedence.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, new Version(10, 2, 0)), range), "Range fallback failed.");
            }
        });

        run("most specific target replaces the whole profile without merging", () =>
        {
            VersionRangeInfo range = Range();
            VersionRangeInfo exact = Exact();
            VersionRangeInfo hash = Hashed();
            range.methods.patchMethods = new[] { Patch(SyntheticPe.A, "AA BB") };
            exact.methods.patchMethods = new[] { Patch(SyntheticPe.B, "CC DD") };
            hash.methods.patchMethods = new[] { Patch(SyntheticPe.C, "EE FF") };
            PatchInfo feed = Feed(range, exact, hash);
            VersionRangeInfo selected = PatchTargetResolver.Resolve(feed, Hash, Release);
            Check(ReferenceEquals(selected, hash) && ReferenceEquals(selected.methods, hash.methods), "Resolver copied or combined profile payloads.");
            Check(selected.metadataVersion == 31 && selected.cleanLauncherPath == "hash.exe", "Selected profile inherited parser or launcher settings.");
            Check(selected.methods.patchMethods.Length == 1 && selected.methods.patchMethods[0].name == SyntheticPe.C,
                "Methods were merged from lower tiers.");
        });

        run("hash-only target works without a detected version or containing range", () =>
        {
            VersionRangeInfo hash = Hashed();
            PatchInfo feed = Feed(hash);
            Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, Hash.ToLowerInvariant(), null), hash), "Hash-only target required a version.");
            Check(ReferenceEquals(PatchTargetResolver.ResolveHash(feed, Hash), hash), "Hash bootstrap did not select its target.");
            Check(PatchTargetResolver.ResolveHash(feed, OtherHash) == null, "Unmatched hash bootstrap invented a target.");
        });

        run("exact-only target works outside every range", () =>
        {
            VersionRangeInfo exact = Exact();
            PatchInfo feed = Feed(exact);
            Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, Release), exact), "Standalone exact target failed.");
            Check(PatchTargetResolver.ResolveHash(feed, Hash) == null, "Hash bootstrap selected an exact-version target.");
            Reject(() => PatchTargetResolver.Resolve(feed, OtherHash, null));
        });

        run("range endpoints are inclusive and compare components numerically", () =>
        {
            VersionRangeInfo range = Range("13.9.0", "13.10.0");
            PatchInfo feed = Feed(range);
            foreach (Version version in new[] { new Version(13, 9, 0), new Version(13, 9, 255), new Version(13, 10, 0) })
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, Hash, version), range), "A numeric in-range endpoint was excluded.");
            Reject(() => PatchTargetResolver.Resolve(feed, Hash, new Version(13, 8, 255)));
            Reject(() => PatchTargetResolver.Resolve(feed, Hash, new Version(13, 10, 1)));
        });

        run("empty and Current upper range bounds remain unbounded", () =>
        {
            foreach (string upper in new[] { string.Empty, "Current", "current", "CURRENT" })
            {
                VersionRangeInfo range = Range("10.0.0", upper);
                Check(ReferenceEquals(PatchTargetResolver.Resolve(Feed(range), Hash, new Version(99, 0, 0)), range), "Unbounded range was capped.");
            }
        });

        run("legacy label-only targets remain broad ranges through both JSON loaders", () =>
        {
            const string json = @"{""versionRanges"":[{""versionRange"":""10.1.1"",""metadataVersion"":24,""cleanLauncherPath"":""legacy.exe"",""methods"":{""patchMethods"":[]}}]}";
            PatchInfo first = JsonConvert.DeserializeObject<PatchInfo>(json)!;
            PatchInfo second = System.Text.Json.JsonSerializer.Deserialize<PatchInfo>(json, MainForm.JsonOptions)!;
            foreach (PatchInfo feed in new[] { first, second })
            {
                PatchTargetResolver.Validate(feed);
                VersionRangeInfo legacy = feed.versionRanges[0];
                Check(legacy.version == null && legacy.gameAssemblySha256 == null, "Display label became another selector.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, new Version(0, 0, 0)), legacy),
                    "Omitted legacy lower bound did not start at zero.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, OtherHash, new Version(99, 0, 0)), legacy),
                    "Legacy display label was inferred as an exact version.");
                VersionRangeInfo narrow = Range();
                Reject(() => PatchTargetResolver.Resolve(Feed(legacy, narrow), OtherHash, Release));
                VersionRangeInfo exact = Exact();
                Check(ReferenceEquals(PatchTargetResolver.Resolve(Feed(legacy, narrow, exact), OtherHash, Release), exact),
                    "Ambiguous legacy ranges outranked a unique exact target.");
                VersionRangeInfo hash = Hashed();
                Check(ReferenceEquals(PatchTargetResolver.Resolve(Feed(legacy, narrow, exact, hash), Hash, Release), hash),
                    "Ambiguous legacy ranges outranked a unique hash target.");
            }
        });

        run("no matching target is rejected instead of choosing a nearby range", () =>
        {
            Reject(() => PatchTargetResolver.Resolve(Feed(Range()), Hash, new Version(9, 9, 9)));
            Reject(() => PatchTargetResolver.Resolve(Feed(), Hash, Release));
            Reject(() => PatchTargetResolver.Resolve(Feed(Range()), Hash, null));
        });

        run("ambiguous winning-tier targets are rejected", () =>
        {
            Reject(() => PatchTargetResolver.Resolve(Feed(Hashed(), Hashed()), Hash, Release));
            Reject(() => PatchTargetResolver.ResolveHash(Feed(Hashed(), Hashed()), Hash));
            Reject(() => PatchTargetResolver.Resolve(Feed(Exact(), Exact(), Range()), OtherHash, Release));
            Reject(() => PatchTargetResolver.Resolve(Feed(Range(), Range("10.1.0", "12.0.0")), OtherHash, Release));
        });

        run("ambiguity in a lower tier does not outrank a unique higher-tier target", () =>
        {
            VersionRangeInfo hash = Hashed();
            Check(ReferenceEquals(PatchTargetResolver.Resolve(Feed(Exact(), hash, Exact(), Range(), Range()), Hash, Release), hash),
                "Lower-tier matches interfered with the unique hash target.");
            VersionRangeInfo exact = Exact();
            Check(ReferenceEquals(PatchTargetResolver.Resolve(Feed(Range(), exact, Range()), OtherHash, Release), exact),
                "Lower-tier ranges interfered with the exact target.");
        });

        run("malformed target selectors are rejected anywhere in the feed", () =>
        {
            var invalid = new List<VersionRangeInfo>
            {
                new(),
                new() { gameAssemblySha256 = new string('A', 63) },
                new() { gameAssemblySha256 = new string('G', 64) },
                new() { version = "10.1" },
                new() { version = "10.1.1.0" },
                new() { version = "10.-1.1" },
                new() { version = "10.1.Current" },
                Range("11.0.0", "10.0.0"),
                Range("Current", "11.0.0"),
                Range("10.0.0", "invalid")
            };
            foreach (VersionRangeInfo profile in invalid)
            {
                Reject(() => PatchTargetResolver.Validate(Feed(profile)));
                Reject(() => PatchTargetResolver.Resolve(Feed(Hashed(), profile), Hash, Release));
                Reject(() => PatchTargetResolver.ResolveHash(Feed(Hashed(), profile), Hash));
            }
        });

        run("conflicting hash exact and range selector fields are rejected", () =>
        {
            foreach (VersionRangeInfo profile in new[]
            {
                new VersionRangeInfo { gameAssemblySha256 = Hash, version = "10.1.1" },
                new VersionRangeInfo { gameAssemblySha256 = Hash, versionFrom = "10.0.0" },
                new VersionRangeInfo { gameAssemblySha256 = Hash, versionTo = "11.0.0" },
                new VersionRangeInfo { version = "10.1.1", versionFrom = "10.0.0" },
                new VersionRangeInfo { version = "10.1.1", versionTo = "11.0.0" }
            }) Reject(() => PatchTargetResolver.Validate(Feed(profile)));
        });

        run("SHA-256 helper hashes the exact original bytes", () =>
        {
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes("abc");
            byte[] original = (byte[])bytes.Clone();
            string actual = PatchTargetResolver.ComputeSha256(bytes);
            Check(actual.Equals("BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD", StringComparison.OrdinalIgnoreCase), "SHA-256 differs from the known vector.");
            Check(bytes.SequenceEqual(original), "Hashing changed the input bytes.");
        });

        run("selected higher-tier patch failure is atomic and does not fall back", () =>
        {
            foreach (bool useHash in new[] { false, true })
            {
                var fixture = new SyntheticPe();
                fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
                byte[] original = (byte[])fixture.Image.Clone();
                VersionRangeInfo range = Range();
                range.methods.patchMethods = new[] { Patch(SyntheticPe.A, "DE AD BE EF") };
                VersionRangeInfo higher = useHash ? Hashed(PatchTargetResolver.ComputeSha256(original)) : Exact();
                higher.methods.patchMethods = new[]
                {
                    Patch(SyntheticPe.A, "DE AD BE EF"),
                    Patch(SyntheticPe.B, "12 34 56 78")
                };
                PatchInfo feed = Feed(range, higher);
                VersionRangeInfo selected = PatchTargetResolver.Resolve(feed, PatchTargetResolver.ComputeSha256(original), Release);
                Check(ReferenceEquals(selected, higher), "Resolver selected the lower-tier valid range.");
                Reject(() => fixture.CreatePatcher(selected).PatchGameAssembly());
                Check(fixture.Image.SequenceEqual(original), "The failed complete patch set wrote a partial patch or fell back.");
                Check(ReferenceEquals(PatchTargetResolver.Resolve(feed, PatchTargetResolver.ComputeSha256(original), Release), higher),
                    "A failed patch changed subsequent target selection.");
            }
        });

        run("direct hash target rejects mismatched original bytes atomically", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            byte[] original = (byte[])fixture.Image.Clone();
            VersionRangeInfo target = Hashed();
            target.methods.patchMethods = new[] { Patch(SyntheticPe.A, "DE AD BE EF") };
            Reject(() => fixture.CreatePatcher(target).PatchGameAssembly());
            Check(fixture.Image.SequenceEqual(original), "Mismatched hash target modified the image.");
        });

        run("changing displayed version before patch preserves original hash targeting", () =>
        {
            SyntheticPe fixture = VersionedFixture();
            byte[] expected = (byte[])fixture.Image.Clone();
            VersionRangeInfo target = VersionedHashTarget(fixture);
            Patcher patcher = fixture.CreatePatcher(target);
            patcher.ChangeGameVersion(new GameVersion(10, 2, 0, 0));
            patcher.PatchGameAssembly();
            expected[SyntheticPe.TextRaw + 1] = 2;
            expected[SyntheticPe.TextRaw + 2] = 0;
            expected[SyntheticPe.TextRaw + 0x44] = 0xC3;
            Check(fixture.Image.SequenceEqual(expected), "Version edit invalidated targeting or changed unrelated bytes.");
        });

        run("save refuses an externally changed target without overwriting it", () =>
        {
            SyntheticPe fixture = VersionedFixture();
            string path = TemporaryDllPath();
            try
            {
                File.WriteAllBytes(path, fixture.Image);
                Patcher patcher = fixture.CreatePatcher(VersionedHashTarget(fixture), path);
                patcher.PatchGameAssembly();
                byte[] external = File.ReadAllBytes(path);
                external[SyntheticPe.TextRaw + 0x85] ^= 0x11;
                File.WriteAllBytes(path, external);
                Reject(() => patcher.SaveGameAssembly());
                Check(File.ReadAllBytes(path).SequenceEqual(external), "Save overwrote the externally changed file.");
            }
            finally { File.Delete(path); }
        });

        run("patch save then version change save retains original and saved identities", () =>
        {
            SyntheticPe fixture = VersionedFixture();
            string path = TemporaryDllPath();
            try
            {
                File.WriteAllBytes(path, fixture.Image);
                Patcher patcher = fixture.CreatePatcher(VersionedHashTarget(fixture), path);
                patcher.PatchGameAssembly();
                patcher.SaveGameAssembly();
                Check(File.ReadAllBytes(path).SequenceEqual(fixture.Image), "The first save did not persist the patch.");
                patcher.ChangeGameVersion(new GameVersion(10, 2, 0, 0));
                patcher.SaveGameAssembly();
                byte[] saved = File.ReadAllBytes(path);
                Check(saved.SequenceEqual(fixture.Image), "The second save rejected or lost the version edit.");
                Check(saved[SyntheticPe.TextRaw + 0x44] == 0xC3 && saved[SyntheticPe.TextRaw + 1] == 2,
                    "Patch or version edit was lost across the two saves.");
            }
            finally { File.Delete(path); }
        });
    }

    private static SyntheticPe VersionedFixture()
    {
        var fixture = new SyntheticPe();
        fixture.Put(0, 10, 1, 1, 0);
        fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
        return fixture;
    }

    private static VersionRangeInfo VersionedHashTarget(SyntheticPe fixture)
    {
        VersionRangeInfo target = Hashed(PatchTargetResolver.ComputeSha256(fixture.Image));
        target.methods.patchMethods = new[] { Patch(SyntheticPe.B, "DE AD BE EF") };
        target.methods.gameVersionMethod = new GameVersionMethodInfo
        {
            name = SyntheticPe.A, majorOffset = 0, minorOffset = 1, revisionOffset = 2, typeOffset = 3
        };
        return target;
    }

    private static string TemporaryDllPath() => Path.Combine(Path.GetTempPath(), $"SCPSL.ModPatch.Tests-{Guid.NewGuid():N}.dll");

    private static PatchInfo Feed(params VersionRangeInfo[] targets) => new() { versionRanges = targets };
    private static VersionRangeInfo Range(string from = "10.0.0", string to = "11.0.0") =>
        new() { versionRange = "range", versionFrom = from, versionTo = to, metadataVersion = 24, cleanLauncherPath = "range.exe" };
    private static VersionRangeInfo Exact() =>
        new() { versionRange = "exact", version = "10.1.1", metadataVersion = 29, cleanLauncherPath = "exact.exe" };
    private static VersionRangeInfo Hashed(string? hash = null) =>
        new() { versionRange = "hash", gameAssemblySha256 = hash ?? Hash, metadataVersion = 31, cleanLauncherPath = "hash.exe" };
    private static PatchMethodInfo Patch(string name, string pattern) =>
        new() { name = name, patchPattern = pattern, patchData = "[RET]", patchSize = 1 };

    private static void Reject(Action action)
    {
        try { action(); }
        catch (InvalidDataException) { return; }
        throw new Exception("Expected an InvalidDataException.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}
