using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class TargetedFeedTests
{
    private const string Early1120Hash = "FC662B3B2B5D88FBECE05AAE6B5D4E772D9EC5ECAC85196B9977E64044A36BA6";
    private const string AwakeName = "LauncherAssetScanProgressBar$$Awake";
    private const string AuthPattern = "40 55 56 57 41 54 41 55 41 56 41 57 48 81 EC";
    private const string AwakePattern = "48 8B 48 08 8B 01 48 8B CB 89 43 38";
    private static readonly string OtherHash = new('0', 64);

    public static void Register(Action<string, Action> run)
    {
        run("actual feed retains the required CentralServer patch from 14.1.3 alongside menu patterns", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                VersionRangeInfo earlier = PatchTargetResolver.Resolve(feed, OtherHash, new Version(14, 1, 2));
                Check(!earlier.methods.patchMethods.Any(patch => patch.name == "CentralServer$$Init"),
                    "The newer CentralServer patch leaked into an older target.");
                foreach (Version version in new[] { new Version(14, 1, 3), new Version(14, 2, 7), new Version(14, 2, 8) })
                {
                    VersionRangeInfo target = PatchTargetResolver.Resolve(feed, OtherHash, version);
                    PatchMethodInfo central = target.methods.patchMethods.Single(patch => patch.name == "CentralServer$$Init");
                    Check(central.patchOffset == 0 && central.patchData == "[RET]" && central.patchSize == 5 && !central.nowarning,
                        "The required CentralServer entry patch was changed or made optional.");
                    Check(target.methods.patchMethods.Count(patch => patch.patchPattern != null) >= 2,
                        "The current feed lost the menu byte-pattern patches.");
                }
            }
        });

        run("actual feed isolates the early 11.2.0 hash from later builds through both loaders", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                PatchTargetResolver.Validate(feed);
                VersionRangeInfo early = feed.versionRanges.Single(target =>
                    string.Equals(target.gameAssemblySha256, Early1120Hash, StringComparison.OrdinalIgnoreCase));
                Check(early.version == null && early.versionFrom == string.Empty && early.versionTo == string.Empty,
                    "Early 11.2.0 must have only a hash selector.");
                Check(ReferenceEquals(PatchTargetResolver.ResolveHash(feed, Early1120Hash), early) &&
                    ReferenceEquals(PatchTargetResolver.Resolve(feed, Early1120Hash, new Version(11, 2, 0)), early),
                    "Early 11.2.0 did not select the complete hash target.");
                Check(early.metadataVersion == 24 && early.cleanLauncherPath.EndsWith("2019.4.16f1/SCPSL.exe", StringComparison.Ordinal),
                    "The hash target lost its parser or launcher configuration.");
                PatchMethodInfo auth = early.methods.patchMethods.Single();
                Check(auth.name == "CentralAuthManager$$Authentication" && auth.patchPattern == AuthPattern &&
                    auth.patchOffset == null && auth.patternOffset == 0 && auth.patchData == "[RET]" && auth.patchSize == 2 &&
                    !auth.nowarning && auth.patchifnotexists == null,
                    "The early hash target must contain only the required, unique-entry authentication patch.");
                VersionRangeInfo later = PatchTargetResolver.Resolve(feed, OtherHash, new Version(11, 2, 0));
                Check(!ReferenceEquals(early, later) && later.version == null && later.gameAssemblySha256 == null &&
                    later.versionFrom == "11.1.5" && later.versionTo == "12.0.2" &&
                    later.methods.patchMethods.Length == 4 &&
                    later.methods.patchMethods.Any(patch => patch.name == "SimpleMenu.<StartLoad>d__10$$MoveNext"),
                    "Other 11.2.0 binaries lost the complete verification-aware range target.");
            }
        });

        run("actual feed selects the complete exact 13.6.9 target outside its neighboring range", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                VersionRangeInfo exact = PatchTargetResolver.Resolve(feed, OtherHash, new Version(13, 6, 9));
                Check(exact.version == "13.6.9" && exact.gameAssemblySha256 == null &&
                    exact.versionFrom == string.Empty && exact.versionTo == string.Empty,
                    "13.6.9 must use only the exact-version selector.");
                Check(feed.versionRanges.Any(target => target.versionFrom == "13.0.0" && target.versionTo == "13.5.1") &&
                    !feed.versionRanges.Any(target => target.version == null && target.gameAssemblySha256 == null &&
                        Includes(target, new Version(13, 6, 9))),
                    "The exact 13.6.9 target must remain selectable without a containing range.");
                Check(exact.methods.patchMethods.Length == 5 && exact.metadataVersion == 29 &&
                    exact.methods.gameVersionMethod?.autoFindOffsets == true,
                    "The exact target lost part of its complete patch/parser configuration.");
                PatchMethodInfo awake = exact.methods.patchMethods.Single(patch => patch.name == AwakeName);
                Check(awake.patchPattern == AwakePattern && awake.patternOffset == 4 && awake.patchOffset == null &&
                    awake.patchData == "33 C0" && awake.patchSize == 2 && !awake.nowarning && awake.patchifnotexists == null,
                    "Awake must replace the inline progress dereference, rather than skip initialization or patch only the getter.");
            }
        });

        run("complete exact feed patches the inline Awake read while preserving its store and version call", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                SyntheticPe fixture = ExactFixture();
                byte[] expected = (byte[])fixture.Image.Clone();
                expected[SyntheticPe.TextRaw] = 0xC3;
                expected[SyntheticPe.TextRaw + 1] = 0x90;
                new byte[] { 0x33, 0xC0 }.CopyTo(expected, SyntheticPe.TextRaw + 0x160);
                new byte[] { 0xC3, 0x90 }.CopyTo(expected, SyntheticPe.TextRaw + 0x200);
                new byte[] { 0x90, 0x90, 0x90, 0xEB, 0x20 }.CopyTo(expected, SyntheticPe.TextRaw + 0x340);
                new byte[] { 0xC3, 0x90, 0x90 }.CopyTo(expected, SyntheticPe.TextRaw + 0x400);
                VersionRangeInfo selected = PatchTargetResolver.Resolve(feed, PatchTargetResolver.ComputeSha256(fixture.Image), new Version(13, 6, 9));
                fixture.CreatePatcher(selected).PatchGameAssembly();
                Check(fixture.Image.SequenceEqual(expected),
                    "The complete target changed bytes outside its five qualified spans, or left the Awake read intact.");
            }
        });

        run("duplicate Awake read rejects the entire selected exact feed without partial writes", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                SyntheticPe fixture = ExactFixture();
                fixture.Put(0x180, CapturedAwakeContext());
                RejectCompleteTargetUnchanged(feed, fixture);
            }
        });

        run("missing Awake context rejects the entire selected exact feed without partial writes", () =>
        {
            foreach (PatchInfo feed in LoadFeeds())
            {
                SyntheticPe fixture = ExactFixture();
                fixture.Image[SyntheticPe.TextRaw + 0x160] = 0x90;
                RejectCompleteTargetUnchanged(feed, fixture);
            }
        });
    }

    private static PatchInfo[] LoadFeeds()
    {
        string json = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "patchinfo.json"));
        return new[]
        {
            JsonConvert.DeserializeObject<PatchInfo>(json)!,
            System.Text.Json.JsonSerializer.Deserialize<PatchInfo>(json, MainForm.JsonOptions)!
        };
    }

    private static SyntheticPe ExactFixture()
    {
        var fixture = new SyntheticPe(
            new("LauncherCommunicator$$.cctor", 0, 0x100),
            new(AwakeName, 0x100, 0x100),
            new("LauncherAssetScanProgressBar$$Update", 0x200, 0x100),
            new("SimpleMenu.<StartLoad>d__10$$MoveNext", 0x300, 0x100),
            new("CentralAuth.CentralAuthManager$$Authentication", 0x400, 0x100));
        // Captured 13.6.9 instructions, including the following version-text call.
        // The extra copy in a neighboring method tests the named-method boundary.
        fixture.Put(0x15C, CapturedAwakeContext());
        fixture.Put(0x80, CapturedAwakeContext());
        fixture.Put(0x200, 0x40, 0x53, 0x48, 0x83, 0xEC, 0x40, 0x80, 0x3D, 0xC1, 0x59, 0x15, 0x03, 0,
            0x48, 0x8B, 0xD9, 0x0F, 0x29, 0x7C, 0x24, 0x20);
        fixture.Put(0x340, 0x80, 0x39, 0, 0x75, 0x20);
        fixture.Put(0x400, 0x48, 0x8B, 0xC4, 0x53, 0x56, 0x57, 0x41, 0x54, 0x41, 0x55, 0x41, 0x56, 0x41, 0x57, 0x48, 0x81, 0xEC);
        return fixture;
    }

    private static byte[] CapturedAwakeContext() => new byte[]
    {
        0x48, 0x8B, 0x48, 0x08, 0x8B, 0x01, 0x48, 0x8B, 0xCB, 0x89, 0x43, 0x38, 0xE8, 0x93, 0x01, 0, 0
    };

    private static void RejectCompleteTargetUnchanged(PatchInfo feed, SyntheticPe fixture)
    {
        byte[] original = (byte[])fixture.Image.Clone();
        VersionRangeInfo selected = PatchTargetResolver.Resolve(feed, PatchTargetResolver.ComputeSha256(original), new Version(13, 6, 9));
        try
        {
            fixture.CreatePatcher(selected).PatchGameAssembly();
        }
        catch (InvalidDataException)
        {
            Check(fixture.Image.SequenceEqual(original), "The selected complete exact target wrote a partial patch after Awake qualification failed.");
            return;
        }
        throw new Exception("The selected complete exact target accepted an absent or ambiguous required Awake pattern.");
    }

    private static bool Includes(VersionRangeInfo target, Version value)
    {
        Version lower = string.IsNullOrEmpty(target.versionFrom) ? new Version(0, 0, 0) : Version.Parse(target.versionFrom);
        Version? upper = string.IsNullOrEmpty(target.versionTo) || target.versionTo.Equals("Current", StringComparison.OrdinalIgnoreCase)
            ? null : Version.Parse(target.versionTo);
        return value >= lower && (upper == null || value <= upper);
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}
