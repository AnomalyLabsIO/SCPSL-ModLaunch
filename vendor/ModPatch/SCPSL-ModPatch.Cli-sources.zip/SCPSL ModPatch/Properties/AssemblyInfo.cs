using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("SCPSL.ModPatch.Tests")]
