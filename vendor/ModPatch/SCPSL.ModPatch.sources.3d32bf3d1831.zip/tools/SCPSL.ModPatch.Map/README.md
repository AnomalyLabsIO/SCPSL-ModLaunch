# Static IL2CPP method maps

Generate a symbol map from `GameAssembly.dll` and its matching `global-metadata.dat` for use with the [audit](../SCPSL.ModPatch.Audit/README.md), [disassembly](../SCPSL.ModPatch.Disasm/README.md), and [survey](../SCPSL.ModPatch.Survey/README.md) tools. Input files remain unchanged.

Run from the repository root with the .NET 10 SDK and .NET 6 Runtime installed:

```powershell
dotnet run --project tools/SCPSL.ModPatch.Map -- `
  --assembly C:\inspection\GameAssembly.dll `
  --metadata C:\inspection\global-metadata.dat `
  --metadata-version 31 `
  --expected-sha256 '<assembly SHA-256>' `
  --output C:\inspection\new-map
```

Use the DLL's SHA-256 and the `metadataVersion` from the matching profile in [patchinfo.json](../../Shared_Files/patchinfo.json). The output directory must be new or empty.

Keep the generated `script.json` and `map-provenance.json` together. The provenance record identifies the inputs and parser settings used to create the map.

## Optional arguments

| Option | Description |
| --- | --- |
| `--il2cpp-version VERSION` | Select a binary parser version instead of automatic selection. |
| `--attempt-report PATH` | Save diagnostics, including failed mapping attempts. |
| `--script-only true` | Keep only the symbol map and provenance record. |

## Batch mapping

With PowerShell 7, build the mapper in Release and provide an input index:

```powershell
dotnet build tools/SCPSL.ModPatch.Map -c Release
./tools/SCPSL.ModPatch.Map/Invoke-MetadataTrials.ps1 `
  -InputIndex C:\inspection\inputs.json `
  -OutputDirectory C:\inspection\maps
```

The index is a JSON array with `manifestId`, `assemblyPath`, `metadataPath`, `expectedSha256`, and `preferredMetadataVersion` for each build. The script tries parser settings and writes a `mapping-index.json` for batch surveys.

Optional: `-ManifestId ID1,ID2` selects builds; `-RetryFailures` retries failed entries.
