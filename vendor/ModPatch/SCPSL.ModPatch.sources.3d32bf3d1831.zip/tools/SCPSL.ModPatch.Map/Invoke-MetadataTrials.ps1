#requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string] $InputIndex,
    [Parameter(Mandatory)][string] $OutputDirectory,
    [string] $Mapper = (Join-Path $PSScriptRoot 'bin/Release/net6.0/SCPSL.ModPatch.Map.dll'),
    [ValidateRange(5, 600)][int] $TimeoutSeconds = 90,
    [string[]] $ManifestId = @(),
    [switch] $RetryFailures,
    [switch] $IgnoreExistingMaps
)
$ErrorActionPreference = 'Stop'
$InputIndex = [IO.Path]::GetFullPath($InputIndex)
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$Mapper = [IO.Path]::GetFullPath($Mapper)
if (!(Test-Path -LiteralPath $Mapper -PathType Leaf)) { throw "Build the mapper first: $Mapper" }
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

function Read-Property($Object, [string] $Name, $Default = $null) {
    $property = $Object.PSObject.Properties[$Name]
    if ($null -ne $property) { return $property.Value }
    return $Default
}
function Get-Hash([string] $Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Write-Json([string] $Path, $Value) {
    $temporary = $Path + '.new'
    ConvertTo-Json -InputObject $Value -Depth 30 | Set-Content -LiteralPath $temporary -Encoding utf8NoBOM
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}
function Test-Packed([string] $Path) {
    $stream = [IO.File]::OpenRead($Path)
    $reader = [IO.BinaryReader]::new($stream)
    try {
        if ($reader.ReadUInt16() -ne 0x5A4D) { return $false }
        $stream.Position = 0x3C
        $pe = $reader.ReadInt32()
        $stream.Position = $pe + 6
        $count = $reader.ReadUInt16()
        $stream.Position = $pe + 20
        $optional = $reader.ReadUInt16()
        for ($number = 0; $number -lt $count; $number++) {
            $stream.Position = $pe + 24 + $optional + 40 * $number
            $name = [Text.Encoding]::ASCII.GetString($reader.ReadBytes(8)).Trim([char]0)
            if ($name -match '^\.(themida|boot|vmp\d*)$') { return $true }
        }
        return $false
    } finally { $reader.Dispose(); $stream.Dispose() }
}
function Get-Trials([int] $Preferred, [int] $Reported) {
    $schemas = [Collections.Generic.List[int]]::new()
    foreach ($schema in @($Preferred, $Reported, 24, 27, 29, 31)) {
        if ($schema -in @(24, 27, 29, 31) -and !$schemas.Contains($schema)) { $schemas.Add($schema) }
    }
    foreach ($schema in $schemas) {
        [pscustomobject]@{ Schema = $schema; Force = $null }
        $versions = switch ($schema) {
            24 { @(24.3, 24.5, 24.4, 24.2, 24.1, 24) }
            27 { @(27.2, 27.1, 27) }
            29 { @(29.1, 29) }
            31 { @(31) }
        }
        foreach ($version in $versions) { [pscustomobject]@{ Schema = $schema; Force = $version } }
    }
}
function Get-ReusableMap([string[]] $Candidates, [string] $AssemblyHash, [string] $MetadataHash) {
    foreach ($candidate in $Candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
        $provenancePath = Join-Path $candidate 'map-provenance.json'
        $scriptPath = Join-Path $candidate 'script.json'
        if (!(Test-Path -LiteralPath $provenancePath) -or !(Test-Path -LiteralPath $scriptPath)) { continue }
        try {
            $provenance = Get-Content -LiteralPath $provenancePath -Raw | ConvertFrom-Json
            if ($provenance.assemblySha256 -ne $AssemblyHash -or
                $provenance.originalMetadataSha256 -ne $MetadataHash -or
                $provenance.scriptSha256 -ne (Get-Hash $scriptPath)) { continue }
            return [pscustomobject]@{ Directory = [IO.Path]::GetFullPath($candidate); Provenance = $provenance }
        } catch { Write-Warning "Cannot reuse $candidate`: $($_.Exception.Message)" }
    }
    return $null
}

$rows = @(Get-Content -LiteralPath $InputIndex -Raw | ConvertFrom-Json)
if ($ManifestId.Count -gt 0) { $rows = @($rows | Where-Object { $_.manifestId -in $ManifestId }) }
$results = [Collections.Generic.List[object]]::new()
$mapCache = @{}
foreach ($row in $rows) {
    $id = [string]$row.manifestId
    if ($id -notmatch '^\d+$') { throw "Invalid manifest ID: $id" }
    $rowOutput = Join-Path $OutputDirectory $id
    New-Item -ItemType Directory -Path $rowOutput -Force | Out-Null
    $resultPath = Join-Path $rowOutput 'trial-result.json'
    $assembly = [IO.Path]::GetFullPath([string]$row.assemblyPath)
    $metadata = [IO.Path]::GetFullPath([string]$row.metadataPath)
    $assemblyHash = Get-Hash $assembly
    $metadataHash = Get-Hash $metadata
    if ($assemblyHash -ne $row.expectedSha256) { throw "Assembly hash mismatch for manifest $id" }
    $expectedMetadataHash = Read-Property $row 'metadataSha256'
    if ($null -ne $expectedMetadataHash -and $metadataHash -ne $expectedMetadataHash) { throw "Metadata hash mismatch for manifest $id" }
    $cacheKey = $assemblyHash + ':' + $metadataHash
    $metadataStream = [IO.File]::OpenRead($metadata)
    try {
        $header = [byte[]]::new(8)
        if ($metadataStream.Read($header, 0, 8) -ne 8 -or [BitConverter]::ToUInt32($header, 0) -ne [uint32]4205910959) {
            throw "Invalid metadata header for manifest $id"
        }
        $reported = [BitConverter]::ToInt32($header, 4)
    } finally { $metadataStream.Dispose() }

    if (Test-Path -LiteralPath $resultPath) {
        $previous = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
        $previousMap = if ($previous.status -eq 'Mapped') { Get-ReusableMap @($previous.mapDirectory) $assemblyHash $metadataHash } else { $null }
        if (!$IgnoreExistingMaps -and $previous.assemblySha256 -eq $assemblyHash -and $previous.metadataSha256 -eq $metadataHash -and
            $previous.inputHashesUnchanged -eq $true -and ($previous.status -eq 'Mapped' -or !$RetryFailures)) {
            if ($previous.status -ne 'Mapped' -or $null -ne $previousMap) {
                $results.Add($previous)
                if ($previous.status -eq 'Mapped') { $mapCache[$cacheKey] = [pscustomobject]@{ Directory = $previous.mapDirectory; ManifestId = $id } }
                Write-Verbose "$id`: reused previous trial result ($($previous.status))."
                continue
            }
        }
    }
    $result = [ordered]@{
        manifestId = $id; assemblyPath = $assembly; metadataPath = $metadata
        assemblySha256 = $assemblyHash; metadataSha256 = $metadataHash
        sourceKind = (Read-Property $row 'sourceKind' 'original')
        reportedMetadataHeaderVersion = $reported; preferredMetadataVersion = [int]$row.preferredMetadataVersion
        status = 'Unmapped'; reused = $false; mapDirectory = $null
        normalizedMetadataHeaderVersion = $null; forcedIl2CppVersion = $null
        actualMetadataVersion = $null; actualIl2CppVersion = $null
        attemptedVersions = @(); inputHashesUnchanged = $false; createdUtc = [DateTimeOffset]::UtcNow
    }
    $cached = $mapCache[$cacheKey]
    $cachedDirectory = if ($null -ne $cached) { $cached.Directory } else { $null }
    $candidates = @((Read-Property $row 'reusedMapDirectory'), (Join-Path (Split-Path -Parent $assembly) 'symbols'), $cachedDirectory)
    $reuse = if ($IgnoreExistingMaps) { $null } else { Get-ReusableMap $candidates $assemblyHash $metadataHash }
    if ($null -ne $reuse) {
        $result.status = 'Mapped'; $result.reused = $true; $result.mapDirectory = $reuse.Directory
        $result.normalizedMetadataHeaderVersion = $reuse.Provenance.configuredMetadataVersion
        $result.forcedIl2CppVersion = Read-Property $reuse.Provenance 'forcedIl2CppVersion'
        $result.actualMetadataVersion = $reuse.Provenance.parserMetadataVersion
        $result.actualIl2CppVersion = $reuse.Provenance.il2CppParserVersion
        if ($null -ne $cached -and $reuse.Directory -eq $cached.Directory) { $result['reusedFromManifestId'] = $cached.ManifestId }
        $result['reuseValidation'] = 'Assembly, original metadata, and script SHA-256 match existing successful map provenance. Original map qualification remains applicable.'
    } elseif ($result.sourceKind -ne 'ReconstructedMemoryDump' -and (Test-Packed $assembly)) {
        $result.status = 'NeedsUnpack'
    } else {
        $attempts = [Collections.Generic.List[object]]::new()
        $failedMetadataSchemas = [Collections.Generic.HashSet[int]]::new()
        foreach ($trial in Get-Trials ([int]$row.preferredMetadataVersion) $reported) {
            # A forced binary parser cannot repair a metadata-table parse failure.
            if ($failedMetadataSchemas.Contains($trial.Schema)) { continue }
            $forceName = if ($null -eq $trial.Force) { 'auto' } else { ([double]$trial.Force).ToString('0.0', [Globalization.CultureInfo]::InvariantCulture) }
            $trialName = "$($trial.Schema)-$forceName"
            $trialDirectory = Join-Path $rowOutput "trials/$trialName"
            # Existing failed trials are kept intact. A retry gets a distinct directory.
            if (Test-Path -LiteralPath $trialDirectory) { $trialDirectory += '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8) }
            New-Item -ItemType Directory -Path $trialDirectory -Force | Out-Null
            $attemptReport = Join-Path $trialDirectory 'attempt.json'
            $symbols = Join-Path $trialDirectory 'symbols'
            $arguments = @($Mapper, '--assembly', $assembly, '--metadata', $metadata,
                '--metadata-version', [string]$trial.Schema, '--expected-sha256', $assemblyHash,
                '--output', $symbols, '--attempt-report', $attemptReport, '--script-only', 'true')
            if ($null -ne $trial.Force) { $arguments += @('--il2cpp-version', $forceName) }
            $start = [Diagnostics.ProcessStartInfo]::new('dotnet')
            $start.UseShellExecute = $false; $start.CreateNoWindow = $true
            $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
            foreach ($argument in $arguments) { $start.ArgumentList.Add($argument) }
            $process = [Diagnostics.Process]::new(); $process.StartInfo = $start
            $timer = [Diagnostics.Stopwatch]::StartNew()
            [void]$process.Start()
            $stdoutTask = $process.StandardOutput.ReadToEndAsync()
            $stderrTask = $process.StandardError.ReadToEndAsync()
            $timedOut = !$process.WaitForExit($TimeoutSeconds * 1000)
            if ($timedOut) {
                try { $process.Kill($true) }
                catch { if (!$process.HasExited) { throw } }
                $process.WaitForExit()
            }
            $stdoutTask.GetAwaiter().GetResult() | Set-Content -LiteralPath (Join-Path $trialDirectory 'stdout.log') -Encoding utf8NoBOM
            $stderr = $stderrTask.GetAwaiter().GetResult()
            $stderr | Set-Content -LiteralPath (Join-Path $trialDirectory 'stderr.log') -Encoding utf8NoBOM
            $attempt = [ordered]@{
                normalizedMetadataHeaderVersion = $trial.Schema; forcedIl2CppVersion = $trial.Force
                exitCode = $process.ExitCode; timedOut = $timedOut; elapsedSeconds = $timer.Elapsed.TotalSeconds
                reportPath = $attemptReport; outputDirectory = $symbols; error = $stderr.Trim()
                reportedMetadataHeaderVersion = $reported; actualMetadataVersion = $null; actualIl2CppVersion = $null
                stage = $(if ($timedOut) { 'process-timeout' } else { 'process-exit' }); success = $false
            }
            $process.Dispose()
            if (Test-Path -LiteralPath $attemptReport) {
                $details = Get-Content -LiteralPath $attemptReport -Raw | ConvertFrom-Json
                $attempt['reportedMetadataHeaderVersion'] = $details.reportedMetadataHeaderVersion
                $attempt['actualMetadataVersion'] = $details.actualMetadataVersion
                $attempt['actualIl2CppVersion'] = $details.actualIl2CppVersion
                $attempt['stage'] = $details.stage
                $attempt['success'] = $details.success
                if (!$details.success -and $details.stage -eq 'metadata-parse') { [void]$failedMetadataSchemas.Add($trial.Schema) }
            }
            $attempts.Add([pscustomobject]$attempt)
            if (!$timedOut -and $attempt.exitCode -eq 0 -and (Test-Path -LiteralPath (Join-Path $symbols 'map-provenance.json'))) {
                $result.status = 'Mapped'; $result.mapDirectory = $symbols
                $result.normalizedMetadataHeaderVersion = $trial.Schema; $result.forcedIl2CppVersion = $trial.Force
                $result.actualMetadataVersion = $details.actualMetadataVersion; $result.actualIl2CppVersion = $details.actualIl2CppVersion
                break
            }
        }
        $result.attemptedVersions = @($attempts.ToArray())
    }
    $result.inputHashesUnchanged = (Get-Hash $assembly) -eq $assemblyHash -and (Get-Hash $metadata) -eq $metadataHash
    if ($result.status -eq 'Mapped') { $mapCache[$cacheKey] = [pscustomobject]@{ Directory = $result.mapDirectory; ManifestId = $id } }
    Write-Json $resultPath $result
    $results.Add([pscustomobject]$result)
    Write-Json (Join-Path $OutputDirectory 'mapping-index.json') @($results.ToArray())
    if (!$result.inputHashesUnchanged) { throw "An input hash changed for manifest $id; batch stopped." }
    Write-Output "$id`: $($result.status); schema $($result.normalizedMetadataHeaderVersion), IL2CPP $($result.actualIl2CppVersion); $($result.attemptedVersions.Count) attempt(s), reused=$($result.reused)."
}
Write-Json (Join-Path $OutputDirectory 'mapping-index.json') @($results.ToArray())
