using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using Il2CppDumper;

internal static class Program
{
    private static readonly string[] RequiredArguments =
        { "assembly", "metadata", "metadata-version", "output", "expected-sha256" };
    private static readonly string[] OptionalArguments = { "il2cpp-version", "attempt-report", "script-only" };
    private static readonly double[] SupportedIl2CppVersions =
        { 24, 24.1, 24.2, 24.3, 24.4, 24.5, 27, 27.1, 27.2, 29, 29.1, 31 };

    private static int Main(string[] args)
    {
        var attempt = new MappingAttempt { StartedUtc = DateTimeOffset.UtcNow };
        string? reportPath = null;
        string? stagingDirectory = null;
        string? outputRoot = null;
        PE? binaryParser = null;
        try
        {
            Dictionary<string, string> options = ParseArguments(args);
            string assemblyPath = Path.GetFullPath(options["assembly"]);
            string metadataPath = Path.GetFullPath(options["metadata"]);
            string outputDirectory = Path.GetFullPath(options["output"]);
            outputRoot = outputDirectory;
            reportPath = options.TryGetValue("attempt-report", out string? report) ? Path.GetFullPath(report) : null;
            attempt.AssemblyPath = assemblyPath;
            attempt.MetadataPath = metadataPath;
            attempt.OutputDirectory = outputDirectory;
            bool scriptOnly = false;
            if (options.TryGetValue("script-only", out string? scriptOnlyText) && !bool.TryParse(scriptOnlyText, out scriptOnly))
                throw new ArgumentException("--script-only must be true or false.");
            if (!int.TryParse(options["metadata-version"], NumberStyles.None,
                    CultureInfo.InvariantCulture, out int configuredMetadataVersion) || configuredMetadataVersion <= 0)
                throw new ArgumentException("--metadata-version must be a positive integer from the selected patch-info range.");
            attempt.NormalizedMetadataHeaderVersion = configuredMetadataVersion;
            double? forcedIl2CppVersion = null;
            if (options.TryGetValue("il2cpp-version", out string? forceVersion))
            {
                if (!double.TryParse(forceVersion, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture,
                        out double parsedVersion) || !SupportedIl2CppVersions.Contains(parsedVersion))
                    throw new ArgumentException("--il2cpp-version must be a bundled parser version: 24 through 24.5, 27 through 27.2, 29, 29.1, or 31.");
                forcedIl2CppVersion = parsedVersion;
                attempt.ForcedIl2CppVersion = parsedVersion;
            }

            // Reserve only a fresh directory. Incomplete scripts remain private until validation succeeds.
            if (Directory.Exists(outputDirectory) && Directory.EnumerateFileSystemEntries(outputDirectory).Any())
                throw new InvalidDataException("The output directory must be new or empty.");

            byte[] image = File.ReadAllBytes(assemblyPath);
            byte[] assemblyHash = SHA256.HashData(image);
            attempt.AssemblySha256 = Convert.ToHexString(assemblyHash);
            byte[] expectedHash = Convert.FromHexString(options["expected-sha256"]);
            if (expectedHash.Length != 32 || !CryptographicOperations.FixedTimeEquals(expectedHash, assemblyHash))
                throw new InvalidDataException("The expected SHA-256 does not match the supplied assembly.");

            byte[] originalMetadata = File.ReadAllBytes(metadataPath);
            if (originalMetadata.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(originalMetadata) != 0xFAB11BAF)
                throw new InvalidDataException("The metadata input does not contain an IL2CPP metadata header.");
            int originalMetadataHeaderVersion = BinaryPrimitives.ReadInt32LittleEndian(originalMetadata.AsSpan(4, 4));
            string originalMetadataHash = Convert.ToHexString(SHA256.HashData(originalMetadata));
            attempt.ReportedMetadataHeaderVersion = originalMetadataHeaderVersion;
            attempt.MetadataSha256 = originalMetadataHash;

            // Only this private parser buffer is normalized. The supplied metadata is never opened for writing.
            byte[] parserMetadata = (byte[])originalMetadata.Clone();
            BinaryPrimitives.WriteInt32LittleEndian(parserMetadata.AsSpan(4, 4), configuredMetadataVersion);
            // Il2CppDumper's BinaryStream requires writable memory even for static parsing.
            // These streams have no filesystem backing; the assembly buffer is hash-checked below.
            using var metadataStream = new MemoryStream(parserMetadata, writable: true);
            using var assemblyStream = new MemoryStream(image, writable: true);
            attempt.Stage = "metadata-parse";
            var metadata = new Metadata(metadataStream);
            attempt.ActualMetadataVersion = metadata.Version;
            ValidateMetadata(metadata, parserMetadata);
            attempt.TypeCount = metadata.typeDefs.Length;
            attempt.MethodCount = metadata.methodDefs.Length;
            attempt.Stage = "registration-search";
            var il2Cpp = new PE(assemblyStream);
            binaryParser = il2Cpp;
            il2Cpp.SetProperties(forcedIl2CppVersion ?? metadata.Version, metadata.metadataUsagesCount);

            bool found = il2Cpp.PlusSearch(metadata.methodDefs.Count(method => method.methodIndex >= 0),
                metadata.typeDefs.Length, metadata.imageDefs.Length);
            if (!found)
                found = il2Cpp.Search();
            if (!found)
                found = il2Cpp.SymbolSearch();
            if (!found)
                throw new InvalidDataException("Automatic IL2CPP registration search failed. No manual input, binary loading, or unpacking is attempted.");
            attempt.ActualIl2CppVersion = il2Cpp.Version;

            Directory.CreateDirectory(outputDirectory);
            stagingDirectory = Path.Combine(outputDirectory, ".pending-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDirectory);
            attempt.Stage = "script-generation";
            var executor = new Il2CppExecutor(metadata, il2Cpp);
            var generator = new StructGenerator(executor);
            generator.WriteScript(stagingDirectory + Path.DirectorySeparatorChar);

            string stagedScriptPath = Path.Combine(stagingDirectory, "script.json");
            if (!File.Exists(stagedScriptPath))
                throw new InvalidDataException("IL2CPP mapping did not produce script.json.");
            attempt.Stage = "script-validation";
            attempt.DiscoveredTargets = ValidateScript(stagedScriptPath, image);
            if (!CryptographicOperations.FixedTimeEquals(assemblyHash, SHA256.HashData(image)))
                throw new InvalidDataException("The parser changed its in-memory assembly buffer; the map cannot be bound to the input.");

            // Hash the disk inputs again before recording successful provenance.
            if (!string.Equals(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assemblyPath))),
                    Convert.ToHexString(assemblyHash), StringComparison.Ordinal) ||
                !string.Equals(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(metadataPath))),
                    originalMetadataHash, StringComparison.Ordinal))
                throw new InvalidDataException("An input file changed during mapping; no successful provenance was recorded.");

            string scriptPath = Path.Combine(outputDirectory, "script.json");
            var provenance = new
            {
                MapFormatVersion = 2,
                CreatedUtc = DateTimeOffset.UtcNow,
                AssemblyPath = assemblyPath,
                AssemblySha256 = Convert.ToHexString(assemblyHash),
                AssemblySize = image.Length,
                MetadataPath = metadataPath,
                OriginalMetadataSha256 = originalMetadataHash,
                OriginalMetadataSize = originalMetadata.Length,
                OriginalMetadataHeaderVersion = originalMetadataHeaderVersion,
                ConfiguredMetadataVersion = configuredMetadataVersion,
                ForcedIl2CppVersion = forcedIl2CppVersion,
                ParserMetadataVersion = metadata.Version,
                Il2CppParserVersion = il2Cpp.Version,
                ScriptPath = scriptPath,
                ScriptSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(stagedScriptPath))),
                StructuralValidation = "Metadata string and table bounds, method/type ownership, mapped executable PE addresses, and discovery of a known authentication target passed.",
                DiscoveredTargets = attempt.DiscoveredTargets,
                SymbolAddressConvention = "ScriptMethod.Address is an RVA for this PE image.",
                MetadataNormalization = "Only the private parser copy at bytes 4-7 was normalized to the configured schema version; input files were not modified.",
                Scope = "Static registration discovery and symbol mapping only; no game code was executed and no game version or runtime compatibility is established."
            };
            File.WriteAllText(Path.Combine(stagingDirectory, "map-provenance.json"),
                JsonSerializer.Serialize(provenance, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                }) + Environment.NewLine);
            if (scriptOnly)
                foreach (string supportingFile in Directory.EnumerateFiles(stagingDirectory))
                    if (Path.GetFileName(supportingFile) is not ("script.json" or "map-provenance.json"))
                        File.Delete(supportingFile);
            foreach (string stagedFile in Directory.EnumerateFiles(stagingDirectory))
                File.Move(stagedFile, Path.Combine(outputDirectory, Path.GetFileName(stagedFile)));
            foreach (string stagedChild in Directory.EnumerateDirectories(stagingDirectory))
                Directory.Move(stagedChild, Path.Combine(outputDirectory, Path.GetFileName(stagedChild)));
            Directory.Delete(stagingDirectory);
            stagingDirectory = null;
            attempt.Stage = "complete";
            attempt.Success = true;
            Console.WriteLine($"Generated hash-bound method map: {scriptPath}");
            return 0;
        }
        catch (Exception ex)
        {
            attempt.ErrorType = ex.GetType().FullName;
            attempt.Error = ex.Message;
            Console.Error.WriteLine($"Mapping failed: {ex.Message}");
            return 1;
        }
        finally
        {
            // This path was just created by this process under its fresh output directory.
            if (stagingDirectory != null && Directory.Exists(stagingDirectory) &&
                string.Equals(Path.GetDirectoryName(Path.GetFullPath(stagingDirectory)), outputRoot, StringComparison.OrdinalIgnoreCase) &&
                Path.GetFileName(stagingDirectory).StartsWith(".pending-", StringComparison.Ordinal))
                Directory.Delete(stagingDirectory, recursive: true);
            attempt.CompletedUtc = DateTimeOffset.UtcNow;
            if (binaryParser != null)
                attempt.ActualIl2CppVersion = binaryParser.Version;
            if (reportPath != null)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(reportPath)!);
                File.WriteAllText(reportPath, JsonSerializer.Serialize(attempt, JsonOptions) + Environment.NewLine);
            }
        }
    }

    private static readonly JsonSerializerOptions JsonOptions = new()
        { WriteIndented = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

    private static void ValidateMetadata(Metadata metadata, byte[] bytes)
    {
        if (metadata.imageDefs.Length == 0 || metadata.typeDefs.Length < 100 || metadata.methodDefs.Length < 100)
            throw new InvalidDataException("Metadata tables are too small for a supported game build.");
        ulong stringsStart = metadata.header.stringOffset;
        ulong stringsSize = (ulong)metadata.header.stringSize;
        if (stringsSize == 0 || stringsStart + stringsSize > (ulong)bytes.Length)
            throw new InvalidDataException("Metadata string table is outside the input.");
        void ValidateName(uint index)
        {
            if (index >= stringsSize || Array.IndexOf(bytes, (byte)0, checked((int)(stringsStart + index)),
                    checked((int)(stringsSize - index))) < 0)
                throw new InvalidDataException("A metadata name is outside the terminated string table.");
        }
        foreach (var definition in metadata.imageDefs)
        {
            ValidateName(definition.nameIndex);
            if (definition.typeStart < 0 || (long)definition.typeStart + definition.typeCount > metadata.typeDefs.Length)
                throw new InvalidDataException("An image's type range is outside the type table.");
        }
        for (int typeIndex = 0; typeIndex < metadata.typeDefs.Length; typeIndex++)
        {
            var definition = metadata.typeDefs[typeIndex];
            ValidateName(definition.nameIndex);
            ValidateName(definition.namespaceIndex);
            if (definition.method_count == 0)
                continue;
            if (definition.methodStart < 0 || (long)definition.methodStart + definition.method_count > metadata.methodDefs.Length)
                throw new InvalidDataException("A type's method range is outside the method table.");
            for (int index = definition.methodStart; index < definition.methodStart + definition.method_count; index++)
                if (metadata.methodDefs[index].declaringType != typeIndex)
                    throw new InvalidDataException("Metadata method ownership does not match the type table.");
        }
        foreach (var definition in metadata.methodDefs)
        {
            ValidateName(definition.nameIndex);
            if (definition.declaringType < 0 || definition.declaringType >= metadata.typeDefs.Length ||
                (definition.token & 0xFF000000) != 0x06000000 ||
                (definition.parameterCount > 0 && (definition.parameterStart < 0 ||
                    (long)definition.parameterStart + definition.parameterCount > metadata.parameterDefs.Length)))
                throw new InvalidDataException("A method contains implausible type, token, or parameter references.");
        }
    }

    private static string[] ValidateScript(string scriptPath, byte[] image)
    {
        int pe = BinaryPrimitives.ReadInt32LittleEndian(image.AsSpan(0x3c, 4));
        int sectionCount = BinaryPrimitives.ReadUInt16LittleEndian(image.AsSpan(pe + 6, 2));
        int optionalSize = BinaryPrimitives.ReadUInt16LittleEndian(image.AsSpan(pe + 20, 2));
        var executableRanges = new List<(ulong Start, ulong End)>();
        for (int index = 0; index < sectionCount; index++)
        {
            int section = pe + 24 + optionalSize + 40 * index;
            uint characteristics = BinaryPrimitives.ReadUInt32LittleEndian(image.AsSpan(section + 36, 4));
            uint rawSize = BinaryPrimitives.ReadUInt32LittleEndian(image.AsSpan(section + 16, 4));
            uint rawOffset = BinaryPrimitives.ReadUInt32LittleEndian(image.AsSpan(section + 20, 4));
            uint rva = BinaryPrimitives.ReadUInt32LittleEndian(image.AsSpan(section + 12, 4));
            if ((characteristics & 0x20000000) != 0 && rawSize != 0 && (ulong)rawOffset + rawSize <= (ulong)image.Length)
                executableRanges.Add((rva, (ulong)rva + rawSize));
        }
        bool IsExecutable(ulong address) => executableRanges.Any(range => address >= range.Start && address < range.End);
        using JsonDocument script = JsonDocument.Parse(File.ReadAllBytes(scriptPath));
        int mapped = 0;
        int executable = 0;
        var targets = new HashSet<string>(StringComparer.Ordinal);
        string[] knownTargets = { "CentralAuthManager$$Authentication", "CentralAuth.CentralAuthManager$$Authentication",
            "GameCore.Version$$.cctor", "VersionCheck$$.cctor", "LauncherCommunicator$$.cctor",
            "LauncherAssetScanProgressBar$$Update" };
        foreach (JsonElement method in script.RootElement.GetProperty("ScriptMethod").EnumerateArray())
        {
            ulong address = method.GetProperty("Address").GetUInt64();
            if (address == 0)
                continue;
            mapped++;
            bool isExecutable = IsExecutable(address);
            if (isExecutable)
                executable++;
            string name = method.GetProperty("Name").GetString() ?? "";
            if (knownTargets.Contains(name, StringComparer.Ordinal) ||
                (name.StartsWith("SimpleMenu.<StartLoad>", StringComparison.Ordinal) && name.EndsWith("$$MoveNext", StringComparison.Ordinal)))
            {
                if (!isExecutable)
                    throw new InvalidDataException($"Target method {name} does not map to raw-backed executable code.");
                targets.Add(name);
            }
        }
        if (mapped < 100 || executable < mapped * 0.95)
            throw new InvalidDataException($"Only {executable} of {mapped} mapped methods lie in raw-backed executable PE sections.");
        if (!targets.Contains("CentralAuthManager$$Authentication") && !targets.Contains("CentralAuth.CentralAuthManager$$Authentication"))
            throw new InvalidDataException("No known authentication target was discovered in executable code.");
        return targets.OrderBy(name => name, StringComparer.Ordinal).ToArray();
    }

    private sealed class MappingAttempt
    {
        public DateTimeOffset StartedUtc { get; set; }
        public DateTimeOffset CompletedUtc { get; set; }
        public string? AssemblyPath { get; set; }
        public string? MetadataPath { get; set; }
        public string? OutputDirectory { get; set; }
        public string? AssemblySha256 { get; set; }
        public string? MetadataSha256 { get; set; }
        public int? ReportedMetadataHeaderVersion { get; set; }
        public int? NormalizedMetadataHeaderVersion { get; set; }
        public double? ForcedIl2CppVersion { get; set; }
        public double? ActualMetadataVersion { get; set; }
        public double? ActualIl2CppVersion { get; set; }
        public int? TypeCount { get; set; }
        public int? MethodCount { get; set; }
        public string[]? DiscoveredTargets { get; set; }
        public string Stage { get; set; } = "input-validation";
        public bool Success { get; set; }
        public string? ErrorType { get; set; }
        public string? Error { get; set; }
    }

    private static Dictionary<string, string> ParseArguments(string[] args)
    {
        var options = new Dictionary<string, string>(StringComparer.Ordinal);
        if (args.Length == 1 && (args[0] == "--help" || args[0] == "-h"))
            throw new ArgumentException("Usage: --assembly PATH --metadata PATH --metadata-version INT --output EMPTY_DIRECTORY --expected-sha256 HEX [--il2cpp-version DOUBLE] [--attempt-report PATH] [--script-only true|false]");
        for (int index = 0; index < args.Length; index += 2)
        {
            if (!args[index].StartsWith("--", StringComparison.Ordinal) || index + 1 >= args.Length)
                throw new ArgumentException("Arguments must be --name value pairs.");
            string name = args[index][2..];
            if ((!RequiredArguments.Contains(name, StringComparer.Ordinal) && !OptionalArguments.Contains(name, StringComparer.Ordinal)) ||
                string.IsNullOrWhiteSpace(args[index + 1]) || !options.TryAdd(name, args[index + 1]))
                throw new ArgumentException($"Unknown, empty, or repeated argument: --{name}.");
        }
        foreach (string required in RequiredArguments)
            if (!options.ContainsKey(required))
                throw new ArgumentException($"Missing required argument: --{required}.");
        return options;
    }
}
