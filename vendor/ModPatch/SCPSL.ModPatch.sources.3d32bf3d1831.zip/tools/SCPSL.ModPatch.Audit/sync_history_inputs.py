"""Join completed downloads and isolated-unpack results for static parser trials."""
import argparse
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--audit-root", type=Path, default=ROOT / "artifacts/history-audit")
args = parser.parse_args()
AUDIT = args.audit_root.resolve()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else []


def hash_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def lower_keys(row):
    return {key.lower(): value for key, value in row.items()}


downloads = read(AUDIT / "downloads.json")
unpacked = {str(row["manifestid"]): row for row in map(lower_keys, read(AUDIT / "unpack/index.json"))}
rows, waiting = [], []
for download in downloads:
    mid = str(download["manifestId"])
    if download["exitCode"] != 0:
        waiting.append({"manifestId": mid, "status": "DownloadFailed"})
        continue
    unpack = unpacked.get(mid)
    if not unpack or unpack.get("status") not in ("Plain", "Unpacked"):
        waiting.append({"manifestId": mid, "status": unpack.get("status") if unpack else "AwaitingUnpackInspection"})
        continue
    source_hash = download["assemblySha256"]
    metadata_hash = download["metadataSha256"]
    if unpack["sourceassemblysha256"].upper() != source_hash.upper() or unpack["metadatasha256"].upper() != metadata_hash.upper():
        raise ValueError(f"Unpack provenance does not match the completed download for {mid}")
    image_path = Path(unpack["effectiveassemblypath"])
    expected_hash = unpack["effectiveassemblysha256"]
    if hash_file(image_path) != expected_hash.upper():
        raise ValueError(f"Effective DLL hash changed for {mid}")
    reuse = unpack.get("reusedmapdirectory")
    if not reuse:
        candidate = Path(download["assemblyPath"]).parent / "symbols"
        provenance_path = candidate / "map-provenance.json"
        if provenance_path.exists():
            provenance = read(provenance_path)
            if provenance.get("assemblySha256", "").upper() == expected_hash.upper() and provenance.get("originalMetadataSha256", "").upper() == metadata_hash.upper():
                reuse = str(candidate)
    rows.append({
        "manifestId": mid,
        "seenUtc": download["seenUtc"],
        "assemblyPath": str(image_path),
        "metadataPath": download["metadataPath"],
        "expectedSha256": expected_hash,
        "metadataSha256": metadata_hash,
        "preferredMetadataVersion": download["preferredMetadataVersion"],
        "sourceKind": unpack["provenancekind"],
        "sourceAssemblyPath": download["assemblyPath"],
        "sourceAssemblySha256": source_hash,
        "unpackResultPath": unpack.get("unpackresultpath"),
        "reusedMapDirectory": reuse,
    })

for name, value in (("effective-inputs.json", rows), ("waiting-inputs.json", waiting)):
    target = AUDIT / name
    temporary = target.with_suffix(target.suffix + ".next")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, target)
print(json.dumps({"completedDownloads": len(downloads), "readyForMapping": len(rows), "waiting": len(waiting)}))
