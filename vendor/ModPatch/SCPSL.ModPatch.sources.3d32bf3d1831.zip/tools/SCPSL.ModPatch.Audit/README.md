# Read-only binary audit

Inspect original patch bytes and check whether byte patterns match uniquely within IL2CPP methods. This tool reads the DLL without modifying it.

Run from the repository root with the .NET 10 SDK and .NET 6 Runtime installed:

```powershell
dotnet run --project tools/SCPSL.ModPatch.Audit -- `
  --assembly C:\inspection\GameAssembly.dll `
  --script C:\inspection\script.json `
  --patchinfo Shared_Files\patchinfo.json `
  --range '14.1.3 – Current' `
  --expected-sha256 '<assembly SHA-256>'
```

Use a matching [RVA symbol map](../SCPSL.ModPatch.Map/README.md), the DLL's SHA-256, and an exact profile label from the patch definitions.

The JSON report prints to the console and includes patch bytes, pattern matches, version observations, and inspection errors. Review those errors before updating patch definitions.

## Optional arguments

| Option | Description |
| --- | --- |
| `--output PATH` | Save the JSON report to a file. |
| `--method NAME --pattern BYTES` | Test a candidate pattern within one method. Supply both arguments. |
| `--map-provenance PATH` | Verify inputs against the mapper's provenance record. |
| `--manifest-id ID` | Associate the report with a Steam manifest. Requires `--map-provenance`. |
