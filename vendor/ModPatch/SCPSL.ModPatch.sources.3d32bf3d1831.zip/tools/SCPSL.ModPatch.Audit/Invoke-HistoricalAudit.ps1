param([switch]$Force, [switch]$PatternFeed)

$ErrorActionPreference = 'Stop'
$repositoryPath = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Push-Location -LiteralPath $repositoryPath
try {
    $auditDll = Join-Path $PSScriptRoot 'bin\Release\net6.0\SCPSL.ModPatch.Audit.dll'
    $auditRoot = Join-Path $repositoryPath 'artifacts\historical-audit'
    $downloadRows = Get-Content -LiteralPath (Join-Path $auditRoot 'downloads.json') -Raw | ConvertFrom-Json
    $mappingRows = Get-Content -LiteralPath (Join-Path $auditRoot 'mapping-results.json') -Raw | ConvertFrom-Json
    $manifestPath = if ($PatternFeed) { 'Shared_Files\patchinfo.json' } else { 'tests\SCPSL.ModPatch.Tests\Fixtures\legacy-patchinfo.json' }
    $manifestDefinition = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $prefix = if ($PatternFeed) { 'pattern' } else { 'steam' }
    $indexPath = Join-Path $auditRoot ($prefix + '-audit-index.json')
    $verifiedRows = @()
    if ($PatternFeed) {
        $verifiedRows = @(Get-Content -LiteralPath (Join-Path $auditRoot 'steam-audit-index.json') -Raw | ConvertFrom-Json)
    }
    $auditRows = @()
    if (Test-Path -LiteralPath $indexPath) {
        $auditRows = @(Get-Content -LiteralPath $indexPath -Raw | ConvertFrom-Json)
    }

    foreach ($mapping in $mappingRows) {
        if ($mapping.exitCode -ne 0) { continue }
        $manifestId = $mapping.manifestId
        if (-not $Force -and ($auditRows | Where-Object { $_.manifestId -eq $manifestId -and $_.exitCode -eq 0 })) { continue }
        $download = $downloadRows | Where-Object { $_.manifestId -eq $manifestId }
        $imageFile = $download.files | Where-Object { $_.path -like '*\GameAssembly.dll' }
        if (@($imageFile).Count -ne 1) { throw "Expected one downloaded assembly for manifest $manifestId." }

        # The expected release selects the parser schema. Only decoded DLL bytes establish the observed version.
        $expected = $mapping.expectedVersion
        if ($PatternFeed) {
            $verified = $verifiedRows | Where-Object { $_.manifestId -eq $manifestId }
            $ranges = @($manifestDefinition.versionRanges | Where-Object {
                $_.gameAssemblySha256 -and $_.gameAssemblySha256 -eq $imageFile.sha256
            })
            if ($ranges.Count -eq 0) {
                if (-not $verified.verifiedVersion) { continue }
                $actualVersion = [Version]$verified.verifiedVersion
                $ranges = @($manifestDefinition.versionRanges | Where-Object {
                    $_.version -and [Version]$_.version -eq $actualVersion
                })
                if ($ranges.Count -eq 0) {
                    $ranges = @($manifestDefinition.versionRanges | Where-Object {
                        -not $_.gameAssemblySha256 -and -not $_.version -and
                        (-not $_.versionFrom -or $actualVersion -ge [Version]$_.versionFrom) -and
                        (-not $_.versionTo -or $_.versionTo -eq 'Current' -or $actualVersion -le [Version]$_.versionTo)
                    })
                }
            }
            if ($ranges.Count -ne 1) { throw "The original DLL has no unique patch-info target: $manifestId." }
            $rangeLabel = $ranges[0].versionRange
        }
        else {
            $rangeLabel = if ($expected -eq 'Current' -or [Version]$expected -ge [Version]'14.1.0') { '14.1.0 – Current' }
            elseif ([Version]$expected -ge [Version]'13.6.9') { '13.6.9 – 14.0.3' }
            elseif ([Version]$expected -ge [Version]'13.0.0') { '13.0.0 – 13.5.1' }
            elseif ([Version]$expected -ge [Version]'11.1.5') { '11.1.5 – 12.0.2' }
            else { '10.1.0 – 11.1.4' }
        }
        $selectedRange = $manifestDefinition.versionRanges | Where-Object { $_.versionRange -eq $rangeLabel }
        $probeMethod = $selectedRange.methods.patchMethods | Where-Object { $_.name -like '*StartLoad*' } |
            Select-Object -First 1 -ExpandProperty name
        $reportPath = Join-Path $auditRoot ($prefix + '-' + $manifestId + '.json')
        $logPath = Join-Path $auditRoot ($prefix + '-' + $manifestId + '.log')
        $auditArguments = @('--assembly', $imageFile.path, '--script', (Join-Path $mapping.outputPath 'script.json'),
            '--patchinfo', $manifestPath, '--range', $rangeLabel, '--expected-sha256', $imageFile.sha256,
            '--manifest-id', $manifestId, '--map-provenance', (Join-Path $mapping.outputPath 'map-provenance.json'),
            '--output', $reportPath)
        if ($probeMethod) {
            $auditArguments += @('--method', $probeMethod, '--pattern', '48 8B 80 B8 00 00 00 48 8B 48 08 8B 01')
        }
        & dotnet $auditDll @auditArguments *> $logPath
        $auditExit = $LASTEXITCODE
        $verifiedVersion = $null
        $versionType = $null
        $patchErrors = @()
        $patternCount = 0
        if ($auditExit -eq 0) {
            $report = Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
            $verifiedVersion = $report.Version.VerifiedVersion
            $versionType = $report.Version.VersionTypeByte
            $patchErrors = @($report.Patches | Where-Object { $_.Error } | ForEach-Object { $_.Method + ': ' + $_.Error })
            $patternCount = @($report.Patches | Where-Object { $_.ConfiguredPatchPattern }).Count
        }
        $auditRows = @($auditRows | Where-Object { $_.manifestId -ne $manifestId })
        $auditRows += [PSCustomObject]@{ manifestId = $manifestId; expectedVersion = $expected; range = $rangeLabel;
            exitCode = $auditExit; verifiedVersion = $verifiedVersion; versionTypeByte = $versionType;
            patternChecks = $patternCount; patchErrors = $patchErrors;
            reportPath = $reportPath; logPath = $logPath }
        ConvertTo-Json -InputObject $auditRows -Depth 5 | Set-Content -LiteralPath $indexPath
        Write-Output "Manifest ${manifestId}: exit=$auditExit, verified=$verifiedVersion, type=$versionType"
    }
}
finally {
    Pop-Location
}
