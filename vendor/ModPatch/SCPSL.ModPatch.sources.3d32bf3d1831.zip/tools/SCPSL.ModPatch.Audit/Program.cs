using System.Buffers.Binary;
using System.Globalization;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
using Newtonsoft.Json;
using SCPSL_ModPatch.PatchUtils;

internal static class Program
{
    private static readonly string[] RequiredArguments =
        { "assembly", "script", "patchinfo", "range", "expected-sha256" };
    private static readonly JsonSerializerOptions OutputOptions = new() { WriteIndented = true };

    private static int Main(string[] args)
    {
        try
        {
            Dictionary<string, string> options = ParseArguments(args);
            string assemblyPath = Path.GetFullPath(options["assembly"]);
            string scriptPath = Path.GetFullPath(options["script"]);
            string patchInfoPath = Path.GetFullPath(options["patchinfo"]);
            byte[] image = File.ReadAllBytes(assemblyPath);
            string assemblyHash = Convert.ToHexString(SHA256.HashData(image));
            string scriptHash = HashFile(scriptPath);
            byte[] expectedHash = Convert.FromHexString(options["expected-sha256"]);
            if (expectedHash.Length != 32 || !CryptographicOperations.FixedTimeEquals(
                    expectedHash, Convert.FromHexString(assemblyHash)))
                throw new InvalidDataException("The expected SHA-256 does not match the supplied assembly.");

            PatchInfo patchInfo = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(patchInfoPath))
                ?? throw new InvalidDataException("The patch-info file is null.");
            PatchTargetResolver.Validate(patchInfo);
            VersionRangeInfo[] matchingRanges = (patchInfo.versionRanges ?? Array.Empty<VersionRangeInfo>())
                .Where(range => range != null && string.Equals(range.versionRange, options["range"], StringComparison.Ordinal))
                .ToArray();
            if (matchingRanges.Length != 1)
                throw new InvalidDataException("The range label must identify exactly one patch-info range.");
            VersionRangeInfo range = matchingRanges[0];
            if (range.methods == null || range.methods.patchMethods == null)
                throw new InvalidDataException("The selected range has no methods definition.");

            string? manifestId = options.GetValueOrDefault("manifest-id");
            if (manifestId != null && (!ulong.TryParse(manifestId, NumberStyles.None,
                    CultureInfo.InvariantCulture, out ulong numericManifestId) || numericManifestId == 0))
                throw new ArgumentException("--manifest-id must be a positive decimal Steam manifest ID.");
            string? provenancePath = options.TryGetValue("map-provenance", out string? suppliedProvenance)
                ? Path.GetFullPath(suppliedProvenance) : null;
            if (manifestId != null && provenancePath == null)
                throw new ArgumentException("--manifest-id requires --map-provenance with matching assembly and symbol hashes.");
            object? provenance = provenancePath != null
                ? ValidateMapProvenance(provenancePath, assemblyHash, scriptHash, range.metadataVersion) : null;

            Dictionary<string, HashSet<ulong>> symbols = ReadSymbols(scriptPath);
            if (!string.Equals(scriptHash, HashFile(scriptPath), StringComparison.Ordinal))
                throw new InvalidDataException("The symbol map changed during inspection.");
            var nativeMap = new NativeMethodMap(image);
            using var imageStream = new MemoryStream(image, writable: false);
            using var peReader = new PEReader(imageStream);
            SectionHeader[] sections = peReader.PEHeaders.SectionHeaders.ToArray();

            MethodLocation ResolveMethod(string name)
            {
                if (!symbols.TryGetValue(name, out HashSet<ulong>? addresses) || addresses.Count == 0)
                    throw new InvalidDataException($"Method ({name}) is absent from the supplied symbol map.");
                if (addresses.Count != 1)
                    throw new InvalidDataException($"Method ({name}) has {addresses.Count} distinct symbol RVAs; refusing to choose one.");
                ulong rva = addresses.Single();
                int rawOffset = MapRvaToRaw(rva, sections, image.Length);
                return new MethodLocation(name, rva, nativeMap.GetMethodRange(rawOffset));
            }

            object version = AuditVersion(range.methods.gameVersionMethod, image, ResolveMethod);
            var patchReports = new List<object>();
            foreach (PatchMethodInfo patch in range.methods.patchMethods)
                patchReports.Add(AuditPatch(patch, image, symbols, ResolveMethod));

            object? suppliedProbe = null;
            if (options.TryGetValue("pattern", out string? pattern))
            {
                string methodName = options["method"];
                try
                {
                    MethodLocation method = ResolveMethod(methodName);
                    suppliedProbe = new { Method = methodName, Location = DescribeMethod(method),
                        Probe = Probe(pattern, image.AsSpan(method.Range.Offset, method.Range.Length), method.Range.Offset) };
                }
                catch (Exception ex) when (IsInspectionError(ex))
                {
                    suppliedProbe = new { Method = methodName, Pattern = pattern, Error = ex.Message };
                }
            }

            var report = new
            {
                AuditFormatVersion = 1,
                CreatedUtc = DateTimeOffset.UtcNow,
                SourceKind = manifestId != null
                    ? "Downloaded Steam depot files; SHA256 verified and symbols generated from matching metadata."
                    : "Existing local offline files; not Steam downloads or verified Steam release baselines.",
                Steam = manifestId == null ? null : new { AppId = 700330, DepotId = 700331, ManifestId = manifestId,
                    ManifestBinding = "Manifest identity is supplied by the operator; map provenance verifies the inspected file hashes." },
                AssemblyPath = assemblyPath,
                AssemblySha256 = assemblyHash,
                AssemblySize = image.Length,
                ScriptPath = scriptPath,
                ScriptSha256 = scriptHash,
                MapProvenancePath = provenancePath,
                MapProvenance = provenance,
                SymbolAddressConvention = "ScriptMethod.Address must be an RVA, not a virtual address or raw file offset.",
                Binding = provenance != null ? "Assembly, symbol map, and metadata hashes match the static map-generation provenance."
                    : "The required expected assembly hash is the operator assertion that this symbol map belongs to this assembly; the tool does not independently prove map provenance.",
                AmbiguousSymbolNameCount = symbols.Count(pair => pair.Value.Count > 1),
                PatchInfoPath = patchInfoPath,
                PatchInfoSha256 = HashFile(patchInfoPath),
                Range = range.versionRange,
                RangeFrom = range.versionFrom,
                RangeTo = range.versionTo,
                TargetSelection = "Explicit profile inspection; automatic target selection was bypassed.",
                Version = version,
                Patches = patchReports,
                SuppliedPatternProbe = suppliedProbe,
                Acceptance = "Byte inspection of an explicitly selected profile only; not automatic target-selection qualification. This report does not establish release coverage, patch behavior, game startup, authentication, or network compatibility."
            };
            string json = System.Text.Json.JsonSerializer.Serialize(report, OutputOptions);
            if (options.TryGetValue("output", out string? output))
            {
                string outputPath = Path.GetFullPath(output);
                if (new[] { assemblyPath, scriptPath, patchInfoPath, provenancePath }.Any(input =>
                        string.Equals(input, outputPath, StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidDataException("The report output cannot overwrite an input file.");
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
                File.WriteAllText(outputPath, json + Environment.NewLine);
                Console.WriteLine($"Read-only audit report: {outputPath}");
            }
            else
                Console.WriteLine(json);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Audit failed: {ex.Message}");
            return 1;
        }
    }

    private static object ValidateMapProvenance(string path, string assemblyHash, string scriptHash, int metadataVersion)
    {
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(path));
        JsonElement root = document.RootElement;
        if (root.GetProperty("mapFormatVersion").GetInt32() is not (1 or 2))
            throw new InvalidDataException("The mapping provenance format is unsupported.");
        string recordedAssemblyHash = root.GetProperty("assemblySha256").GetString() ?? string.Empty;
        string recordedScriptHash = root.GetProperty("scriptSha256").GetString() ?? string.Empty;
        if (!HashesEqual(recordedAssemblyHash, assemblyHash) || !HashesEqual(recordedScriptHash, scriptHash))
            throw new InvalidDataException("The assembly or script hash does not match mapping provenance.");
        if (root.GetProperty("configuredMetadataVersion").GetInt32() != metadataVersion)
            throw new InvalidDataException("The selected range metadata version differs from mapping provenance.");
        string metadataPath = Path.GetFullPath(root.GetProperty("metadataPath").GetString()
            ?? throw new InvalidDataException("The mapping provenance metadata path is missing."));
        string metadataHash = HashFile(metadataPath);
        if (!HashesEqual(root.GetProperty("originalMetadataSha256").GetString() ?? string.Empty, metadataHash))
            throw new InvalidDataException("The metadata hash does not match mapping provenance.");
        return new
        {
            Path = path,
            Sha256 = HashFile(path),
            HashesVerified = true,
            AssemblySha256 = assemblyHash,
            ScriptSha256 = scriptHash,
            MetadataPath = metadataPath,
            OriginalMetadataSha256 = metadataHash,
            ConfiguredMetadataVersion = metadataVersion,
            OriginalMetadataHeaderVersion = root.GetProperty("originalMetadataHeaderVersion").GetInt32(),
            ParserMetadataVersion = root.GetProperty("parserMetadataVersion").GetDouble(),
            Il2CppParserVersion = root.GetProperty("il2CppParserVersion").GetDouble(),
            MetadataNormalization = root.GetProperty("metadataNormalization").GetString()
        };
    }

    private static bool HashesEqual(string first, string second)
    {
        byte[] left = Convert.FromHexString(first);
        byte[] right = Convert.FromHexString(second);
        return left.Length == 32 && right.Length == 32 && CryptographicOperations.FixedTimeEquals(left, right);
    }

    private static object AuditPatch(PatchMethodInfo patch, byte[] image,
        Dictionary<string, HashSet<ulong>> symbols, Func<string, MethodLocation> resolve)
    {
        if (patch == null)
            return new { Error = "The patch definition is null." };
        try
        {
            if (!string.IsNullOrEmpty(patch.patchifnotexists) && symbols.ContainsKey(patch.patchifnotexists))
                return new { Method = patch.name, Status = "Skipped by patchifnotexists", Condition = patch.patchifnotexists };
            if (patch.nowarning && !symbols.ContainsKey(patch.name))
                return new { Method = patch.name, Status = "Optional method absent (nowarning)" };
            MethodLocation method = resolve(patch.name);
            int patchSize = patch.patchSize ?? PatchDataLength(patch.patchData);
            if (patchSize <= 0)
                throw new InvalidDataException("The patch size must be positive for byte inspection.");
            int relativeOffset;
            if (patch.patchPattern != null)
            {
                if (patch.patchOffset != null)
                    throw new InvalidDataException("patchPattern and patchOffset cannot both be specified.");
                int found = BytePattern.Parse(patch.patchPattern).FindUniqueOffset(
                    image.AsSpan(method.Range.Offset, method.Range.Length));
                relativeOffset = checked(found + patch.patternOffset);
            }
            else
                relativeOffset = patch.patchOffset ?? 0;
            if (relativeOffset < 0 || relativeOffset > method.Range.Length - patchSize)
                throw new InvalidDataException("The configured patch span extends outside the authoritative native method range.");

            int rawOffset = checked(method.Range.Offset + relativeOffset);
            string original = Hex(image.AsSpan(rawOffset, patchSize));
            int contextStart = Math.Max(0, relativeOffset - 16);
            int contextEnd = (int)Math.Min(method.Range.Length, (long)relativeOffset + patchSize + 16);
            string candidate = patch.patchPattern ?? original;
            return new
            {
                Method = patch.name,
                Status = "Inspected original bytes only",
                Location = DescribeMethod(method),
                ConfiguredPatchOffset = patch.patchOffset,
                ConfiguredPatchPattern = patch.patchPattern,
                ConfiguredPatternOffset = patch.patternOffset,
                ConfiguredPatchData = patch.patchData,
                PatchSize = patchSize,
                OriginalRelativeOffset = relativeOffset,
                OriginalRawOffset = rawOffset,
                OriginalRawOffsetHex = $"0x{rawOffset:X}",
                OriginalBytes = original,
                ContextRelativeOffset = contextStart,
                ContextRawOffset = method.Range.Offset + contextStart,
                ContextBytes = Hex(image.AsSpan(method.Range.Offset + contextStart, contextEnd - contextStart)),
                CandidateSource = patch.patchPattern == null ? "Exact original patchSize bytes; candidate only, not a proposed manifest change." : "Explicit patchPattern from definition.",
                Candidate = Probe(candidate, image.AsSpan(method.Range.Offset, method.Range.Length), method.Range.Offset)
            };
        }
        catch (Exception ex) when (IsInspectionError(ex))
        {
            return new { Method = patch.name, ConfiguredPatchOffset = patch.patchOffset,
                ConfiguredPatchPattern = patch.patchPattern, ConfiguredPatchSize = patch.patchSize, Error = ex.Message };
        }
    }

    private static object AuditVersion(GameVersionMethodInfo? version, byte[] image, Func<string, MethodLocation> resolve)
    {
        if (version == null)
            return new { Status = "No gameVersionMethod is configured.", VerifiedVersion = (string?)null };
        try
        {
            MethodLocation method = resolve(version.name);
            int[] offsets = { version.majorOffset, version.minorOffset, version.revisionOffset, version.typeOffset };
            int[] fieldDisplacements = { 0, 1, 2, 4 };
            string[] fields = { "major", "minor", "revision", "type" };
            var observations = new List<object>();
            var values = new byte[4];
            bool plausible = true;
            string? baseRegister = null;
            ReadOnlySpan<byte> methodBytes = image.AsSpan(method.Range.Offset, method.Range.Length);
            for (int i = 0; i < offsets.Length; i++)
            {
                int offset = offsets[i];
                bool inside = offset >= 0 && offset < method.Range.Length;
                DecodedByteStore? store = inside ? DecodeVersionByteStore(methodBytes, offset, fieldDisplacements[i]) : null;
                if (inside && store == null && i == 3)
                    store = DecodeVersionByteStore(methodBytes, offset, 3); // Older layouts have no padding before type.
                bool immediateStore = store != null;
                if (store != null)
                {
                    baseRegister ??= store.BaseRegister;
                    plausible &= string.Equals(baseRegister, store.BaseRegister, StringComparison.Ordinal);
                }
                byte? value = inside ? image[method.Range.Offset + offset] : null;
                if (value != null)
                    values[i] = value.Value;
                plausible &= immediateStore;
                observations.Add(new { Field = fields[i], ConfiguredOffset = offset, InsideMethod = inside,
                    ObservedByte = value, ExpectedFieldDisplacements = i == 3 ? new[] { 3, 4 } : new[] { fieldDisplacements[i] },
                    MatchesImmediateByteStore = immediateStore, DecodedStore = store });
            }
            plausible &= values[0] > 0 && values[0] <= 99 && values[1] <= 99 && values[2] <= 99 && values[3] <= 8;
            AutoVersionObservation? automatic = version.autoFindOffsets
                ? AuditAutomaticVersion(image.AsSpan(method.Range.Offset, method.Range.Length)) : null;
            string? verifiedVersion = automatic?.VerifiedVersion ?? (plausible && !version.autoFindOffsets
                ? $"{values[0]}.{values[1]}.{values[2]}" : null);
            return new
            {
                Method = version.name,
                AutoFindOffsetsConfigured = version.autoFindOffsets,
                AutoFindOffsetsPerformed = version.autoFindOffsets,
                Location = DescribeMethod(method),
                ConfiguredOffsetObservations = observations,
                ConfiguredOffsetsPlausible = plausible,
                ConfiguredStoreBaseRegister = plausible ? baseRegister : null,
                AutomaticVersionSearch = automatic,
                VerifiedVersion = verifiedVersion,
                VersionTypeByte = automatic?.VersionTypeByte ?? (plausible && !version.autoFindOffsets ? (byte?)values[3] : null),
                Status = verifiedVersion != null ? "Version fields match bounded immediate byte stores; symbol provenance remains operator asserted."
                    : "Version stores were not identified safely; observed configured-offset bytes are not a verified game version."
            };
        }
        catch (Exception ex) when (IsInspectionError(ex))
        {
            return new { Method = version.name, AutoFindOffsetsConfigured = version.autoFindOffsets,
                AutoFindOffsetsPerformed = false, VerifiedVersion = (string?)null, Error = ex.Message };
        }
    }

    private static DecodedByteStore? DecodeVersionByteStore(ReadOnlySpan<byte> method, int valueOffset, int expectedDisplacement)
    {
        DecodedByteStore? result = null;
        string[] registerNames = { "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
            "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15" };
        for (int start = Math.Max(0, valueOffset - 8); start < valueOffset; start++)
        {
            int position = start;
            byte rex = 0;
            if (method[position] >= 0x40 && method[position] <= 0x4F)
            {
                rex = method[position++];
                if (position >= valueOffset)
                    continue;
            }
            else if (position > 0 && method[position - 1] >= 0x40 && method[position - 1] <= 0x4F)
                continue; // Treat a directly preceding REX byte as part of this instruction.
            if (method[position++] != 0xC6 || position >= valueOffset)
                continue;
            byte modRm = method[position++];
            int mode = modRm >> 6;
            int register = modRm & 7;
            if ((modRm & 0x38) != 0 || (rex & 4) != 0 || mode == 3)
                continue; // C6 /0, memory operand only.
            if (register == 4)
            {
                if (position >= valueOffset)
                    continue;
                byte sib = method[position++];
                if (((sib >> 3) & 7) != 4 || (rex & 2) != 0)
                    continue; // Version fields must have a base register and no index.
                register = sib & 7;
            }
            if (mode == 0 && register == 5)
                continue; // RIP-relative or base-less addressing is not a consistent field base.
            int displacement = 0;
            if (mode == 1)
            {
                if (position >= valueOffset)
                    continue;
                displacement = unchecked((sbyte)method[position++]);
            }
            else if (mode == 2)
            {
                if (position + 4 > valueOffset)
                    continue;
                displacement = BinaryPrimitives.ReadInt32LittleEndian(method.Slice(position, 4));
                position += 4;
            }
            if (position != valueOffset || displacement != expectedDisplacement)
                continue;
            register |= (rex & 1) << 3;
            var decoded = new DecodedByteStore(start, registerNames[register], displacement,
                Hex(method.Slice(start, valueOffset - start + 1)));
            if (result != null)
                return null; // Multiple possible instruction starts do not establish a version store.
            result = decoded;
        }
        return result;
    }

    private static AutoVersionObservation AuditAutomaticVersion(ReadOnlySpan<byte> method)
    {
        try
        {
            // Match the production version-finder's anchor and field stores, but never leave this method.
            byte[] anchor = Convert.FromHexString("488B88B8000000");
            int anchorOffset = method.IndexOf(anchor);
            if (anchorOffset < 0)
                throw new InvalidDataException("The automatic version-search anchor was not found inside the cctor.");
            string[] prefixes = { "C6 01", "C6 41 01", "C6 41 02", "C6 41 04" };
            int[] offsets = new int[4];
            int[] values = new int[4];
            int previous = anchorOffset + anchor.Length - 1;
            for (int i = 0; i < prefixes.Length; i++)
            {
                BytePattern prefix = BytePattern.Parse(prefixes[i]);
                int instruction = prefix.FindUniqueOffset(method);
                int valueOffset = checked(instruction + prefix.Length);
                if (instruction <= previous || valueOffset >= method.Length)
                    throw new InvalidDataException("Automatic version stores are out of order or outside the cctor.");
                offsets[i] = valueOffset;
                values[i] = method[valueOffset];
                previous = valueOffset;
            }
            if (values[0] == 0 || values[0] > 99 || values[1] > 99 || values[2] > 99 || values[3] > 8)
                throw new InvalidDataException("Automatic version fields have implausible values.");
            return new AutoVersionObservation(true, $"{values[0]}.{values[1]}.{values[2]}", (byte)values[3],
                anchorOffset, offsets, values, null);
        }
        catch (Exception ex) when (IsInspectionError(ex))
        {
            return new AutoVersionObservation(false, null, null, null, null, null, ex.Message);
        }
    }

    private static object Probe(string patternText, ReadOnlySpan<byte> method, int rawStart)
    {
        try
        {
            BytePattern pattern = BytePattern.Parse(patternText);
            int offset = pattern.FindUniqueOffset(method);
            return new { Pattern = patternText, PatternSize = pattern.Length, Unique = true,
                RelativeOffset = (int?)offset, RawOffset = (int?)(rawStart + offset), Error = (string?)null };
        }
        catch (Exception ex) when (IsInspectionError(ex))
        {
            return new { Pattern = patternText, Unique = false, RelativeOffset = (int?)null,
                RawOffset = (int?)null, Error = ex.Message };
        }
    }

    private static object DescribeMethod(MethodLocation method) => new
    {
        method.Name,
        Rva = method.Rva,
        RvaHex = $"0x{method.Rva:X}",
        RawOffset = method.Range.Offset,
        RawOffsetHex = $"0x{method.Range.Offset:X}",
        method.Range.Length,
        method.Range.FragmentCount,
        BoundarySource = "Exact AMD64 PE exception-directory root and contiguous UNW_FLAG_CHAININFO fragments"
    };

    private static Dictionary<string, HashSet<ulong>> ReadSymbols(string path)
    {
        using FileStream stream = File.OpenRead(path);
        using JsonDocument document = JsonDocument.Parse(stream);
        if (!document.RootElement.TryGetProperty("ScriptMethod", out JsonElement methods) || methods.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("The script map must contain a ScriptMethod array.");
        var symbols = new Dictionary<string, HashSet<ulong>>(StringComparer.Ordinal);
        foreach (JsonElement method in methods.EnumerateArray())
        {
            string name = method.GetProperty("Name").GetString()
                ?? throw new InvalidDataException("A ScriptMethod name is null.");
            JsonElement addressValue = method.GetProperty("Address");
            ulong address = addressValue.ValueKind == JsonValueKind.Number ? addressValue.GetUInt64()
                : ParseAddress(addressValue.GetString() ?? string.Empty);
            if (!symbols.TryGetValue(name, out HashSet<ulong>? addresses))
            {
                addresses = new HashSet<ulong>();
                symbols.Add(name, addresses);
            }
            addresses.Add(address);
        }
        return symbols;
    }

    private static ulong ParseAddress(string value) => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
        ? ulong.Parse(value.AsSpan(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture)
        : ulong.Parse(value, CultureInfo.InvariantCulture);

    private static int MapRvaToRaw(ulong rva, SectionHeader[] sections, int imageLength)
    {
        if (rva > uint.MaxValue)
            throw new InvalidDataException("A symbol address is not a 32-bit RVA; virtual-address maps are unsupported.");
        int? match = null;
        foreach (SectionHeader section in sections)
        {
            ulong start = (uint)section.VirtualAddress;
            ulong length = (uint)(section.VirtualSize == 0 ? section.SizeOfRawData : section.VirtualSize);
            if (rva < start || rva - start >= length)
                continue;
            ulong relative = rva - start;
            ulong rawOffset = (uint)section.PointerToRawData + relative;
            if (relative >= (uint)section.SizeOfRawData || rawOffset >= (ulong)imageLength ||
                (section.SectionCharacteristics & SectionCharacteristics.MemExecute) == 0)
                throw new InvalidDataException("A symbol RVA does not map to file-backed executable bytes.");
            if (match != null)
                throw new InvalidDataException("A symbol RVA maps ambiguously to multiple PE sections.");
            match = checked((int)rawOffset);
        }
        return match ?? throw new InvalidDataException("A symbol RVA is outside the PE sections.");
    }

    private static int PatchDataLength(string data)
    {
        if (data.Contains("[FASM:", StringComparison.Ordinal))
            throw new InvalidDataException("A patchSize is required to inspect FASM definitions; the audit tool never invokes assemblers.");
        string hex = data.Replace("[NOP]", "90", StringComparison.Ordinal).Replace("[RET]", "C3", StringComparison.Ordinal);
        hex = new string(hex.Where(character => !char.IsWhiteSpace(character) && character != '-').ToArray());
        return Convert.FromHexString(hex).Length;
    }

    private static string Hex(ReadOnlySpan<byte> bytes) => string.Join(" ", bytes.ToArray().Select(value => value.ToString("X2", CultureInfo.InvariantCulture)));
    private static string HashFile(string path)
    {
        using FileStream stream = File.OpenRead(path);
        using SHA256 hash = SHA256.Create();
        return Convert.ToHexString(hash.ComputeHash(stream));
    }
    private static bool IsInspectionError(Exception ex) => ex is InvalidDataException or FormatException or
        ArgumentException or OverflowException or NotSupportedException or BadImageFormatException;

    private static Dictionary<string, string> ParseArguments(string[] args)
    {
        var allowed = new HashSet<string>(RequiredArguments.Concat(new[] { "output", "pattern", "method", "manifest-id", "map-provenance" }), StringComparer.Ordinal);
        var options = new Dictionary<string, string>(StringComparer.Ordinal);
        for (int i = 0; i < args.Length; i += 2)
        {
            if (!args[i].StartsWith("--", StringComparison.Ordinal) || i + 1 == args.Length ||
                !allowed.Contains(args[i][2..]) || !options.TryAdd(args[i][2..], args[i + 1]))
                throw new ArgumentException("Usage: --assembly PATH --script PATH --patchinfo PATH --range LABEL --expected-sha256 HASH [--output PATH] [--method NAME --pattern BYTES] [--map-provenance PATH --manifest-id ID]");
        }
        foreach (string required in RequiredArguments)
            if (!options.TryGetValue(required, out string? value) || string.IsNullOrWhiteSpace(value))
                throw new ArgumentException($"Required argument --{required} is missing.");
        if (options.ContainsKey("pattern") != options.ContainsKey("method"))
            throw new ArgumentException("--method and --pattern must be supplied together.");
        return options;
    }

    private sealed record MethodLocation(string Name, ulong Rva, NativeMethodRange Range);
    private sealed record DecodedByteStore(int RelativeOffset, string BaseRegister, int Displacement, string Bytes);
    private sealed record AutoVersionObservation(bool Success, string? VerifiedVersion, byte? VersionTypeByte,
        int? AnchorRelativeOffset, int[]? FieldValueRelativeOffsets, int[]? FieldValues, string? Error);
}
