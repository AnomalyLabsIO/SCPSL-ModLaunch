"""Index completed explicit-queue downloads; never interpret credentials or QR data."""

import datetime
import hashlib
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "artifacts/history-audit"
SOURCE = ROOT / "artifacts/historical-audit/manifests"
LOG = AUDIT / "depot-queue" / (sys.argv[1] if len(sys.argv) > 1 else "retry-qr-2.log")
LOG.resolve().relative_to(AUDIT / "depot-queue")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


queue = read(AUDIT / "depot-queue/retry-queue.json")
queued = {entry["manifestId"]: entry for entry in queue}
text = LOG.read_text(encoding="utf-8-sig")
completed = re.findall(r"^HISTORY_QUEUE_DONE ([0-9]+)\s*$", text, flags=re.MULTILINE)
if len(set(completed)) != len(completed) or not set(completed).issubset(queued):
    raise ValueError("The log has duplicate or unexpected completion identifiers.")
rows = read(AUDIT / "downloads.json")
by_id = {row["manifestId"]: row for row in rows}
changed = 0
for mid in completed:
    destination = Path(queued[mid]["destination"]).resolve()
    if destination != (SOURCE / mid).resolve():
        raise ValueError("A queue destination is outside its manifest-specific source directory.")
    # A marker alone cannot qualify a skipped/failed manifest. Require the SDK's
    # explicit manifest identity and two-file completion summary in its segment.
    segment = text.split(f"HISTORY_QUEUE_START {mid}", 1)[1].split(f"HISTORY_QUEUE_DONE {mid}", 1)[0]
    if f"Manifest {mid} (" not in segment or "Depot 700331 - Downloaded " not in segment or "from 1 depots" not in segment:
        raise ValueError(f"The SDK log does not establish a completed depot transfer for {mid}.")
    row = by_id[mid]
    if row.get("exitCode") == 0:
        continue
    files = []
    for name in ("GameAssembly.dll", "SCPSL_Data/il2cpp_data/Metadata/global-metadata.dat"):
        path = destination / name
        with path.open("rb") as stream:
            signature = stream.read(4)
            stream.seek(0)
            digest = hashlib.file_digest(stream, "sha256").hexdigest().upper()
        if not ((name == "GameAssembly.dll" and signature[:2] == b"MZ") or
                (name != "GameAssembly.dll" and signature == bytes.fromhex("AF1BB1FA"))):
            raise ValueError(f"An acquired file has the wrong signature: {path}")
        if path.stat().st_size == 0:
            raise ValueError("An acquired file is empty.")
        files.append({"path": str(path), "size": path.stat().st_size, "sha256": digest})
    initial = {"exitCode": row.get("exitCode"), "logPath": row.get("logPath"), "timedOut": row.get("timedOut")}
    row.update(exitCode=0, timedOut=False, reusedVerifiedCache=False, files=files,
               assemblyPath=files[0]["path"], metadataPath=files[1]["path"],
               assemblySha256=files[0]["sha256"], metadataSha256=files[1]["sha256"],
               logPath=str(LOG), acquisition="Reviewed single-session explicit-manifest queue; QR login; no cache-import mode.",
               previousFailedAttempt=initial, completedIndexedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    changed += 1
temporary = AUDIT / "downloads.json.next"
temporary.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
os.replace(temporary, AUDIT / "downloads.json")
print(json.dumps({"queueCompleted": len(completed), "newlyIndexed": changed,
                  "totalSuccessfulDownloads": sum(row.get("exitCode") == 0 for row in rows)}))
