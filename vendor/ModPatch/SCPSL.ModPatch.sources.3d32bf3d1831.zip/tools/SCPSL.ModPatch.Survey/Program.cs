using System.Globalization;
using System.Buffers.Binary;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
using Iced.Intel;
using Newtonsoft.Json;
using SCPSL_ModPatch.PatchUtils;

internal static class Program
{
    private static readonly string[] Required = { "assembly", "script", "map-provenance", "patchinfo", "manifest-id", "output" };
    private static readonly (string Name, string Pattern)[] StartPatterns = {
        ("CompletionGate1B", "80 39 00 75 1B"), ("CompletionGate20", "80 39 00 75 20"),
        ("ProgressRead14", "48 8B 48 08 48 85 C9 78 07"),
        ("CompletionRead14", "48 8B 80 B8 00 00 00 48 8B 48 08 8B 01") };
    private static readonly (string Name, string Pattern)[] AuthPatterns = {
        ("AuthenticationOld", "40 55 56 57 41 54 41 55 41 56 41 57 48 81 EC"),
        ("AuthenticationNew", "48 8B C4 53 56 57 41 54 41 55 41 56 41 57 48 81 EC") };
    private static readonly (string Name, string Pattern)[] ScanPatterns = {
        ("ScanBarOld", "40 53 48 83 EC 30 80 3D ?? ?? ?? ?? 00 48 8B D9 75 ??"),
        ("ScanBar1369", "40 53 48 83 EC 40 80 3D ?? ?? ?? ?? 00 48 8B D9 0F 29 7C 24 20") };

    private static int Main(string[] args)
    {
        try
        {
            Dictionary<string, string> options = ParseArguments(args);
            string assembly = Path.GetFullPath(options["assembly"]), script = Path.GetFullPath(options["script"]),
                provenancePath = Path.GetFullPath(options["map-provenance"]), feedPath = Path.GetFullPath(options["patchinfo"]),
                output = Path.GetFullPath(options["output"]);
            if (!ulong.TryParse(options["manifest-id"], NumberStyles.None, CultureInfo.InvariantCulture, out ulong manifestId) || manifestId == 0)
                throw new ArgumentException("--manifest-id must be a positive exact decimal string.");
            using JsonDocument provenanceDocument = JsonDocument.Parse(File.ReadAllBytes(provenancePath));
            JsonElement provenance = provenanceDocument.RootElement;
            string metadata = Path.GetFullPath(provenance.GetProperty("metadataPath").GetString()!);
            string[] inputs = { assembly, script, provenancePath, feedPath, metadata };
            if (inputs.Any(path => string.Equals(path, output, StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("The report output cannot overwrite any input.");
            var inputHashes = inputs.Distinct(StringComparer.OrdinalIgnoreCase).ToDictionary(path => path, HashFile, StringComparer.OrdinalIgnoreCase);
            RequireHash(provenance, "assemblySha256", inputHashes[assembly]);
            RequireHash(provenance, "scriptSha256", inputHashes[script]);
            RequireHash(provenance, "originalMetadataSha256", inputHashes[metadata]);
            byte[] image = File.ReadAllBytes(assembly);
            if (Hash(image) != inputHashes[assembly]) throw new InvalidDataException("The assembly changed during input preparation.");
            PatchInfo feed = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(feedPath)) ?? throw new InvalidDataException("The patch feed is null.");
            PatchTargetResolver.Validate(feed);
            (Dictionary<string, HashSet<ulong>> symbols, Dictionary<ulong, List<string>> labels, Dictionary<ulong, string> strings, HashSet<ulong> arrayFormatTargets) = ReadSymbols(script);
            using var stream = new MemoryStream(image, writable: false);
            using var pe = new PEReader(stream);
            SectionHeader[] sections = pe.PEHeaders.SectionHeaders.ToArray();
            NativeMethodMap? native = null;
            string? nativeError = null;
            try { native = new NativeMethodMap(image); } catch (Exception ex) when (InspectionError(ex)) { nativeError = ex.Message; }
            Method Resolve(string name)
            {
                if (!symbols.TryGetValue(name, out HashSet<ulong>? addresses) || addresses.Count == 0)
                    throw new InvalidDataException("Method is absent from the matching symbol map.");
                if (addresses.Count != 1) throw new InvalidDataException($"Method name has {addresses.Count} distinct RVAs; refusing to choose.");
                if (native == null) throw new InvalidDataException(nativeError ?? "Native bounds are unavailable.");
                ulong rva = addresses.Single();
                int raw = MapRva(rva, sections, image.Length);
                return new Method(name, rva, native.GetMethodRange(raw));
            }
            int? actualSchema = ReadInt(provenance, "configuredMetadataVersion");
            VersionReport version = DiscoverVersion(image, feed, actualSchema, Resolve);
            if (!symbols.ContainsKey("GameCore.Version$$.cctor"))
                version = DiscoverLegacyVersion(image, labels, strings, arrayFormatTargets, Resolve, version, metadata, actualSchema);
            VersionRangeInfo? range = null;
            string selection, selectionError = string.Empty;
            try
            {
                range = PatchTargetResolver.Resolve(feed, PatchTargetResolver.ComputeSha256(image),
                    version.VerifiedVersion == null ? null : System.Version.Parse(version.VerifiedVersion));
                selection = range.gameAssemblySha256 != null ? "AssemblyHashProfile" :
                    range.version != null ? "ObservedVersionProfile" : "ObservedVersionRange";
            }
            catch (Exception ex) when (InspectionError(ex))
            {
                selection = version.VerifiedVersion == null ? "UnknownVersion" : "NoProfile";
                selectionError = ex.Message;
            }
            var names = new HashSet<string>(StringComparer.Ordinal) { "GameCore.Version$$.cctor", "CentralAuthManager$$Authentication",
                "CentralAuth.CentralAuthManager$$Authentication", "LauncherCommunicator$$.cctor", "LauncherAssetScanProgressBar$$Update" };
            if (version.Reader.StartsWith("LegacyCompatibleVersions", StringComparison.Ordinal)) { names.Add("CustomNetworkManager$$.cctor"); names.Add("Misc$$ParseVersion"); }
            foreach (string name in symbols.Keys.Where(name => name.StartsWith("SimpleMenu.<StartLoad>d__", StringComparison.Ordinal) && name.EndsWith("$$MoveNext", StringComparison.Ordinal))) names.Add(name);
            var inventory = names.OrderBy(name => name, StringComparer.Ordinal).Select(name => InspectMethod(name, image, symbols, labels, Resolve)).ToArray();
            object[] patches = range?.methods.patchMethods.Select(patch => InspectPatch(patch, image, symbols, Resolve)).ToArray() ?? Array.Empty<object>();
            foreach ((string path, string hash) in inputHashes)
                if (HashFile(path) != hash) throw new InvalidDataException($"An input changed during the survey: {path}");
            var report = new {
                SurveyFormatVersion = 1, CreatedUtc = DateTimeOffset.UtcNow,
                SourceKind = options.GetValueOrDefault("source-kind") ?? "HashBoundLocalImage",
                Steam = new { AppId = 700330, DepotId = 700331, ManifestId = options["manifest-id"], ManifestBinding = "Operator-supplied exact manifest ID; file identity is verified against map provenance." },
                AssemblyPath = assembly, AssemblySha256 = inputHashes[assembly], AssemblySize = image.Length,
                ScriptPath = script, ScriptSha256 = inputHashes[script], MetadataPath = metadata, MetadataSha256 = inputHashes[metadata],
                MapProvenancePath = provenancePath, MapProvenanceSha256 = inputHashes[provenancePath], MapProvenance = provenance,
                PatchInfoPath = feedPath, PatchInfoSha256 = inputHashes[feedPath], Version = version,
                Selection = selection, SelectionError = selectionError, SelectedRange = range?.versionRange,
                SelectedRangeMetadataVersion = range?.metadataVersion, ActualConfiguredMetadataVersion = actualSchema,
                MetadataVersionDiscrepancy = range == null || actualSchema == null ? (bool?)null : range.metadataVersion != actualSchema,
                NativeBoundaryError = nativeError, MethodInventory = inventory, Patches = patches,
                OriginalInputsUnchanged = true,
                Acceptance = "Read-only native byte and symbol-map survey. No game code or unpacker is executed, no patch is applied, and no game startup, authentication, network, or gameplay behavior is established." };
            Directory.CreateDirectory(Path.GetDirectoryName(output)!);
            File.WriteAllText(output, System.Text.Json.JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine);
            Console.WriteLine($"Survey {options["manifest-id"]}: version={version.VerifiedVersion ?? "unknown"}, selection={selection}, report={output}");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine($"Survey failed: {ex.Message}"); return 1; }
    }

    private static VersionReport DiscoverVersion(byte[] image, PatchInfo feed, int? actualSchema, Func<string, Method> resolve)
    {
        var report = new VersionReport();
        try
        {
            Method method = resolve("GameCore.Version$$.cctor");
            report.Location = Describe(method);
            DecodeResult decoded = Decode(image, method);
            report.DecodeError = decoded.Error;
            var stores = new List<Store>();
            foreach (Decoded item in decoded.Instructions)
            {
                Instruction instruction = item.Instruction;
                if (instruction.Mnemonic != Mnemonic.Mov || instruction.Op0Kind != OpKind.Memory || instruction.Op1Kind != OpKind.Immediate8 ||
                    instruction.MemorySize != MemorySize.UInt8 || instruction.MemoryBase == Register.None || instruction.MemoryBase == Register.RIP ||
                    instruction.MemoryIndex != Register.None || instruction.MemoryDisplacement64 > 4) continue;
                var decoder = Iced.Intel.Decoder.Create(64, image.AsSpan(method.Range.Offset + item.Offset, instruction.Length).ToArray(), instruction.IP);
                decoder.Decode(out Instruction reread);
                ConstantOffsets constants = decoder.GetConstantOffsets(in reread);
                stores.Add(new Store(item.Offset, item.Offset + constants.ImmediateOffset, instruction.MemoryBase.ToString(),
                    checked((int)instruction.MemoryDisplacement64), instruction.Immediate8, item.Bytes));
            }
            report.ImmediateByteStores = stores.ToArray();
            // This is a field-layout distinction, not a game-version inference: older metadata-24 builds
            // pack the enum at +3; newer layouts contain another field at +3 and the enum at +4.
            int typeDisplacement = actualSchema == 24 ? 3 : 4;
            report.ExpectedTypeDisplacement = typeDisplacement;
            // Enumerate complete ordered field-store tuples. Do not let configured offsets break an ambiguity.
            var candidates = new List<VersionCandidate>();
            foreach (Store major in stores.Where(store => store.Displacement == 0 && store.Value > 0 && store.Value <= 99))
            foreach (Store minor in stores.Where(store => Next(major, store, 1) && store.Value <= 99))
            foreach (Store revision in stores.Where(store => Next(minor, store, 2) && store.Value <= 99))
            foreach (Store type in stores.Where(store => store.InstructionOffset > revision.InstructionOffset && store.BaseRegister == major.BaseRegister &&
                store.Displacement == typeDisplacement && store.Value <= 8 && store.InstructionOffset - major.InstructionOffset <= 512))
            {
                int[] offsets = { major.ValueOffset, minor.ValueOffset, revision.ValueOffset, type.ValueOffset };
                string[] configured = (feed.versionRanges ?? Array.Empty<VersionRangeInfo>()).Where(range => range.methods?.gameVersionMethod is GameVersionMethodInfo definition &&
                    definition.name == method.Name && offsets.SequenceEqual(new[] { definition.majorOffset, definition.minorOffset, definition.revisionOffset, definition.typeOffset })).Select(range => range.versionRange).ToArray();
                candidates.Add(new VersionCandidate($"{major.Value}.{minor.Value}.{revision.Value}", type.Value, major.BaseRegister, type.Displacement, offsets, configured));
                if (candidates.Count > 128) throw new InvalidDataException("More than 128 possible ordered version-store sequences; refusing unbounded enumeration.");
            }
            report.Candidates = candidates.ToArray();
            if (decoded.Error != null) { report.Status = "Unknown: native instruction stream did not decode completely."; return report; }
            if (candidates.Count == 1)
            {
                report.VerifiedVersion = candidates[0].Version;
                report.VersionTypeByte = candidates[0].Type;
                report.Status = "One ordered major/minor/revision/type byte-store sequence with a consistent base register inside the exact mapped version cctor.";
            }
            else report.Status = candidates.Count == 0 ? "Unknown: no complete plausible version-store sequence." : "Ambiguous: multiple complete version-store sequences.";
        }
        catch (Exception ex) when (InspectionError(ex)) { report.Status = "Unknown"; report.Error = ex.Message; }
        return report;
    }

    private static bool Next(Store previous, Store next, int displacement) => next.InstructionOffset > previous.InstructionOffset &&
        next.InstructionOffset - previous.InstructionOffset <= 128 && next.BaseRegister == previous.BaseRegister && next.Displacement == displacement;

    private static VersionReport DiscoverLegacyVersion(byte[] image, Dictionary<ulong, List<string>> labels,
        Dictionary<ulong, string> strings, HashSet<ulong> arrayFormatTargets, Func<string, Method> resolve, VersionReport original, string metadataPath, int? metadataSchema)
    {
        var report = new VersionReport { Method = "CustomNetworkManager$$.cctor -> Misc$$ParseVersion", Reader = "LegacyCompatibleVersions", PriorReaderError = original.Error };
        var result = new LegacyReleaseVersionReader.Result();
        try
        {
            LegacyReleaseVersionReader.Read(image, labels, strings, arrayFormatTargets, name =>
            {
                Method method = resolve(name);
                return new LegacyReleaseVersionReader.Method(method.Name, method.Rva, method.Range);
            }, ReadNetworkMetadataFields(metadataPath, metadataSchema), result);
        }
        catch (Exception ex) when (InspectionError(ex))
        {
            result.VerifiedVersion = null;
            result.Status = "Unknown legacy version";
            report.Error = ex.Message;
        }
        report.Reader = result.Reader;
        report.VerifiedVersion = result.VerifiedVersion;
        report.VersionTypeByte = result.VersionTypeByte;
        report.ReleaseLabel = result.ReleaseLabel;
        report.ReleaseQualifier = result.ReleaseQualifier;
        report.NetworkVersionTuple = result.NetworkVersionTuple;
        report.Status = result.Status;
        report.Location = result.Location;
        report.LegacyEvidence = result.LegacyEvidence;
        return report;
    }

    private static string[] ReadNetworkMetadataFields(string metadataPath, int? schema)
    {
        if (schema == null) throw new InvalidDataException("Successful metadata schema is missing from map provenance.");
        byte[] parserBytes = File.ReadAllBytes(metadataPath);
        if (parserBytes.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(parserBytes) != 0xFAB11BAF)
            throw new InvalidDataException("The bound metadata header is invalid.");
        // This independent private buffer has no filesystem backing; the input is hashed again by Main.
        BinaryPrimitives.WriteInt32LittleEndian(parserBytes.AsSpan(4, 4), schema.Value);
        using var stream = new MemoryStream(parserBytes, writable: true);
        var metadata = new Il2CppDumper.Metadata(stream);
        var definitions = metadata.typeDefs.Where(type => metadata.GetStringFromIndex(type.nameIndex) == "CustomNetworkManager" &&
            metadata.GetStringFromIndex(type.namespaceIndex) == "").ToArray();
        if (definitions.Length != 1) throw new InvalidDataException("Network metadata type is absent or ambiguous.");
        var definition = definitions[0];
        if (definition.fieldStart < 0 || (long)definition.fieldStart + definition.field_count > metadata.fieldDefs.Length)
            throw new InvalidDataException("Network metadata field range is invalid.");
        return metadata.fieldDefs.Skip(definition.fieldStart).Take(definition.field_count)
            .Select(field => metadata.GetStringFromIndex(field.nameIndex)).ToArray();
    }

    private static object InspectMethod(string name, byte[] image, Dictionary<string, HashSet<ulong>> symbols,
        Dictionary<ulong, List<string>> labels, Func<string, Method> resolve)
    {
        try
        {
            Method method = resolve(name);
            DecodeResult decoded = Decode(image, method);
            (string Name, string Pattern)[] patterns = name.Contains("<StartLoad>", StringComparison.Ordinal) ? StartPatterns :
                name.EndsWith("$$Authentication", StringComparison.Ordinal) ? AuthPatterns : name == "LauncherAssetScanProgressBar$$Update" ? ScanPatterns : Array.Empty<(string, string)>();
            var branches = new List<object>();
            for (int i = 0; i + 1 < decoded.Instructions.Count; i++)
            {
                Decoded compare = decoded.Instructions[i], branch = decoded.Instructions[i + 1];
                Instruction cmp = compare.Instruction, jcc = branch.Instruction;
                if (cmp.Mnemonic != Mnemonic.Cmp || cmp.Op0Kind != OpKind.Memory || cmp.MemorySize != MemorySize.UInt8 ||
                    cmp.Op1Kind != OpKind.Immediate8 || cmp.Immediate8 != 0 || jcc.FlowControl != FlowControl.ConditionalBranch) continue;
                object[] context = decoded.Instructions.Skip(Math.Max(0, i - 3)).Take(8).Select(InstructionDescription).ToArray();
                var calls = decoded.Instructions.Take(i).Where(item => item.Offset >= compare.Offset - 160 && item.Instruction.FlowControl == FlowControl.Call &&
                    item.Instruction.Op0Kind is OpKind.NearBranch16 or OpKind.NearBranch32 or OpKind.NearBranch64).Select(item => new {
                        item.Offset, TargetRva = item.Instruction.NearBranchTarget,
                        TargetNameCount = labels.GetValueOrDefault(item.Instruction.NearBranchTarget)?.Count ?? 0,
                        TargetNames = labels.GetValueOrDefault(item.Instruction.NearBranchTarget)?.Take(8).ToArray() ?? Array.Empty<string>() }).ToArray();
                branches.Add(new { CompareRelativeOffset = compare.Offset, CompareBytes = compare.Bytes, BranchRelativeOffset = branch.Offset,
                    BranchBytes = branch.Bytes, BranchMnemonic = jcc.Mnemonic.ToString(), TargetRva = jcc.NearBranchTarget,
                    TargetRelativeOffset = (long)jcc.NearBranchTarget - (long)method.Rva,
                    TargetInsideMethod = jcc.NearBranchTarget >= method.Rva && jcc.NearBranchTarget < method.Rva + (ulong)method.Range.Length,
                    PriorDirectCalls = calls, Context = context,
                    Interpretation = "Candidate byte-zero comparison and adjacent conditional branch only; semantic completion-gate identity is not established." });
            }
            return new { Method = name, Status = "Inspected", Location = Describe(method), SymbolAddressCount = symbols[name].Count,
                EntryBytes = Hex(image.AsSpan(method.Range.Offset, Math.Min(method.Range.Length, 32))), DecodeError = decoded.Error,
                Patterns = patterns.Select(pattern => Probe(pattern.Name, pattern.Pattern, image, method)).ToArray(),
                ByteZeroConditionalBranches = branches.ToArray() };
        }
        catch (Exception ex) when (InspectionError(ex)) { return new { Method = name, Status = symbols.ContainsKey(name) ? "Unresolved" : "Missing", Error = ex.Message }; }
    }

    private static object InspectPatch(PatchMethodInfo patch, byte[] image, Dictionary<string, HashSet<ulong>> symbols, Func<string, Method> resolve)
    {
        try
        {
            if (!string.IsNullOrEmpty(patch.patchifnotexists) && symbols.ContainsKey(patch.patchifnotexists)) return new { Method = patch.name, Status = "Skipped by patchifnotexists" };
            if (patch.nowarning && !symbols.ContainsKey(patch.name)) return new { Method = patch.name, Status = "Optional method absent" };
            Method method = resolve(patch.name);
            int size = patch.patchSize ?? DataLength(patch.patchData);
            if (size <= 0) throw new InvalidDataException("Patch size must be positive.");
            if (patch.patchPattern != null && patch.patchOffset != null) throw new InvalidDataException("patchPattern and patchOffset cannot both be specified.");
            int offset = patch.patchPattern == null ? patch.patchOffset ?? 0 : checked(BytePattern.Parse(patch.patchPattern).FindUniqueOffset(image.AsSpan(method.Range.Offset, method.Range.Length)) + patch.patternOffset);
            if (offset < 0 || offset > method.Range.Length - size) throw new InvalidDataException("Configured patch span is outside the native method bounds.");
            return new { Method = patch.name, Status = "Inspected", ConfiguredPatchPattern = patch.patchPattern, ConfiguredPatchOffset = patch.patchOffset,
                OriginalRelativeOffset = offset, OriginalRawOffset = method.Range.Offset + offset, PatchSize = size,
                OriginalBytes = Hex(image.AsSpan(method.Range.Offset + offset, size)), Context = Context(image, method, offset, size) };
        }
        catch (Exception ex) when (InspectionError(ex)) { return new { Method = patch.name, ConfiguredPatchPattern = patch.patchPattern, Error = ex.Message }; }
    }

    private static object Probe(string name, string patternText, byte[] image, Method method)
    {
        BytePattern parsed = BytePattern.Parse(patternText);
        // Count every match, including overlapping occurrences, for the inventory. Production still owns the unique-match decision.
        string compact = new string(patternText.Where(character => !char.IsWhiteSpace(character) && character != '-').ToArray());
        string[] tokens = Enumerable.Range(0, compact.Length / 2).Select(index => compact.Substring(index * 2, 2)).ToArray();
        var matches = new List<int>();
        ReadOnlySpan<byte> bytes = image.AsSpan(method.Range.Offset, method.Range.Length);
        for (int start = 0; start <= bytes.Length - parsed.Length; start++)
        {
            bool found = true;
            for (int i = 0; i < tokens.Length; i++) if (tokens[i] != "??" && bytes[start + i] != byte.Parse(tokens[i], NumberStyles.HexNumber, CultureInfo.InvariantCulture)) { found = false; break; }
            if (found) matches.Add(start);
        }
        bool unique = matches.Count == 1;
        if (unique && parsed.FindUniqueOffset(bytes) != matches[0]) throw new InvalidDataException("Survey and production pattern matchers disagree.");
        return new { Name = name, Pattern = patternText, MatchCount = matches.Count, Unique = unique,
            RelativeOffsets = matches.ToArray(), Matches = matches.Take(64).Select(offset => new { RelativeOffset = offset,
                RawOffset = method.Range.Offset + offset, OriginalBytes = Hex(image.AsSpan(method.Range.Offset + offset, parsed.Length)), Context = Context(image, method, offset, parsed.Length) }).ToArray(),
            ContextsTruncated = matches.Count > 64, Error = unique ? null : matches.Count == 0 ? "Pattern is missing from this method." : "Pattern has multiple matches in this method." };
    }

    private static object Context(byte[] image, Method method, int offset, int size)
    {
        int start = Math.Max(0, offset - 16), end = (int)Math.Min(method.Range.Length, (long)offset + size + 16);
        return new { RelativeOffset = start, RawOffset = method.Range.Offset + start, Bytes = Hex(image.AsSpan(method.Range.Offset + start, end - start)) };
    }

    private static DecodeResult Decode(byte[] image, Method method)
    {
        var instructions = new List<Decoded>();
        var decoder = Iced.Intel.Decoder.Create(64, image.AsSpan(method.Range.Offset, method.Range.Length).ToArray(), method.Rva);
        var formatter = new IntelFormatter(); var formatted = new StringOutput();
        while (decoder.IP < method.Rva + (ulong)method.Range.Length)
        {
            decoder.Decode(out Instruction instruction);
            if (instruction.Code == Code.INVALID || instruction.Length == 0 || decoder.IP > method.Rva + (ulong)method.Range.Length)
                return new DecodeResult(instructions, $"Invalid or truncated instruction at +0x{instruction.IP - method.Rva:X}.");
            formatter.Format(instruction, formatted);
            int offset = checked((int)(instruction.IP - method.Rva));
            instructions.Add(new Decoded(instruction, offset, Hex(image.AsSpan(method.Range.Offset + offset, instruction.Length)), formatted.ToStringAndReset()));
        }
        return new DecodeResult(instructions, null);
    }

    private static object InstructionDescription(Decoded instruction) => new { RelativeOffset = instruction.Offset, instruction.Bytes, instruction.Text };
    private static object Describe(Method method) => new { Method = method.Name, Rva = method.Rva, RawOffset = method.Range.Offset,
        Length = method.Range.Length, FragmentCount = method.Range.FragmentCount, BoundarySource = "Exact AMD64 runtime-function root and contiguous chained unwind fragments." };
    private static int DataLength(string data) => Convert.FromHexString(new string(data.Replace("[NOP]", "90").Replace("[RET]", "C3").Where(character => !char.IsWhiteSpace(character) && character != '-').ToArray())).Length;
    private static string Hex(ReadOnlySpan<byte> bytes) => string.Join(" ", bytes.ToArray().Select(value => value.ToString("X2", CultureInfo.InvariantCulture)));
    private static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes));
    private static string HashFile(string path) { using FileStream stream = File.OpenRead(path); using SHA256 hasher = SHA256.Create(); return Convert.ToHexString(hasher.ComputeHash(stream)); }
    private static int? ReadInt(JsonElement value, string name) => value.TryGetProperty(name, out JsonElement property) && property.TryGetInt32(out int number) ? number : null;
    private static void RequireHash(JsonElement provenance, string name, string actual) { if (!string.Equals(provenance.GetProperty(name).GetString(), actual, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"Input hash does not match map provenance: {name}."); }
    private static bool InspectionError(Exception ex) => ex is InvalidDataException or ArgumentException or FormatException or OverflowException or NotSupportedException or BadImageFormatException;
    private static int MapRva(ulong rva, SectionHeader[] sections, int imageLength)
    {
        if (rva > uint.MaxValue) throw new InvalidDataException("Symbol is not a 32-bit RVA.");
        SectionHeader[] matches = sections.Where(section => rva >= (uint)section.VirtualAddress && rva - (uint)section.VirtualAddress < (uint)(section.VirtualSize == 0 ? section.SizeOfRawData : section.VirtualSize) &&
            rva - (uint)section.VirtualAddress < (uint)section.SizeOfRawData && (section.SectionCharacteristics & SectionCharacteristics.MemExecute) != 0).ToArray();
        if (matches.Length != 1) throw new InvalidDataException("Symbol is not uniquely backed by executable file bytes.");
        int raw = checked((int)((ulong)(uint)matches[0].PointerToRawData + rva - (uint)matches[0].VirtualAddress));
        if (raw < 0 || raw >= imageLength) throw new InvalidDataException("Symbol raw offset is outside the image.");
        return raw;
    }
    private static (Dictionary<string, HashSet<ulong>>, Dictionary<ulong, List<string>>, Dictionary<ulong, string>, HashSet<ulong>) ReadSymbols(string path)
    {
        using JsonDocument document = JsonDocument.Parse(File.ReadAllBytes(path));
        var symbols = new Dictionary<string, HashSet<ulong>>(StringComparer.Ordinal); var labels = new Dictionary<ulong, List<string>>();
        var arrayFormatTargets = new HashSet<ulong>();
        foreach (string key in new[] { "ScriptMethod", "ScriptMetadata", "ScriptMetadataMethod" })
        {
            if (!document.RootElement.TryGetProperty(key, out JsonElement array)) { if (key == "ScriptMethod") throw new InvalidDataException("The script map has no ScriptMethod array."); continue; }
            foreach (JsonElement entry in array.EnumerateArray())
            {
                string name = entry.GetProperty("Name").GetString() ?? throw new InvalidDataException("Null symbol name.");
                JsonElement addressValue = entry.GetProperty("Address");
                string? text = addressValue.ValueKind == JsonValueKind.String ? addressValue.GetString() : null;
                ulong address = text == null ? addressValue.GetUInt64() : text.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? ulong.Parse(text.AsSpan(2), NumberStyles.HexNumber, CultureInfo.InvariantCulture) : ulong.Parse(text, CultureInfo.InvariantCulture);
                if (!labels.TryGetValue(address, out List<string>? names)) labels.Add(address, names = new List<string>());
                names.Add(name);
                if (key != "ScriptMethod") continue;
                if (name == "System.String$$Format" && entry.TryGetProperty("Signature", out JsonElement signature) &&
                    signature.GetString() == "System_String_o* System_String__Format (System_String_o* format, System_Object_array* args, const MethodInfo* method);")
                    arrayFormatTargets.Add(address);
                if (!symbols.TryGetValue(name, out HashSet<ulong>? addresses)) symbols.Add(name, addresses = new HashSet<ulong>());
                addresses.Add(address);
            }
        }
        var strings = new Dictionary<ulong, string>();
        if (document.RootElement.TryGetProperty("ScriptString", out JsonElement literals))
            foreach (JsonElement literal in literals.EnumerateArray())
            {
                ulong address = literal.GetProperty("Address").GetUInt64();
                string value = literal.GetProperty("Value").GetString() ?? string.Empty;
                if (strings.TryGetValue(address, out string? existing) && existing != value) throw new InvalidDataException("A metadata string address has conflicting values.");
                strings[address] = value;
            }
        return (symbols, labels, strings, arrayFormatTargets);
    }
    private static Dictionary<string, string> ParseArguments(string[] args)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        for (int i = 0; i < args.Length; i += 2)
            if (i + 1 >= args.Length || !args[i].StartsWith("--", StringComparison.Ordinal) || !(Required.Contains(args[i][2..]) || args[i] == "--source-kind") || !result.TryAdd(args[i][2..], args[i + 1]))
                throw new ArgumentException("Arguments must be unique --name value pairs: " + string.Join(" ", Required.Select(name => "--" + name + " VALUE")));
        foreach (string name in Required) if (!result.TryGetValue(name, out string? value) || string.IsNullOrWhiteSpace(value)) throw new ArgumentException($"Missing --{name}.");
        return result;
    }
    private sealed record Method(string Name, ulong Rva, NativeMethodRange Range);
    private sealed record Decoded(Instruction Instruction, int Offset, string Bytes, string Text);
    private sealed record DecodeResult(List<Decoded> Instructions, string? Error);
    private sealed record Store(int InstructionOffset, int ValueOffset, string BaseRegister, int Displacement, byte Value, string Bytes);
    private sealed record VersionCandidate(string Version, byte Type, string BaseRegister, int TypeDisplacement, int[] ValueOffsets, string[] ConfiguredProfiles);
    private sealed class VersionReport
    {
        public string Method { get; set; } = "GameCore.Version$$.cctor";
        public string Reader { get; set; } = "GameCoreByteStores";
        public string? VerifiedVersion { get; set; }
        public byte? VersionTypeByte { get; set; }
        public string? ReleaseLabel { get; set; }
        public string? ReleaseQualifier { get; set; }
        public string? NetworkVersionTuple { get; set; }
        public int? ExpectedTypeDisplacement { get; set; }
        public string Status { get; set; } = "Unknown";
        public object? Location { get; set; }
        public Store[] ImmediateByteStores { get; set; } = Array.Empty<Store>();
        public VersionCandidate[] Candidates { get; set; } = Array.Empty<VersionCandidate>();
        public string? DecodeError { get; set; }
        public string? Error { get; set; }
        public string? PriorReaderError { get; set; }
        public object? LegacyEvidence { get; set; }
    }
}
