# Static build survey

Summarize detected versions, patch-profile matches, and authentication/launcher methods across IL2CPP builds. Use this read-only tool to identify builds and patch targets that need review.

Run from the repository root with the .NET 10 SDK and .NET 6 Runtime installed:

```powershell
dotnet run --project tools/SCPSL.ModPatch.Survey -- `
  --assembly C:\inspection\GameAssembly.dll `
  --script C:\inspection\symbols\script.json `
  --map-provenance C:\inspection\symbols\map-provenance.json `
  --patchinfo Shared_Files\patchinfo.json `
  --manifest-id '<Steam manifest ID>' `
  --output C:\inspection\survey.json
```

Use matching outputs from the [mapper](../SCPSL.ModPatch.Map/README.md) and keep the original metadata at its recorded location.

The JSON report includes the detected release, selected profile, method inventory, pattern matches, and inspection errors. Builds without a matching profile still receive an inventory for review.

Optional: `--source-kind LABEL` adds an acquisition label to the report.

## Batch surveys

For [mapping batches](../SCPSL.ModPatch.Map/README.md#batch-mapping), build the survey tool in Release and run the coordinator with PowerShell 7:

```powershell
dotnet build tools/SCPSL.ModPatch.Survey -c Release
./tools/SCPSL.ModPatch.Survey/Invoke-HistorySurvey.ps1
```

By default, it reads `artifacts/history-audit/maps/mapping-index.json` and writes a resumable index and summary under `artifacts/history-audit/survey`.

Optional: `-MappingIndex PATH` and `-OutputDirectory PATH` select other locations; `-MaximumCount N` limits the batch; `-Force` regenerates reports.
