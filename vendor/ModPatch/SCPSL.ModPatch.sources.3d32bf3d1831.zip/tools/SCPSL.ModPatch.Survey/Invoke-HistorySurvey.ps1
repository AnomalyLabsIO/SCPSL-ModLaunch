param(
    [string]$MappingIndex = 'artifacts/history-audit/maps/mapping-index.json',
    [string]$PatchInfo = 'Shared_Files/patchinfo.json',
    [string]$OutputDirectory = 'artifacts/history-audit/survey',
    [int]$MaximumCount = 0,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$repositoryPath = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Push-Location -LiteralPath $repositoryPath
try {
    $surveyDll = Join-Path $PSScriptRoot 'bin/Release/net6.0/SCPSL.ModPatch.Survey.dll'
    if (-not (Test-Path -LiteralPath $surveyDll)) { throw 'Build SCPSL.ModPatch.Survey in Release first.' }
    $surveyHash = (Get-FileHash -LiteralPath $surveyDll -Algorithm SHA256).Hash
    $coordinatorHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash
    $feedPath = (Resolve-Path -LiteralPath $PatchInfo).Path
    $feedHash = (Get-FileHash -LiteralPath $feedPath -Algorithm SHA256).Hash
    $surveyRoot = [IO.Path]::GetFullPath((Join-Path $repositoryPath $OutputDirectory))
    [void][IO.Directory]::CreateDirectory($surveyRoot)
    $indexPath = Join-Path $surveyRoot 'survey-index.json'
    $summaryPath = Join-Path $surveyRoot 'summary.json'
    $rows = @()
    if (Test-Path -LiteralPath $indexPath) { $rows = @(Get-Content -LiteralPath $indexPath -Raw | ConvertFrom-Json) }
    $mappings = @(Get-Content -LiteralPath $MappingIndex -Raw | ConvertFrom-Json)
    $completed = 0
    foreach ($mapping in $mappings) {
        if ($mapping.status -ne 'Mapped' -or -not $mapping.mapDirectory) { continue }
        $manifestId = [string]$mapping.manifestId
        $scriptPath = Join-Path $mapping.mapDirectory 'script.json'
        $mapProvenance = Join-Path $mapping.mapDirectory 'map-provenance.json'
        $scriptHash = (Get-FileHash -LiteralPath $scriptPath -Algorithm SHA256).Hash
        $provenanceHash = (Get-FileHash -LiteralPath $mapProvenance -Algorithm SHA256).Hash
        $prior = @($rows | Where-Object { $_.manifestId -eq $manifestId })
        if (-not $Force -and $prior.Count -eq 1 -and $prior[0].exitCode -eq 0 -and
            $prior[0].assemblySha256 -eq $mapping.assemblySha256 -and $prior[0].metadataSha256 -eq $mapping.metadataSha256 -and
            $prior[0].scriptSha256 -eq $scriptHash -and $prior[0].patchInfoSha256 -eq $feedHash -and
            $prior[0].mapProvenanceSha256 -eq $provenanceHash -and $prior[0].coordinatorSha256 -eq $coordinatorHash -and
            $prior[0].surveyToolSha256 -eq $surveyHash -and $prior[0].sourceKind -eq $mapping.sourceKind -and
            $prior[0].reportSha256 -and (Test-Path -LiteralPath $prior[0].reportPath) -and
            (Get-FileHash -LiteralPath $prior[0].reportPath -Algorithm SHA256).Hash -eq $prior[0].reportSha256) { continue }
        if ($MaximumCount -gt 0 -and $completed -ge $MaximumCount) { break }
        $reportPath = Join-Path $surveyRoot ('survey-' + $manifestId + '.json')
        $logPath = Join-Path $surveyRoot ('survey-' + $manifestId + '.log')
        $surveyArguments = @($surveyDll, '--assembly', $mapping.assemblyPath, '--script', $scriptPath,
            '--map-provenance', $mapProvenance, '--patchinfo', $feedPath, '--manifest-id', $manifestId,
            '--source-kind', $mapping.sourceKind, '--output', $reportPath)
        & dotnet @surveyArguments *> $logPath
        $exitCode = $LASTEXITCODE
        $categories = @()
        $version = $null
        $versionType = $null
        $selection = $null
        $selectedRange = $null
        $patchErrors = @()
        $nativeErrors = @()
        $ambiguousPatterns = @()
        $startNames = @()
        $signatureMatches = @()
        $metadataDiscrepancy = $null
        $versionStatus = $null
        $reportHash = $null
        if ($exitCode -eq 0) {
            $reportBytes = [IO.File]::ReadAllBytes($reportPath)
            $reportHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($reportBytes))
            $report = [Text.Encoding]::UTF8.GetString($reportBytes) | ConvertFrom-Json
            $version = $report.Version.VerifiedVersion
            $versionType = $report.Version.VersionTypeByte
            $versionStatus = $report.Version.Status
            $selection = $report.Selection
            $selectedRange = $report.SelectedRange
            $metadataDiscrepancy = $report.MetadataVersionDiscrepancy
            $patchErrors = @($report.Patches | Where-Object { $_.Error } | ForEach-Object { $_.Method + ': ' + $_.Error })
            $nativeErrors = @($report.MethodInventory | Where-Object { $_.Status -eq 'Unresolved' } | ForEach-Object { $_.Method + ': ' + $_.Error })
            $startNames = @($report.MethodInventory | Where-Object { $_.Method -like 'SimpleMenu.<StartLoad>*' } | ForEach-Object { $_.Method })
            foreach ($method in $report.MethodInventory) {
                foreach ($pattern in $method.Patterns) {
                    if ($pattern.MatchCount -gt 1) { $ambiguousPatterns += $method.Method + ': ' + $pattern.Name + ' (' + $pattern.MatchCount + ')' }
                    if ($pattern.MatchCount -gt 0) { $signatureMatches += $method.Method + ':' + $pattern.Name + '=' + $pattern.MatchCount }
                }
            }
            if (-not $version) { $categories += 'VersionUnknown' }
            if ($selection -eq 'NoProfile') { $categories += 'NoProfile' }
            if ($selection -eq 'AmbiguousProfile') { $categories += 'AmbiguousProfile' }
            if ($metadataDiscrepancy -eq $true) { $categories += 'ParserSchemaMismatch' }
            if ($patchErrors.Count -gt 0) { $categories += 'SelectedProfilePatchErrors' }
            if (@($patchErrors | Where-Object { $_ -like '*not found within the method*' }).Count -gt 0) { $categories += 'SelectedProfileMissingPattern' }
            if (@($patchErrors | Where-Object { $_ -like '*matches more than once*' }).Count -gt 0) { $categories += 'SelectedProfileAmbiguousPattern' }
            if (@($patchErrors | Where-Object { $_ -like '*absent from the matching symbol map*' }).Count -gt 0) { $categories += 'SelectedProfileMissingMethod' }
            if (@($patchErrors | Where-Object { $_ -like '*outside the native method bounds*' }).Count -gt 0) { $categories += 'SelectedProfileInvalidSpan' }
            if ($nativeErrors.Count -gt 0 -or $report.NativeBoundaryError) { $categories += 'InvalidNativeBoundaries' }
            if ($ambiguousPatterns.Count -gt 0) { $categories += 'AmbiguousKnownPatterns' }
            if ($startNames.Count -eq 0) {
                if ($selectedRange -and @($report.Patches | Where-Object { $_.Method -like '*<StartLoad>*' }).Count -eq 0) { $categories += 'EarlyProfileWithoutStartLoad' }
                else { $categories += 'NoStartLoadCoroutine' }
            }
            if (@($startNames | Where-Object { $_ -notin @('SimpleMenu.<StartLoad>d__8$$MoveNext', 'SimpleMenu.<StartLoad>d__10$$MoveNext') }).Count -gt 0) { $categories += 'UnusualCoroutineNames' }
            if ($categories.Count -eq 0) { $categories += 'CurrentProfileByteChecksPassed' }
        }
        else { $categories += 'SurveyFailed' }
        $rows = @($rows | Where-Object { $_.manifestId -ne $manifestId })
        $rows += [PSCustomObject]@{
            manifestId = $manifestId; sourceKind = $mapping.sourceKind; assemblyPath = $mapping.assemblyPath;
            assemblySha256 = $mapping.assemblySha256; metadataSha256 = $mapping.metadataSha256;
            scriptPath = $scriptPath; scriptSha256 = $scriptHash; mapProvenancePath = $mapProvenance; mapProvenanceSha256 = $provenanceHash;
            patchInfoSha256 = $feedHash; surveyToolSha256 = $surveyHash; coordinatorSha256 = $coordinatorHash;
            exitCode = $exitCode; verifiedVersion = $version; versionTypeByte = $versionType;
            versionStatus = $versionStatus; selection = $selection; selectedRange = $selectedRange;
            actualMetadataVersion = $mapping.actualMetadataVersion; actualIl2CppVersion = $mapping.actualIl2CppVersion;
            normalizedMetadataHeaderVersion = $mapping.normalizedMetadataHeaderVersion; forcedIl2CppVersion = $mapping.forcedIl2CppVersion;
            metadataVersionDiscrepancy = $metadataDiscrepancy; categories = $categories;
            currentProfileByteChecksPassed = [bool]($selectedRange -and $patchErrors.Count -eq 0);
            patchErrors = $patchErrors; nativeErrors = $nativeErrors; ambiguousPatterns = $ambiguousPatterns;
            coroutineNames = $startNames; signatureMatches = $signatureMatches;
            reportPath = $reportPath; reportSha256 = $reportHash; logPath = $logPath; createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
        }
        $temporaryIndex = $indexPath + '.tmp'
        ConvertTo-Json -InputObject @($rows) -Depth 12 | Set-Content -LiteralPath $temporaryIndex -Encoding UTF8
        Move-Item -LiteralPath $temporaryIndex -Destination $indexPath -Force
        $completed++
        Write-Output "Survey ${manifestId}: exit=$exitCode version=$version categories=$($categories -join ',')"
    }
    $categoryCounts = @($rows | ForEach-Object { $_.categories } | Group-Object | Sort-Object Name | ForEach-Object { [PSCustomObject]@{ category = $_.Name; count = $_.Count } })
    $clusters = @($rows | Group-Object -Property { ($_.coroutineNames -join '|') + ';header=' + $_.normalizedMetadataHeaderVersion + ';il2cpp=' + $_.actualIl2CppVersion + ';patterns=' + ($_.signatureMatches -join '|') } |
        Sort-Object Count -Descending | ForEach-Object { [PSCustomObject]@{ count = $_.Count; signature = $_.Name;
            manifestIds = @($_.Group | ForEach-Object { $_.manifestId }); versions = @($_.Group | ForEach-Object { $_.verifiedVersion } | Sort-Object -Unique);
            categories = @($_.Group | ForEach-Object { $_.categories } | Sort-Object -Unique) } })
    [PSCustomObject]@{ createdUtc = [DateTimeOffset]::UtcNow.ToString('o'); surveyed = $rows.Count; newThisRun = $completed;
        categories = $categoryCounts; clusters = $clusters;
        acceptance = 'Read-only static survey only; no patch application, game launch, authentication, network, or gameplay acceptance.' } |
        ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $summaryPath -Encoding UTF8
    Write-Output "Survey index: $indexPath; completed=$($rows.Count); new=$completed"
}
finally { Pop-Location }
