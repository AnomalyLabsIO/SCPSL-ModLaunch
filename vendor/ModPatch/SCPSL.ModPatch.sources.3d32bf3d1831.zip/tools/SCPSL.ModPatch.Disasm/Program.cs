using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Iced.Intel;
using SCPSL_ModPatch.PatchUtils;

try
{
    var options = new Dictionary<string, string>(StringComparer.Ordinal);
    for (int i = 0; i < args.Length; i += 2)
    {
        if (i + 1 >= args.Length || !args[i].StartsWith("--", StringComparison.Ordinal) || !options.TryAdd(args[i][2..], args[i + 1]))
            throw new ArgumentException("Arguments must be unique --name value pairs.");
    }
    foreach (string key in new[] { "assembly", "script", "method", "expected-sha256", "output" })
        if (!options.ContainsKey(key))
            throw new ArgumentException($"Missing --{key}.");
    string assemblyPath = Path.GetFullPath(options["assembly"]);
    string scriptPath = Path.GetFullPath(options["script"]);
    string outputPath = Path.GetFullPath(options["output"]);
    if (new[] { assemblyPath, scriptPath }.Any(path => string.Equals(path, outputPath, StringComparison.OrdinalIgnoreCase)))
        throw new ArgumentException("The output cannot overwrite an input.");
    byte[] image = File.ReadAllBytes(assemblyPath);
    string hash = Convert.ToHexString(SHA256.HashData(image));
    if (!string.Equals(hash, options["expected-sha256"], StringComparison.OrdinalIgnoreCase))
        throw new InvalidDataException("The expected assembly SHA-256 does not match.");
    using var document = JsonDocument.Parse(File.ReadAllBytes(scriptPath));
    var labels = new Dictionary<ulong, List<string>>();
    var methodAddresses = new HashSet<ulong>();
    foreach (string array in new[] { "ScriptMethod", "ScriptMetadata", "ScriptMetadataMethod" })
    {
        if (!document.RootElement.TryGetProperty(array, out JsonElement entries))
            continue;
        foreach (JsonElement entry in entries.EnumerateArray())
        {
            ulong address = entry.GetProperty("Address").GetUInt64();
            string name = entry.GetProperty("Name").GetString() ?? string.Empty;
            if (!labels.TryGetValue(address, out List<string>? names))
            {
                names = new List<string>();
                labels.Add(address, names);
            }
            names.Add(name);
            if (array == "ScriptMethod" && name == options["method"])
                methodAddresses.Add(address);
        }
    }
    if (methodAddresses.Count != 1)
        throw new InvalidDataException("The method name does not identify exactly one distinct RVA.");
    ulong rva = methodAddresses.Single();
    var nativeMap = new NativeMethodMap(image);
    using var stream = new MemoryStream(image, writable: false);
    using var peReader = new PEReader(stream);
    SectionHeader[] matches = peReader.PEHeaders.SectionHeaders.Where(section => rva >= (ulong)section.VirtualAddress &&
        rva - (ulong)section.VirtualAddress < (ulong)(section.VirtualSize == 0 ? section.SizeOfRawData : section.VirtualSize) &&
        rva - (ulong)section.VirtualAddress < (ulong)section.SizeOfRawData).ToArray();
    if (matches.Length != 1)
        throw new InvalidDataException("The method RVA is not uniquely file backed.");
    int raw = checked((int)((ulong)matches[0].PointerToRawData + rva - (ulong)matches[0].VirtualAddress));
    NativeMethodRange range = nativeMap.GetMethodRange(raw);
    byte[] bytes = image.AsSpan(range.Offset, range.Length).ToArray();
    Iced.Intel.Decoder decoder = Iced.Intel.Decoder.Create(64, bytes, rva);
    var formatter = new IntelFormatter();
    var formatted = new StringOutput();
    var report = new StringBuilder();
    report.AppendLine($"Assembly: {assemblyPath}");
    report.AppendLine($"SHA256: {hash}");
    report.AppendLine($"Symbol map: {scriptPath}");
    report.AppendLine($"Method: {options["method"]}");
    report.AppendLine($"RVA: 0x{rva:X}; raw: 0x{raw:X}; length: {range.Length}; chained runtime entries: {range.FragmentCount}");
    report.AppendLine("Static linear instruction decoding only; no game code executed.");
    var boundaries = new HashSet<int>();
    while (decoder.IP < rva + (ulong)bytes.Length)
    {
        decoder.Decode(out Instruction instruction);
        if (instruction.Code == Code.INVALID || instruction.Length == 0 || decoder.IP > rva + (ulong)bytes.Length)
            throw new InvalidDataException("An invalid or truncated instruction was encountered.");
        formatter.Format(instruction, formatted);
        string text = formatted.ToStringAndReset();
        int relative = checked((int)(instruction.IP - rva));
        boundaries.Add(relative);
        string instructionHex = Convert.ToHexString(bytes.AsSpan(relative, instruction.Length));
        var annotations = new List<string>();
        if (instruction.FlowControl is FlowControl.Call or FlowControl.ConditionalBranch or FlowControl.UnconditionalBranch)
        {
            ulong target = instruction.NearBranchTarget;
            if (target >= rva && target < rva + (ulong)range.Length)
                annotations.Add($"target +0x{target - rva:X}");
            if (labels.TryGetValue(target, out List<string>? names))
                annotations.Add(string.Join(" | ", names.Take(8)) + (names.Count > 8 ? $" | ... ({names.Count} aliases)" : string.Empty));
        }
        if (instruction.IsIPRelativeMemoryOperand && labels.TryGetValue(instruction.IPRelativeMemoryAddress, out List<string>? memoryNames))
            annotations.Add("memory: " + string.Join(" | ", memoryNames));
        report.AppendLine($"+0x{relative:X4} 0x{instruction.IP:X8} {instructionHex,-30} {text}" +
            (annotations.Count == 0 ? string.Empty : " ; " + string.Join("; ", annotations)));
    }
    boundaries.Add(bytes.Length);
    if (options.ContainsKey("replacement") != options.ContainsKey("relative"))
        throw new ArgumentException("--replacement and --relative must be supplied together.");
    if (options.TryGetValue("replacement", out string? replacementText))
    {
        int replacementOffset = int.Parse(options["relative"], System.Globalization.CultureInfo.InvariantCulture);
        byte[] replacement = Convert.FromHexString(new string(replacementText.Where(character => !char.IsWhiteSpace(character) && character != '-').ToArray()));
        if (replacement.Length == 0 || !boundaries.Contains(replacementOffset) ||
            !boundaries.Contains(checked(replacementOffset + replacement.Length)))
            throw new InvalidDataException("The replacement span must start and end at original instruction boundaries.");
        report.AppendLine("Replacement instruction analysis only; bytes were not applied to the image:");
        var replacementDecoder = Iced.Intel.Decoder.Create(64, replacement, rva + (ulong)replacementOffset);
        while (replacementDecoder.IP < rva + (ulong)replacementOffset + (ulong)replacement.Length)
        {
            replacementDecoder.Decode(out Instruction instruction);
            if (instruction.Code == Code.INVALID || replacementDecoder.IP > rva + (ulong)replacementOffset + (ulong)replacement.Length)
                throw new InvalidDataException("The replacement instruction sequence is invalid or truncated.");
            formatter.Format(instruction, formatted);
            string target = string.Empty;
            if (instruction.FlowControl is FlowControl.ConditionalBranch or FlowControl.UnconditionalBranch)
            {
                long targetRelative = checked((long)instruction.NearBranchTarget - (long)rva);
                if (targetRelative < 0 || targetRelative > int.MaxValue || !boundaries.Contains((int)targetRelative))
                    throw new InvalidDataException("A replacement branch does not target an original method instruction boundary.");
                target = $" ; target +0x{targetRelative:X}, original instruction boundary";
            }
            report.AppendLine($"+0x{instruction.IP - rva:X4} {formatted.ToStringAndReset()}{target}");
        }
    }
    Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
    File.WriteAllText(outputPath, report.ToString());
    Console.WriteLine($"Static disassembly: {outputPath}");
    return 0;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Disassembly failed: {ex.Message}");
    return 1;
}
