# Static native method inspection

Inspect one IL2CPP method and save a disassembly with annotated calls and data references. The DLL is unchanged.

Run from the repository root with the .NET 10 SDK and .NET 6 Runtime installed:

```powershell
dotnet run --project tools/SCPSL.ModPatch.Disasm -- `
  --assembly C:\inspection\GameAssembly.dll `
  --script C:\inspection\script.json `
  --method 'CentralAuthManager$$Authentication' `
  --expected-sha256 '<assembly SHA-256>' `
  --output C:\inspection\method.txt
```

Use the DLL's SHA-256 and a matching [RVA symbol map](../SCPSL.ModPatch.Map/README.md).

Optional: `--relative OFFSET --replacement '90 90'` previews replacement bytes at the given method offset without applying them.
