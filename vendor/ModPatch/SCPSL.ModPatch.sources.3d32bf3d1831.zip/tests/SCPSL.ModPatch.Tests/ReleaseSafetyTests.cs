using System.Buffers.Binary;
using System.Diagnostics;
using System.Reflection;
using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

internal static class ReleaseSafetyTests
{
    public static void Register(Action<string, Action> run)
    {
        foreach (bool interactive in new[] { false, true })
        {
            run($"{(interactive ? "GUI" : "CLI")} failed load preserves original metadata despite parser normalization", () =>
            {
                using var fixture = new Fixture();
                VersionRangeInfo target = new() { version = "14.2.8", metadataVersion = 29 };
                var info = new PatchInfo { versionRanges = new[] { target } };
                Expect<Il2cppInitException>(() => PatchSession.LoadAsync(fixture.Root, info, target, interactive)
                    .GetAwaiter().GetResult());
                fixture.AssertOriginals();
            });
        }

        run("GUI save normalizes only the metadata header after saving prepared edits and allows subsequent saves", () =>
        {
            using var fixture = new Fixture();
            (PatchSession session, Patcher patcher, SyntheticPe pe) = fixture.Session();
            patcher.PatchGameAssembly();
            session.SaveGameAssemblyAndMetadata(patcher);
            Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(session.NormalizedMetadata), "Normalized metadata was not saved.");
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(pe.Image), "Prepared assembly was not saved.");
            pe.Put(1, 0x90);
            session.SaveGameAssemblyAndMetadata(patcher);
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(pe.Image), "A second explicit save rejected its own prior output.");
        });

        run("GUI save rejects changed metadata before saving assembly", () =>
        {
            using var fixture = new Fixture();
            (PatchSession session, Patcher patcher, _) = fixture.Session();
            byte[] assembly = File.ReadAllBytes(fixture.Assembly);
            byte[] changed = File.ReadAllBytes(fixture.Metadata);
            changed[100] = 0x5A;
            File.WriteAllBytes(fixture.Metadata, changed);
            patcher.PatchGameAssembly();
            Expect<IOException>(() => session.SaveGameAssemblyAndMetadata(patcher));
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(assembly), "Metadata conflict saved the assembly.");
            Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(changed), "Metadata conflict overwrote external changes.");
        });

        run("GUI save leaves metadata unchanged when assembly validation fails", () =>
        {
            using var fixture = new Fixture();
            (PatchSession session, Patcher patcher, _) = fixture.Session();
            byte[] changed = File.ReadAllBytes(fixture.Assembly);
            changed[100] ^= 0xFF;
            File.WriteAllBytes(fixture.Assembly, changed);
            patcher.PatchGameAssembly();
            Expect<InvalidDataException>(() => session.SaveGameAssemblyAndMetadata(patcher));
            Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(fixture.OriginalMetadata), "Failed assembly save normalized metadata.");
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(changed), "Failed save overwrote external assembly changes.");
        });

        run("GUI save rejects locked metadata before saving assembly", () =>
        {
            using var fixture = new Fixture();
            (PatchSession session, Patcher patcher, _) = fixture.Session();
            byte[] assembly = File.ReadAllBytes(fixture.Assembly);
            patcher.PatchGameAssembly();
            using (var held = new FileStream(fixture.Metadata, FileMode.Open, FileAccess.Read, FileShare.None))
                Expect<IOException>(() => session.SaveGameAssemblyAndMetadata(patcher));
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(assembly), "Locked metadata left an assembly edit behind.");
            Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(fixture.OriginalMetadata), "Locked metadata changed.");
        });

        run("unpacker ignores stale output beside the executable and requires a fresh result", () =>
        {
            using var fixture = new Fixture();
            string stale = Path.Combine(fixture.Root, "unpacked_GameAssembly.dll");
            byte[] output = new SyntheticPe().Image;
            File.WriteAllBytes(stale, output);
            Expect<InvalidDataException>(() => fixture.Unpacker.UnpackAndReplace(start =>
            {
                Check(Path.IsPathFullyQualified(start.FileName) && start.ArgumentList.Single() == fixture.Assembly,
                    "Unpacker paths were not passed as absolute, separate arguments.");
                Check(start.WorkingDirectory != fixture.Root && Directory.GetFiles(start.WorkingDirectory).Length == 0,
                    "Unpacker reused a directory containing old output.");
                Check(!start.UseShellExecute && start.CreateNoWindow, "Unpacker opened a shell or visible helper window.");
                return 0;
            }));
            fixture.AssertOriginals();
            Check(File.ReadAllBytes(stale).SequenceEqual(output), "Unrelated stale output was consumed or removed.");
        });

        run("unpacker rejects nonzero exit even with fresh valid output", () =>
        {
            using var fixture = new Fixture();
            Expect<InvalidOperationException>(() => fixture.Unpacker.UnpackAndReplace(start =>
            {
                WriteOutput(start, new SyntheticPe().Image);
                return 7;
            }));
            fixture.AssertOriginals();
        });

        run("unpacker startup failure preserves the original and cleans scratch files", () =>
        {
            using var fixture = new Fixture();
            Expect<IOException>(() => fixture.Unpacker.UnpackAndReplace(_ => throw new IOException("simulated start failure")));
            fixture.AssertOriginals();
            Check(!Directory.EnumerateDirectories(fixture.Root, ".modpatch-unpack-*").Any(), "Failed start left its scratch directory.");
        });

        foreach (string invalid in new[] { "empty", "truncated headers", "wrong machine", "not DLL", "truncated section", "unchanged" })
        {
            run($"unpacker rejects {invalid} output without replacing the original", () =>
            {
                using var fixture = new Fixture();
                var pe = new SyntheticPe();
                byte[] output = pe.Image;
                switch (invalid)
                {
                    case "empty": output = Array.Empty<byte>(); break;
                    case "truncated headers": output = new byte[] { 0x4D, 0x5A }; break;
                    case "wrong machine": pe.Write16(0x84, 0x14C); break;
                    case "not DLL": pe.Write16(0x96, 0x22); break;
                    case "truncated section": pe.Write32(SyntheticPe.SectionHeaders + 16, output.Length); break;
                    case "unchanged": File.WriteAllBytes(fixture.Assembly, output); break;
                }
                byte[] original = File.ReadAllBytes(fixture.Assembly);
                Exception failure = Capture(() => fixture.Unpacker.UnpackAndReplace(start => { WriteOutput(start, output); return 0; }));
                Check(failure is InvalidDataException or BadImageFormatException, "Unexpected validation error: " + failure);
                Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(original), "Invalid output replaced the original.");
                Check(!Directory.EnumerateFiles(fixture.Root, "*.bak").Any(), "Validation failure created a misleading backup.");
            });
        }

        run("unpacker detects an input changed during the attempt", () =>
        {
            using var fixture = new Fixture();
            byte[] changed = new byte[] { 9, 8, 7, 6 };
            Expect<IOException>(() => fixture.Unpacker.UnpackAndReplace(start =>
            {
                WriteOutput(start, new SyntheticPe().Image);
                File.WriteAllBytes(fixture.Assembly, changed);
                return 0;
            }));
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(changed), "Unpacking overwrote an external input change.");
        });

        run("unpacker replacement failure retains the original DLL", () =>
        {
            using var fixture = new Fixture();
            using (var held = new FileStream(fixture.Assembly, FileMode.Open, FileAccess.Read, FileShare.Read))
                Expect<IOException>(() => fixture.Unpacker.UnpackAndReplace(start =>
                {
                    WriteOutput(start, new SyntheticPe().Image);
                    return 0;
                }));
            fixture.AssertOriginals();
        });

        run("unpacker success installs validated output and retains an exact original backup", () =>
        {
            using var fixture = new Fixture();
            byte[] output = new SyntheticPe().Image;
            string backup = fixture.Unpacker.UnpackAndReplace(start => { WriteOutput(start, output); return 0; });
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(output), "Validated output was not installed.");
            Check(File.ReadAllBytes(backup).SequenceEqual(Fixture.OriginalAssembly), "Original backup was lost or changed.");
            Check(!Directory.EnumerateDirectories(fixture.Root, ".modpatch-unpack-*").Any(), "Successful attempt left its scratch directory.");
        });

        string? realGame = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_GAME_DIR");
        if (!string.IsNullOrWhiteSpace(realGame))
            run("GUI real offline load preserves metadata until a successful explicit save", () => RealGuiSession(realGame));
    }

    private static void RealGuiSession(string source)
    {
        using var fixture = new Fixture();
        foreach (string relative in new[] { "GameAssembly.dll", "UnityPlayer.dll", "SCPSL_Data/il2cpp_data/Metadata/global-metadata.dat" })
            File.Copy(Path.Combine(source, relative), Path.Combine(fixture.Root, relative), overwrite: true);
        byte[] originalAssembly = File.ReadAllBytes(fixture.Assembly);
        byte[] metadata = File.ReadAllBytes(fixture.Metadata);
        BinaryPrimitives.WriteInt32LittleEndian(metadata.AsSpan(4), 42);
        File.WriteAllBytes(fixture.Metadata, metadata);
        PatchInfo info = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "patchinfo.json")))!;
        PatchSession session = PatchSession.LoadAsync(fixture.Root, info, null, interactive: true).GetAwaiter().GetResult();
        Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(metadata), "Successful GUI load changed original metadata.");
        Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(originalAssembly), "Successful GUI load changed the assembly.");
        var patcher = new Patcher(fixture.Assembly, session.AssemblyData, session.Manager, session.Target);
        patcher.PatchGameAssembly();
        session.SaveGameAssemblyAndMetadata(patcher);
        Check(File.ReadAllBytes(fixture.Metadata).SequenceEqual(session.NormalizedMetadata), "Explicit GUI save omitted normalization.");
        Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(session.AssemblyData) && !session.AssemblyData.SequenceEqual(originalAssembly),
            "Explicit GUI save omitted prepared assembly patches.");
    }

    private static void WriteOutput(ProcessStartInfo start, byte[] output) =>
        File.WriteAllBytes(Path.Combine(start.WorkingDirectory, "unpacked_GameAssembly.dll"), output);

    private static Exception Capture(Action action)
    {
        try { action(); }
        catch (Exception ex) { return ex; }
        throw new Exception("Expected operation to fail.");
    }

    private static void Expect<T>(Action action) where T : Exception =>
        Check(Capture(action) is T, $"Expected {typeof(T).Name}.");

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }

    private sealed class Fixture : IDisposable
    {
        public static readonly byte[] OriginalAssembly = { 1, 2, 3, 4 };
        public string Root { get; } = Path.Combine(Path.GetTempPath(), "ModPatch-release-safety-" + Guid.NewGuid().ToString("N"));
        public string Assembly => Path.Combine(Root, "GameAssembly.dll");
        public string Metadata => Path.Combine(Root, "SCPSL_Data", "il2cpp_data", "Metadata", "global-metadata.dat");
        public byte[] OriginalMetadata { get; } = new byte[512];
        public Unpacker Unpacker => new(Path.Combine(Root, "unlicense.exe"), Assembly);

        public Fixture()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Metadata)!);
            BinaryPrimitives.WriteUInt32LittleEndian(OriginalMetadata, 0xFAB11BAF);
            BinaryPrimitives.WriteInt32LittleEndian(OriginalMetadata.AsSpan(4), 24);
            File.WriteAllBytes(Assembly, OriginalAssembly);
            File.WriteAllBytes(Metadata, OriginalMetadata);
        }

        public (PatchSession, Patcher, SyntheticPe) Session()
        {
            var pe = new SyntheticPe();
            File.WriteAllBytes(Assembly, pe.Image);
            var target = new VersionRangeInfo { metadataVersion = 29, methods = new MethodsInfo
            {
                patchMethods = new[] { new PatchMethodInfo { name = SyntheticPe.A, patchData = "C3" } }
            } };
            Patcher patcher = pe.CreatePatcher(target, Assembly);
            var manager = (Il2cppManager)typeof(Patcher).GetField("_il2cppManager", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(patcher)!;
            byte[] normalized = OriginalMetadata.ToArray();
            BinaryPrimitives.WriteInt32LittleEndian(normalized.AsSpan(4), 29);
            var session = (PatchSession)Activator.CreateInstance(typeof(PatchSession), BindingFlags.Instance | BindingFlags.NonPublic,
                null, new object?[] { pe.Image, manager, target, null, Metadata, PatchTargetResolver.ComputeSha256(OriginalMetadata), normalized }, null)!;
            return (session, patcher, pe);
        }

        public void AssertOriginals()
        {
            Check(File.ReadAllBytes(Assembly).SequenceEqual(OriginalAssembly), "Original assembly changed.");
            Check(File.ReadAllBytes(Metadata).SequenceEqual(OriginalMetadata), "Original metadata changed.");
        }

        public void Dispose() => Directory.Delete(Root, recursive: true);
    }
}
