using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class OlderFeedTests
{
    private const string Authentication = "CentralAuthManager$$Authentication";
    private static readonly string OtherHash = new('0', 64);

    public static void Register(Action<string, Action> run)
    {
        foreach (string version in new[] { "9.0.0", "10.0.0", "10.1.0" })
        {
            Version release = Version.Parse(version);
            byte[] entry = Convert.FromHexString(release.Major == 9
                ? "40555356574154415641574881EC40010000488D6C2440"
                : "4055565741544155415641574881EC40010000488D6C2440");
            run($"actual {version} profile patches only its authentication entry despite an identical neighboring signature", () =>
            {
                SyntheticPe fixture = Fixture(entry);
                byte[] expected = (byte[])fixture.Image.Clone();
                expected[SyntheticPe.TextRaw] = 0xC3;
                expected[SyntheticPe.TextRaw + 1] = 0x90;
                Patcher patcher = fixture.CreatePatcher(Resolve(LoadFeed(), release));
                patcher.PatchGameAssembly();
                Check(fixture.Image.SequenceEqual(expected), "The profile changed bytes beyond its two-byte authentication entry.");
                Check(patcher.PatchOutcomes.Count == 1 && patcher.PatchOutcomes[0].Name == Authentication && patcher.PatchOutcomes[0].Status == "applied",
                    "The profile did not report exactly one applied authentication patch.");
            });

            foreach (bool duplicate in new[] { false, true })
            {
                bool addDuplicate = duplicate;
                run($"actual {version} profile rejects a {(duplicate ? "duplicate" : "missing")} method-scoped signature before writing", () =>
                {
                    SyntheticPe fixture = Fixture(entry);
                    if (addDuplicate) fixture.Put(0x30, entry);
                    else fixture.Put(0, 0x90);
                    byte[] original = (byte[])fixture.Image.Clone();
                    Patcher patcher = fixture.CreatePatcher(Resolve(LoadFeed(), release));
                    try { patcher.PatchGameAssembly(); }
                    catch (InvalidDataException)
                    {
                        Check(fixture.Image.SequenceEqual(original) && patcher.PatchOutcomes.Count == 0,
                            "Rejected targeting changed bytes or published an applied patch.");
                        return;
                    }
                    throw new Exception("An absent or ambiguous authentication signature was accepted.");
                });
            }
        }
    }

    private static PatchInfo LoadFeed() =>
        JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "patchinfo.json")))!;

    private static VersionRangeInfo Resolve(PatchInfo feed, Version version) => PatchTargetResolver.Resolve(feed, OtherHash, version);

    private static SyntheticPe Fixture(byte[] entry)
    {
        var fixture = new SyntheticPe(new(Authentication, 0, 0x80), new("Fixture.Neighbor$$Run", 0x80, 0x80));
        fixture.Put(0, entry);
        fixture.Put(0x80, entry);
        return fixture;
    }

    private static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
}
