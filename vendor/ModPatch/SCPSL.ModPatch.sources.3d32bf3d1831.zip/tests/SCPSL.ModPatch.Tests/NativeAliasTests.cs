using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;

internal static class NativeAliasTests
{
    public static void Register(Action<string, Action> run)
    {
        run("CLI rejects hardlinked native assembly and launcher before loading or writing", () =>
        {
            using var fixture = new Fixture();
            File.Delete(fixture.Launcher);
            if (!CreateHardLink(fixture.Launcher, fixture.Assembly, IntPtr.Zero))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not create the private test hardlink.");

            JsonElement report = Invoke(fixture);
            Check(report.GetProperty("stage").GetString() == "preflight", "Hardlinked destinations reached the native loader.");
            string message = report.GetProperty("error").GetProperty("message").GetString()!;
            Check(message.Contains("distinct files", StringComparison.OrdinalIgnoreCase), "Failure did not identify a distinct-destination conflict.");
            Check(message.Contains(fixture.Assembly, StringComparison.OrdinalIgnoreCase) &&
                message.Contains(fixture.Launcher, StringComparison.OrdinalIgnoreCase), "Conflict did not identify both aliased destinations.");
            fixture.AssertInputsUnchanged();
        });
        run("CLI does not mistake byte-identical separate native destinations for aliases", () =>
        {
            using var fixture = new Fixture();
            // The fixture creates these through a copy, not a second name for one file.
            Check(File.ReadAllBytes(fixture.Assembly).SequenceEqual(File.ReadAllBytes(fixture.Launcher)),
                "Native destinations must have identical content to exercise file identity rather than hashing.");
            JsonElement report = Invoke(fixture);
            Check(report.GetProperty("stage").GetString() == "load", "Separate files were rejected before the deliberately invalid native inputs reached the loader.");
            fixture.AssertInputsUnchanged();
        });
    }

    private static JsonElement Invoke(Fixture fixture)
    {
        var start = new ProcessStartInfo(FindExecutable())
        {
            WorkingDirectory = fixture.Root,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        foreach (string argument in new[] { "patch", "--game-dir", fixture.Game, "--patch-info", fixture.Manifest,
            "--clean-launcher", fixture.CleanLauncher, "--result", fixture.Result })
            start.ArgumentList.Add(argument);
        using Process process = Process.Start(start) ?? throw new InvalidOperationException("Could not start the CLI executable.");
        Task<string> stdout = process.StandardOutput.ReadToEndAsync();
        Task<string> stderr = process.StandardError.ReadToEndAsync();
        // Keep stdin open: unexpected GUI prompts or console reads must time out.
        if (!process.WaitForExit(15000))
        {
            process.Kill(entireProcessTree: true);
            process.WaitForExit(3000);
            throw new InvalidOperationException("Native destination CLI test timed out with stdin held open.");
        }
        Check(Task.WaitAll(new Task[] { stdout, stderr }, 3000), "CLI left an output pipe open.");
        string detail = $"CLI exit {process.ExitCode}. stdout: {stdout.Result} stderr: {stderr.Result}";
        Check(process.ExitCode == 1, detail);
        Check(File.Exists(fixture.Result), "CLI omitted its failure report. " + detail);
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(fixture.Result));
        JsonElement report = document.RootElement;
        Check(!report.GetProperty("success").GetBoolean() && report.GetProperty("exitCode").GetInt32() == 1,
            "Report disagrees with the failing CLI exit. " + detail);
        Check(report.GetProperty("modifiedFiles").GetArrayLength() == 0, "CLI reported native input modifications on failure.");
        return report.Clone();
    }

    private static string FindExecutable()
    {
        string? explicitPath = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_EXE");
        if (!string.IsNullOrWhiteSpace(explicitPath))
        {
            Check(File.Exists(explicitPath), "SCPSL_MODPATCH_TEST_EXE does not exist.");
            return Path.GetFullPath(explicitPath);
        }
        for (DirectoryInfo? directory = new(AppContext.BaseDirectory); directory != null; directory = directory.Parent)
        {
            if (!File.Exists(Path.Combine(directory.FullName, "SCPSL ModPatch.sln"))) continue;
            string framework = $"net{Environment.Version.Major}.0-windows";
            string path = Path.Combine(directory.FullName, "SCPSL ModPatch", "bin", "Release", framework, "win-x64", "SCPSL ModPatch.exe");
            Check(File.Exists(path), "Build the Release application before running the CLI process tests.");
            return path;
        }
        throw new InvalidOperationException("Could not locate solution; set SCPSL_MODPATCH_TEST_EXE to the existing WinExe.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class Fixture : IDisposable
    {
        private static readonly string FixtureBase = Path.GetFullPath(
            string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_WORK_DIR"))
                ? Path.Combine(Path.GetTempPath(), "SCPSL-ModPatch-native-alias-tests")
                : Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_WORK_DIR")!);
        public string Root { get; } = Path.Combine(FixtureBase, Guid.NewGuid().ToString("N"));
        public string Game => Path.Combine(Root, "game folder ü");
        public string Assembly => Path.Combine(Game, "GameAssembly.dll");
        public string Launcher => Path.Combine(Game, "SCPSL.exe");
        private string Metadata => Path.Combine(Game, "SCPSL_Data", "il2cpp_data", "Metadata", "global-metadata.dat");
        public string Manifest => Path.Combine(Root, "native manifest.json");
        public string CleanLauncher => Path.Combine(Root, "clean launcher.exe");
        public string Result => Path.Combine(Root, "result.json");
        private readonly Dictionary<string, byte[]> _original;

        public Fixture()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Metadata)!);
            var pe = new SyntheticPe();
            pe.Image[2] = 0x90;
            File.WriteAllBytes(Assembly, pe.Image);
            File.Copy(Assembly, Launcher);
            File.WriteAllBytes(Metadata, new byte[0x200]);
            File.WriteAllText(CleanLauncher, "private replacement launcher; never executed");
            File.WriteAllText(Manifest, JsonSerializer.Serialize(new
            {
                versionRanges = new[] { new
                {
                    versionRange = "native alias fixture",
                    gameAssemblySha256 = Convert.ToHexString(SHA256.HashData(pe.Image)), metadataVersion = 24,
                    cleanLauncherPath = Path.GetFileName(CleanLauncher),
                    methods = new { patchMethods = Array.Empty<object>() }
                } }
            }));
            _original = new[] { Assembly, Launcher, Metadata, Manifest, CleanLauncher }
                .ToDictionary(path => path, File.ReadAllBytes, StringComparer.OrdinalIgnoreCase);
        }

        public void AssertInputsUnchanged()
        {
            foreach ((string path, byte[] original) in _original)
                Check(File.Exists(path) && File.ReadAllBytes(path).SequenceEqual(original), "Failure modified a native input: " + path);
        }

        public void Dispose()
        {
            string allowed = Path.TrimEndingDirectorySeparator(FixtureBase) + Path.DirectorySeparatorChar;
            string target = Path.GetFullPath(Root);
            Check(target.StartsWith(allowed, StringComparison.OrdinalIgnoreCase), "Refusing to delete outside the private fixture directory.");
            if (Directory.Exists(target)) Directory.Delete(target, recursive: true);
        }
    }

    [DllImport("kernel32.dll", EntryPoint = "CreateHardLinkW", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateHardLink(string newFileName, string existingFileName, IntPtr securityAttributes);
}
