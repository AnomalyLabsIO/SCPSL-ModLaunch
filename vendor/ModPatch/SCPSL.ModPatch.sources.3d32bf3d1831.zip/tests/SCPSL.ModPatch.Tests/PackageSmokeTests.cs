using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using SCPSL_ModPatch.PatchUtils;

/// <summary>
/// Drives the released executable, including its actual no-argument GUI and button events.
/// No game code is executed. Every writable game input and GUI setting lives in a new private
/// directory; retained files and JSON reports allow failures to be inspected after the run.
/// The Win32 calls also work when this Windows test executable is run inside Wine/Proton.
/// </summary>
internal static class PackageSmokeTests
{
    private static readonly TimeSpan Timeout = TimeSpan.FromMinutes(3);
    private const uint BmClick = 0x00F5;
    private const uint WmClose = 0x0010;

    public static int Run(string[] arguments)
    {
        string root = string.Empty;
        try
        {
            var options = new Dictionary<string, string>(StringComparer.Ordinal);
            for (int i = 1; i < arguments.Length; i += 2)
            {
                Check(i + 1 < arguments.Length && arguments[i].StartsWith("--", StringComparison.Ordinal),
                    "Expected --package-smoke --exe PATH [--work-dir PATH] [--native-game-dir PATH --patch-info PATH --clean-launcher PATH].");
                Check(options.TryAdd(arguments[i], arguments[i + 1]), "Duplicate option: " + arguments[i]);
            }
            Check(options.Keys.All(key => new[] { "--exe", "--work-dir", "--native-game-dir", "--patch-info", "--clean-launcher" }.Contains(key)),
                "Unknown package-smoke option.");
            string executable = Path.GetFullPath(options["--exe"]);
            Check(File.Exists(executable), "The packaged executable does not exist: " + executable);
            root = Path.Combine(Path.GetFullPath(options.GetValueOrDefault("--work-dir") ??
                Path.Combine(Path.GetTempPath(), "SCPSL-ModPatch-package-smoke")), Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            Console.WriteLine("Retained package smoke artifacts: " + root);
            CliBasics(executable, root);
            if (options.TryGetValue("--native-game-dir", out string? nativeGame))
                Native(executable, root, Path.GetFullPath(nativeGame), Path.GetFullPath(options["--patch-info"]),
                    Path.GetFullPath(options["--clean-launcher"]));
            bool nativeChecked = options.ContainsKey("--native-game-dir");
            string coverage = nativeChecked
                ? "Packaged GUI startup/load/patch and CLI help/error/patch checks passed with a real IL2CPP fixture."
                : "Packaged CLI help/error checks passed. Supply --native-game-dir, --patch-info and --clean-launcher for GUI/native patch coverage.";
            File.WriteAllText(Path.Combine(root, "success.txt"),
                coverage + "\nNo game was launched.\n" + executable + "\n" +
                RuntimeInformation.FrameworkDescription + "\n" + RuntimeInformation.OSDescription);
            Console.WriteLine("PASS " + coverage);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            if (Directory.Exists(root)) File.WriteAllText(Path.Combine(root, "failure.txt"), ex.ToString());
            return 1;
        }
    }

    private static void CliBasics(string executable, string root)
    {
        string help = Path.Combine(root, "help.json");
        Check(Invoke(executable, root, new[] { "--help", "--result", help }, "help").ExitCode == 0,
            "Packaged --help did not return success.");
        string json = File.ReadAllText(help);
        Check(json.Contains("--game-dir", StringComparison.Ordinal) && json.Contains("--metadata-mode", StringComparison.Ordinal),
            "Packaged --help did not describe patch options.");
        string invalid = Path.Combine(root, "invalid.json");
        Check(Invoke(executable, root, new[] { "unknown", "--result", invalid }, "invalid").ExitCode == 2,
            "Packaged unknown command did not return syntax error 2.");
        Check(File.ReadAllText(invalid).Contains("\"success\": false", StringComparison.Ordinal),
            "Invalid command did not write a failure result.");
        Console.WriteLine("PASS packaged CLI help and invalid command exit without GUI or stdin.");
    }


    private static void Native(string executable, string root, string source, string originalManifest, string cleanLauncher)
    {
        string area = Path.Combine(root, "native");
        Directory.CreateDirectory(area);
        string[] relativeInputs = new[] { "GameAssembly.dll", "SCPSL.exe", "UnityPlayer.dll",
            "SCPSL_Data/il2cpp_data/Metadata/global-metadata.dat" }.Where(relative => File.Exists(Path.Combine(source,
                relative.Replace('/', Path.DirectorySeparatorChar)))).ToArray();
        Check(relativeInputs.Contains("GameAssembly.dll") && relativeInputs.Contains("UnityPlayer.dll") &&
            relativeInputs.Contains("SCPSL_Data/il2cpp_data/Metadata/global-metadata.dat"),
            "Native source must contain GameAssembly.dll, its matching UnityPlayer.dll and SCPSL_Data/il2cpp_data/Metadata/global-metadata.dat.");
        Dictionary<string, string> sourceHashes = relativeInputs.ToDictionary(relative => relative,
            relative => HashFile(Path.Combine(source, relative.Replace('/', Path.DirectorySeparatorChar))));
        string cleanHash = HashFile(cleanLauncher);
        string manifestHash = HashFile(originalManifest);
        PatchInfo info = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(originalManifest))!;
        foreach (VersionRangeInfo target in info.versionRanges)
        {
            // Keep every profile and its own launcher so this exercises automatic selection
            // against the full feed rather than a fixture-specific profile.
            string relative = target.cleanLauncherPath;
            Check(!Path.IsPathRooted(relative), "The fixture feed must use relative launcher paths.");
            string privateLauncher = Path.GetFullPath(relative, area);
            Check(privateLauncher.StartsWith(area + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase),
                "The fixture launcher path escapes its private directory.");
            Directory.CreateDirectory(Path.GetDirectoryName(privateLauncher)!);
            string sourceLauncher = Path.GetFullPath(relative, Path.GetDirectoryName(originalManifest)!);
            File.Copy(sourceLauncher, privateLauncher, overwrite: true);
            target.cleanLauncherPath = privateLauncher;
            target.cleanLauncherUrl = string.Empty;
        }
        string manifest = Path.Combine(area, "patchinfo.json");
        File.WriteAllText(manifest, JsonConvert.SerializeObject(info, Formatting.Indented));
        string cliGame = Path.Combine(area, "CLI game");
        string guiGame = Path.Combine(area, "GUI game");
        foreach (string game in new[] { cliGame, guiGame })
            foreach (string relative in relativeInputs)
            {
                string destination = Path.Combine(game, relative.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                File.Copy(Path.Combine(source, relative.Replace('/', Path.DirectorySeparatorChar)), destination);
            }
        string cliResult = Path.Combine(area, "cli-result.json");
        ProcessResult cli = Invoke(executable, area,
            new[] { "patch", "--game-dir", cliGame, "--patch-info", manifest, "--result", cliResult }, "native-cli");
        Check(cli.ExitCode == 0, "Packaged real IL2CPP CLI patch failed: " + cli.Error);
        Check(HashFile(Path.Combine(cliGame, "SCPSL.exe")) == cleanHash,
            "CLI did not use the matching default launcher from the selected patch definition.");
        string cliAssembly = Path.Combine(cliGame, "GameAssembly.dll");
        string guiAssembly = Path.Combine(guiGame, "GameAssembly.dll");
        string expected = HashFile(cliAssembly);
        Check(expected != sourceHashes["GameAssembly.dll"], "Native fixture did not require any assembly patch; choose a patchable original.");
        DriveGui(executable, Path.Combine(area, "GUI settings"), guiGame, manifest, guiAssembly,
            () => HashFile(guiAssembly) == expected && HashFile(Path.Combine(guiGame, "SCPSL.exe")) == cleanHash);
        foreach (string relative in relativeInputs)
        {
            Check(HashFile(Path.Combine(source, relative.Replace('/', Path.DirectorySeparatorChar))) == sourceHashes[relative],
                "Original native fixture changed: " + relative);
            Check(HashFile(Path.Combine(cliGame, relative.Replace('/', Path.DirectorySeparatorChar))) ==
                HashFile(Path.Combine(guiGame, relative.Replace('/', Path.DirectorySeparatorChar))),
                "Native GUI and CLI outputs differ: " + relative);
        }
        Check(HashFile(originalManifest) == manifestHash && HashFile(cleanLauncher) == cleanHash, "A native source dependency changed.");
        File.WriteAllText(Path.Combine(area, "source-hashes.json"), JsonConvert.SerializeObject(sourceHashes, Formatting.Indented));
        Console.WriteLine("PASS packaged GUI and CLI automatic IL2CPP loading/patching select the matching default launcher and produce identical binary and metadata; source hashes unchanged.");
    }

    private static void DriveGui(string executable, string settings, string game, string manifest,
        string assemblyPath, Func<bool> patched)
    {
        Directory.CreateDirectory(settings);
        File.WriteAllText(Path.Combine(settings, "config.json"), JsonConvert.SerializeObject(new
        {
            GameFolder_Path = game, AutoUpdatePatchInfo = false, CreateManagedDummyDllFolder = false,
            CustomPatchInfoEnable = true, CustomPatchInfoPath = manifest
        }));
        using Process process = Start(executable, settings, Array.Empty<string>());
        Task<string> output = process.StandardOutput.ReadToEndAsync();
        Task<string> error = process.StandardError.ReadToEndAsync();
        try
        {
            IntPtr main = WaitFor(process, () => Windows(process.Id).FirstOrDefault(window => Title(window) == "SCPSL ModPatch"),
                "The packaged no-argument executable did not display MainForm.");
            SettingsDialogs(process, main, settings);
            string metadataPath = Path.Combine(game, "SCPSL_Data", "il2cpp_data", "Metadata", "global-metadata.dat");
            string beforeLoadAssembly = HashFile(assemblyPath);
            string beforeLoadMetadata = HashFile(metadataPath);
            IntPtr load = FindButton(main, "Load game");
            Check(load != IntPtr.Zero && IsWindowEnabled(load), "MainForm has no enabled Load game button.");
            Check(PostMessage(load, BmClick, IntPtr.Zero, IntPtr.Zero), "Could not click Load game.");
            WaitFor(process, () =>
            {
                RejectDialogs(process.Id, main);
                IntPtr action = FindButton(main, "Patch game");
                return IsWindowEnabled(load) && Title(load) == "Load game" &&
                    action != IntPtr.Zero && IsWindowEnabled(action) ? main : IntPtr.Zero;
            }, "The GUI did not finish loading the isolated game fixture.");
            Check(HashFile(assemblyPath) == beforeLoadAssembly && HashFile(metadataPath) == beforeLoadMetadata,
                "GUI Load game modified the original assembly or metadata before Patch game was clicked.");
            string beforePatch = HashFile(assemblyPath);
            IntPtr patch = FindButton(main, "Patch game");
            Check(patch != IntPtr.Zero && IsWindowEnabled(patch), "MainForm has no enabled Patch game button.");
            Check(PostMessage(patch, BmClick, IntPtr.Zero, IntPtr.Zero), "Could not click Patch.");
            IntPtr dialog = WaitFor(process, () =>
            {
                IntPtr modal = Windows(process.Id).FirstOrDefault(window => window != main && ClassName(window) == "#32770");
                if (modal == IntPtr.Zero) return IntPtr.Zero;
                Check(patched(), "GUI reported completion without the expected saved files: " + Describe(modal));
                File.WriteAllText(Path.Combine(settings, "completion-dialog.txt"), Describe(modal));
                return modal;
            }, "The GUI did not display a patch completion dialog.");
            Check(PostMessage(dialog, WmClose, IntPtr.Zero, IntPtr.Zero), "Could not dismiss GUI completion dialog.");
            WaitFor(process, () => !Windows(process.Id).Contains(dialog) ? main : IntPtr.Zero,
                "The GUI completion dialog did not close.");
            WaitFor(process, () =>
            {
                RejectDialogs(process.Id, main);
                try { return patched() ? main : IntPtr.Zero; }
                catch (IOException) { return IntPtr.Zero; }
            }, "GUI patch output did not match CLI output.");
            Check(HashFile(assemblyPath) != beforePatch, "GUI patch did not change the target assembly.");
            Check(PostMessage(main, WmClose, IntPtr.Zero, IntPtr.Zero), "Could not close the GUI.");
            Check(process.WaitForExit(10000) && process.ExitCode == 0, "MainForm did not exit cleanly.");
            Check(Task.WaitAll(new Task[] { output, error }, 5000), "GUI output streams did not close.");
            File.WriteAllText(Path.Combine(settings, "stdout.txt"), output.Result);
            File.WriteAllText(Path.Combine(settings, "stderr.txt"), error.Result);
        }
        finally
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
                process.WaitForExit(5000);
            }
            if (Task.WaitAll(new Task[] { output, error }, 5000))
            {
                File.WriteAllText(Path.Combine(settings, "stdout.txt"), output.Result);
                File.WriteAllText(Path.Combine(settings, "stderr.txt"), error.Result);
            }
        }
    }

    private static void SettingsDialogs(Process process, IntPtr main, string settingsDirectory)
    {
        string config = Path.Combine(settingsDirectory, "config.json");
        string originalConfigHash = HashFile(config);
        IntPtr open = FindButton(main, "Open settings");
        Check(open != IntPtr.Zero && PostMessage(open, BmClick, IntPtr.Zero, IntPtr.Zero), "Could not open GUI settings.");
        IntPtr settings = WaitFor(process, () => Windows(process.Id).FirstOrDefault(window =>
            window != main && FindButton(window, "Apply settings") != IntPtr.Zero), "The Settings form did not open.");
        var roundTrips = new List<string>();
        foreach (string groupName in new[] { "Game folder (contains SCPSL.exe and SCPSL_Data)", "Custom patch definitions (advanced; restart required)" })
        {
            IntPtr group = Children(settings).FirstOrDefault(window => Title(window) == groupName);
            Check(group != IntPtr.Zero, "Settings group was not found: " + groupName);
            IntPtr browse = FindButton(group, "Browse");
            Check(browse != IntPtr.Zero && IsWindowEnabled(browse) && PostMessage(browse, BmClick, IntPtr.Zero, IntPtr.Zero),
                "Could not click Browse in settings group: " + groupName);
            IntPtr dialog = WaitFor(process, () => Windows(process.Id).FirstOrDefault(window =>
                window != main && window != settings && ClassName(window) == "#32770"),
                "The native browse dialog did not open: " + groupName);
            roundTrips.Add(groupName + ": " + ClassName(dialog) + " / " + Title(dialog));
            Check(PostMessage(dialog, WmClose, IntPtr.Zero, IntPtr.Zero), "Could not cancel native browse dialog: " + groupName);
            WaitFor(process, () => !Windows(process.Id).Contains(dialog) && IsWindowEnabled(settings) ? settings : IntPtr.Zero,
                "The native browse dialog did not close: " + groupName);
        }
        Check(PostMessage(settings, WmClose, IntPtr.Zero, IntPtr.Zero), "Could not close Settings without applying changes.");
        WaitFor(process, () => !Windows(process.Id).Contains(settings) && IsWindowEnabled(main) ? main : IntPtr.Zero,
            "The Settings form did not return to MainForm.");
        Check(HashFile(config) == originalConfigHash, "Cancelling settings/file dialogs changed the configuration.");
        File.WriteAllLines(Path.Combine(settingsDirectory, "native-dialog-roundtrips.txt"), roundTrips);
        Console.WriteLine("PASS packaged GUI Settings, native folder browser and native file browser open/cancel without changing configuration.");
    }

    private static IntPtr WaitFor(Process process, Func<IntPtr> probe, string failure)
    {
        var timer = Stopwatch.StartNew();
        while (timer.Elapsed < Timeout && !process.HasExited)
        {
            IntPtr result = probe();
            if (result != IntPtr.Zero) return result;
            Thread.Sleep(25);
        }
        throw new InvalidOperationException(failure + (process.HasExited ? " Exit code: " + process.ExitCode : string.Empty));
    }

    private static void RejectDialogs(int processId, IntPtr main)
    {
        IntPtr dialog = Windows(processId).FirstOrDefault(window => window != main && ClassName(window) == "#32770");
        Check(dialog == IntPtr.Zero, "Unexpected GUI dialog: " + Describe(dialog));
    }

    private static ProcessResult Invoke(string executable, string directory, IEnumerable<string> arguments, string logName)
    {
        using Process process = Start(executable, directory, arguments);
        Task<string> output = process.StandardOutput.ReadToEndAsync();
        Task<string> error = process.StandardError.ReadToEndAsync();
        var timer = Stopwatch.StartNew();
        try
        {
            while (!process.WaitForExit(25) && timer.Elapsed < Timeout)
                Check(Windows(process.Id).Count == 0, "A packaged CLI command displayed an interactive window.");
            Check(process.HasExited, "Packaged CLI command timed out while stdin remained open.");
            Check(Task.WaitAll(new Task[] { output, error }, 5000), "CLI output streams did not close.");
            File.WriteAllText(Path.Combine(directory, logName + "-stdout.txt"), output.Result);
            File.WriteAllText(Path.Combine(directory, logName + "-stderr.txt"), error.Result);
            return new ProcessResult(process.ExitCode, output.Result, error.Result);
        }
        finally
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
                process.WaitForExit(5000);
            }
        }
    }

    private static Process Start(string executable, string directory, IEnumerable<string> arguments)
    {
        var start = new ProcessStartInfo(executable)
        {
            WorkingDirectory = directory, UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true
        };
        foreach (string argument in arguments) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Could not start packaged executable.");
    }

    private static List<IntPtr> Windows(int processId)
    {
        var result = new List<IntPtr>();
        EnumWindows((window, _) =>
        {
            GetWindowThreadProcessId(window, out uint owner);
            if (owner == processId && IsWindowVisible(window)) result.Add(window);
            return true;
        }, IntPtr.Zero);
        return result;
    }

    private static List<IntPtr> Children(IntPtr parent)
    {
        var result = new List<IntPtr>();
        EnumChildWindows(parent, (window, _) => { result.Add(window); return true; }, IntPtr.Zero);
        return result;
    }

    private static IntPtr FindButton(IntPtr main, string text) => Children(main)
        .FirstOrDefault(window => ClassName(window).Contains("BUTTON", StringComparison.OrdinalIgnoreCase) && Title(window) == text);

    private static string Describe(IntPtr window) => Title(window) + ": " + string.Join(" | ", Children(window).Select(Title));
    private static string Title(IntPtr window)
    {
        var text = new StringBuilder(4096);
        // GetWindowText cannot read another process's edit control. WM_GETTEXT is a system
        // message, so user32 marshals its buffer across the process boundary (also in Wine).
        SendMessageTimeout(window, 0x000D, (IntPtr)text.Capacity, text, 0x0002, 1000, out _);
        return text.ToString();
    }
    private static string ClassName(IntPtr window)
    {
        var text = new StringBuilder(256);
        GetClassName(window, text, text.Capacity);
        return text.ToString();
    }
    private static string Hash(byte[] bytes) { using SHA256 hash = SHA256.Create(); return Convert.ToHexString(hash.ComputeHash(bytes)); }
    private static string HashFile(string path) { using var file = File.OpenRead(path); using SHA256 hash = SHA256.Create(); return Convert.ToHexString(hash.ComputeHash(file)); }
    private static void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private sealed record ProcessResult(int ExitCode, string Output, string Error);
    private delegate bool WindowCallback(IntPtr window, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumWindows(WindowCallback callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr parent, WindowCallback callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] private static extern bool IsWindowEnabled(IntPtr window);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr window, StringBuilder text, int capacity);
    [DllImport("user32.dll")] private static extern bool PostMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr SendMessageTimeout(IntPtr window, uint message, IntPtr wParam, StringBuilder lParam,
        uint flags, uint timeout, out IntPtr result);
}
