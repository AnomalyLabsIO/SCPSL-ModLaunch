using System.Buffers.Binary;
using System.Reflection;
using Il2CppDumper;
using SCPSL_ModPatch;
using SCPSL_ModPatch.IL2Cpp;
using SCPSL_ModPatch.PatchUtils;

internal static class ConsolidationTests
{
    public static void Register(Action<string, Action> run)
    {
        run("method indexes preserve first ordinary lookup and all distinct native addresses", () =>
        {
            var fixture = new SyntheticPe(new(SyntheticPe.A, 0, 0x40),
                new(SyntheticPe.A, 0, 0x40), new(SyntheticPe.A, 0x40, 0x40));
            Patcher patcher = fixture.CreatePatcher(Profile(new PatchMethodInfo { name = SyntheticPe.A, patchData = "C3" }));
            Il2cppManager manager = GetManager(patcher);
            manager.GetMethodsDictionary();

            Check(manager.MethodsDictionary[SyntheticPe.A].Address == SyntheticPe.TextRva,
                "Ordinary method lookup did not retain its first entry.");
            IReadOnlyCollection<ulong> addresses = manager.GetDistinctMethodAddresses(SyntheticPe.A);
            Check(addresses.Count == 2 && addresses.Contains((ulong)SyntheticPe.TextRva) &&
                addresses.Contains((ulong)(SyntheticPe.TextRva + 0x40)), "Distinct method addresses lost or duplicated an entry.");
            Check(manager.GetDistinctMethodAddresses("Fixture.Missing$$Run").Count == 0,
                "An absent method acquired a native address.");
            patcher.PatchGameAssembly();
            Check(fixture.Image[SyntheticPe.TextRaw] == 0xC3 && fixture.Image[SyntheticPe.TextRaw + 0x40] == 0xCC,
                "The ordinary patch path changed which duplicate method it patches.");
        });

        run("pattern operations refresh mutable script ambiguity without changing ordinary lookup", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            Patcher patcher = fixture.CreatePatcher(Profile(Pattern()));
            Il2cppManager manager = GetManager(patcher);
            manager.GetMethodsDictionary();
            var duplicate = new ScriptMethod { Name = SyntheticPe.A, Address = SyntheticPe.TextRva + 0x40 };
            manager.ScriptJson.ScriptMethod.Add(duplicate);
            byte[] original = (byte[])fixture.Image.Clone();

            Expect<InvalidDataException>(patcher.PatchGameAssembly);
            Check(fixture.Image.SequenceEqual(original), "A newly ambiguous method left a partial patch.");
            Check(manager.MethodsDictionary[SyntheticPe.A].Address == SyntheticPe.TextRva,
                "Refreshing ambiguity changed the ordinary first-entry lookup.");

            manager.ScriptJson.ScriptMethod.Remove(duplicate);
            patcher.PatchGameAssembly();
            Check(fixture.Image[SyntheticPe.TextRaw + 4] == 0xC3,
                "The removed duplicate remained in the ambiguity index.");
        });

        run("legacy method evidence refreshes replaced and removed script names independently of ordinary lookup", () =>
        {
            var fixture = new SyntheticPe();
            Patcher patcher = fixture.CreatePatcher(Profile());
            Il2cppManager manager = GetManager(patcher);
            manager.GetMethodsDictionary();
            manager.ScriptJson.ScriptMethod.RemoveAll(method => method.Name == SyntheticPe.A || method.Name == SyntheticPe.B);
            manager.ScriptJson.ScriptMethod.Add(new ScriptMethod { Name = SyntheticPe.A, Address = SyntheticPe.TextRva + 0x40 });
            manager.RefreshMethodAddresses();

            NativeMethodMap map = manager.GetNativeMethodMap(fixture.Image);
            LegacyReleaseVersionReader.Method replacement = GetLegacyMethod(patcher, SyntheticPe.A, map);
            Check(replacement.Rva == SyntheticPe.TextRva + 0x40 && replacement.Range.Offset == SyntheticPe.TextRaw + 0x40,
                "Legacy evidence retained an address from the replaced script entry.");
            Expect<InvalidDataException>(() => GetLegacyMethod(patcher, SyntheticPe.B, map));
            Check(manager.MethodsDictionary[SyntheticPe.A].Address == SyntheticPe.TextRva && manager.MethodsDictionary.ContainsKey(SyntheticPe.B),
                "Refreshing current script evidence rewrote the ordinary lookup dictionary.");
        });

        run("native method map is reused while the image stays unchanged", () =>
        {
            var fixture = new SyntheticPe();
            Il2cppManager manager = GetManager(fixture.CreatePatcher(Profile()));
            NativeMethodMap first = manager.GetNativeMethodMap(fixture.Image);
            Check(ReferenceEquals(first, manager.GetNativeMethodMap(fixture.Image)),
                "An unchanged image rebuilt its native method map.");
            Check(first.GetMethodRange(SyntheticPe.TextRaw).Length == 0x40, "The cached map has incorrect method bounds.");
        });

        run("native method map rejects changed unwind evidence instead of returning stale bounds", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            Patcher patcher = fixture.CreatePatcher(Profile(Pattern()));
            Il2cppManager manager = GetManager(patcher);
            manager.GetNativeMethodMap(fixture.Image);
            fixture.Write32(SyntheticPe.OptionalHeader + 112 + 3 * 8 + 4, 11);
            byte[] changed = (byte[])fixture.Image.Clone();

            Expect<InvalidDataException>(patcher.PatchGameAssembly);
            Expect<InvalidDataException>(() => manager.GetNativeMethodMap(fixture.Image));
            Check(fixture.Image.SequenceEqual(changed), "Rejecting changed native bounds modified the image.");
            Check(patcher.PatchOutcomes.Count == 0, "Rejected native evidence reported an applied pattern patch.");
        });

        run("a different image buffer uses its own native evidence without replacing the loaded-image cache", () =>
        {
            var fixture = new SyntheticPe();
            Il2cppManager manager = GetManager(fixture.CreatePatcher(Profile()));
            NativeMethodMap original = manager.GetNativeMethodMap(fixture.Image);
            byte[] other = (byte[])fixture.Image.Clone();
            BinaryPrimitives.WriteInt32LittleEndian(other.AsSpan(SyntheticPe.PdataRaw + 4), SyntheticPe.TextRva + 0x30);

            NativeMethodMap otherMap = manager.GetNativeMethodMap(other);

            Check(!ReferenceEquals(original, otherMap) && otherMap.GetMethodRange(SyntheticPe.TextRaw).Length == 0x30,
                "A different buffer reused the loaded image's native evidence.");
            Check(ReferenceEquals(original, manager.GetNativeMethodMap(fixture.Image)),
                "Reading a different buffer replaced the unchanged loaded-image cache.");
        });

        run("applying a patch refreshes cached native method bounds", () =>
        {
            var fixture = new SyntheticPe();
            // Legacy offsets may edit bytes outside the named function, including PE evidence.
            var patch = new PatchMethodInfo
            {
                name = SyntheticPe.A, patchOffset = SyntheticPe.PdataRaw + 4 - SyntheticPe.TextRaw, patchData = "30 10 00 00"
            };
            Patcher patcher = fixture.CreatePatcher(Profile(patch));
            Il2cppManager manager = GetManager(patcher);
            NativeMethodMap before = manager.GetNativeMethodMap(fixture.Image);

            patcher.PatchGameAssembly();

            NativeMethodMap after = manager.GetNativeMethodMap(fixture.Image);
            Check(!ReferenceEquals(before, after) && after.GetMethodRange(SyntheticPe.TextRaw).Length == 0x30,
                "A patch reused native bounds from before its PE edits.");
        });

        run("changing game version refreshes the shared native method map", () =>
        {
            var fixture = new SyntheticPe();
            VersionRangeInfo profile = Profile();
            profile.methods.gameVersionMethod = VersionMethod(0, 1, 2, 3);
            Patcher patcher = fixture.CreatePatcher(profile);
            Il2cppManager manager = GetManager(patcher);
            NativeMethodMap before = manager.GetNativeMethodMap(fixture.Image);

            patcher.ChangeGameVersion(new GameVersion(10, 2, 3, 0));

            Check(!ReferenceEquals(before, manager.GetNativeMethodMap(fixture.Image)),
                "A version edit retained the map associated with the previous image.");
            Check(patcher.GetGameVersion().Equals(new GameVersion(10, 2, 3, 0)), "The version edit changed its existing behavior.");
        });

        run("a partially failing version edit cannot leave stale native method bounds", () =>
        {
            var fixture = new SyntheticPe();
            VersionRangeInfo profile = Profile();
            profile.methods.gameVersionMethod = VersionMethod(SyntheticPe.PdataRaw + 4 - SyntheticPe.TextRaw,
                fixture.Image.Length - SyntheticPe.TextRaw, 2, 3);
            Patcher patcher = fixture.CreatePatcher(profile);
            Il2cppManager manager = GetManager(patcher);
            NativeMethodMap before = manager.GetNativeMethodMap(fixture.Image);

            // The existing version writer changes fields in order; the second invalid offset throws.
            Expect<IndexOutOfRangeException>(() => patcher.ChangeGameVersion(new GameVersion(0x30, 2, 3, 0)));

            NativeMethodMap after = manager.GetNativeMethodMap(fixture.Image);
            Check(!ReferenceEquals(before, after) && after.GetMethodRange(SyntheticPe.TextRaw).Length == 0x30,
                "A failed version edit returned bounds from before its first successful write.");
        });

        run("in-memory metadata bypasses corrupt disk bytes and remains independent of parser storage", () =>
        {
            byte[] metadata = new byte[512];
            BinaryPrimitives.WriteUInt32LittleEndian(metadata, 0xFAB11BAF);
            BinaryPrimitives.WriteInt32LittleEndian(metadata.AsSpan(4), 29);
            byte[] original = (byte[])metadata.Clone();
            string path = Path.Combine(Path.GetTempPath(), $"SCPSL.ModPatch.Metadata-{Guid.NewGuid():N}.dat");
            byte[] corrupt = new byte[] { 1, 2, 3, 4 };
            File.WriteAllBytes(path, corrupt);
            try
            {
                // Unsupported image magic stops initialization after the real metadata parser has loaded.
                var manager = new Il2cppManager(corrupt, interactive: false);
                try { manager.LoadIl2cpp(path, metadataData: metadata); }
                catch (Il2cppInitException ex)
                {
                    Check(ex.Message.Contains("il2cpp file not supported", StringComparison.Ordinal),
                        "Initialization read the corrupt disk metadata instead of the supplied metadata bytes.");
                    using Stream parser = GetMetadataStream(manager.Metadata);
                    Check(metadata.SequenceEqual(original), "Loading metadata modified the supplied session bytes.");
                    metadata[400] = 0x5A;
                    parser.Position = 400;
                    Check(parser.ReadByte() == 0, "The metadata parser retained the caller's writable array.");
                    parser.Position = 401;
                    parser.WriteByte(0xA5);
                    Check(metadata[401] == 0, "Parser writes changed the caller's metadata array.");
                    Check(File.ReadAllBytes(path).SequenceEqual(corrupt), "In-memory parsing changed the disk metadata.");
                    return;
                }
                throw new Exception("The unsupported image unexpectedly initialized.");
            }
            finally { File.Delete(path); }
        });
    }

    private static Il2cppManager GetManager(Patcher patcher) =>
        (Il2cppManager)typeof(Patcher).GetField("_il2cppManager", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(patcher)!;

    private static LegacyReleaseVersionReader.Method GetLegacyMethod(Patcher patcher, string name, NativeMethodMap map)
    {
        try
        {
            return (LegacyReleaseVersionReader.Method)typeof(Patcher).GetMethod("GetLegacyVersionMethod", BindingFlags.Instance | BindingFlags.NonPublic)!
                .Invoke(patcher, new object[] { name, map })!;
        }
        catch (TargetInvocationException ex) when (ex.InnerException is InvalidDataException)
        {
            throw (InvalidDataException)ex.InnerException;
        }
    }

    private static Stream GetMetadataStream(Metadata metadata)
    {
        if (metadata.GetType().GetProperty("BaseStream")?.GetValue(metadata) is Stream stream)
            return stream;
        for (Type? type = metadata.GetType(); type != null; type = type.BaseType)
        {
            BinaryReader? reader = type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
                .Select(field => field.GetValue(metadata)).OfType<BinaryReader>().FirstOrDefault();
            if (reader != null) return reader.BaseStream;
        }
        throw new Exception("The metadata parser's source stream was not found.");
    }

    private static VersionRangeInfo Profile(params PatchMethodInfo[] patches) =>
        new() { methods = new MethodsInfo { patchMethods = patches } };

    private static PatchMethodInfo Pattern() => new() { name = SyntheticPe.A, patchPattern = "DE AD BE EF", patchData = "C3" };

    private static GameVersionMethodInfo VersionMethod(int major, int minor, int revision, int type) =>
        new() { name = SyntheticPe.A, majorOffset = major, minorOffset = minor, revisionOffset = revision, typeOffset = type };

    private static void Expect<TException>(Action action) where TException : Exception
    {
        try { action(); }
        catch (TException) { return; }
        throw new Exception($"Expected {typeof(TException).Name}.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}
