using System.Net;
using SCPSL_ModPatch;

internal static class PatchInfoUpdateTests
{
    public static void Register(Action<string, Action> run)
    {
        run("successful patch info download replaces the existing file without temporary leftovers", () =>
        {
            using var fixture = new Fixture();
            string json = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "patchinfo.json"));
            using var client = new HttpClient(new ResponseHandler(HttpStatusCode.OK, json));
            Updater.UpdatePatchInfoAsync(fixture.Path, client).GetAwaiter().GetResult();
            Check(File.ReadAllText(fixture.Path) == json, "The acquired manifest was not saved.");
            Check(!Directory.GetFiles(fixture.Root, "*.tmp").Any(), "A temporary download was left behind.");
        });

        run("failed patch info downloads preserve the existing file", () =>
        {
            using var fixture = new Fixture();
            using var client = new HttpClient(new ResponseHandler(HttpStatusCode.NotFound, "not found"));
            RejectUnchanged<HttpRequestException>(fixture, client);
        });

        run("invalid patch info downloads preserve the existing file", () =>
        {
            foreach (string json in new[] { "<html>unavailable</html>", "null", "{}", "{\"versionRanges\":[]}",
                "{\"versionRanges\":[{\"versionFrom\":\"invalid\"}]}" })
            {
                using var fixture = new Fixture();
                using var client = new HttpClient(new ResponseHandler(HttpStatusCode.OK, json));
                RejectUnchanged<Exception>(fixture, client);
            }
        });
    }

    private static void RejectUnchanged<T>(Fixture fixture, HttpClient client) where T : Exception
    {
        try
        {
            Updater.UpdatePatchInfoAsync(fixture.Path, client).GetAwaiter().GetResult();
        }
        catch (T)
        {
            Check(File.ReadAllText(fixture.Path) == Fixture.Original, "A failed download replaced the existing manifest.");
            Check(!Directory.GetFiles(fixture.Root, "*.tmp").Any(), "A failed download left a temporary file.");
            return;
        }
        throw new InvalidOperationException("The invalid download was accepted.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class ResponseHandler : HttpMessageHandler
    {
        private readonly HttpStatusCode _status;
        private readonly string _content;

        public ResponseHandler(HttpStatusCode status, string content)
        {
            _status = status;
            _content = content;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Check(request.RequestUri!.AbsoluteUri ==
                "https://raw.githubusercontent.com/AnomalyLabsIO/SCPSL-ModPatch/refs/heads/master/Shared_Files/patchinfo.json",
                "The updater requested an unexpected feed.");
            return Task.FromResult(new HttpResponseMessage(_status) { Content = new StringContent(_content) });
        }
    }

    private sealed class Fixture : IDisposable
    {
        public const string Original = "existing local manifest";
        public string Root { get; } = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "ModPatch-Update-" + Guid.NewGuid().ToString("N"));
        public string Path => System.IO.Path.Combine(Root, "patchinfo.json");

        public Fixture()
        {
            Directory.CreateDirectory(Root);
            File.WriteAllText(Path, Original);
        }

        public void Dispose() => Directory.Delete(Root, recursive: true);
    }
}
