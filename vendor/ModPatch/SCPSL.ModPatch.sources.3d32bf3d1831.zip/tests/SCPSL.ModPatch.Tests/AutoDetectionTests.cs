using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class AutoDetectionTests
{
    private static readonly string UnknownHash = new('0', 64);

    public static void Register(Action<string, Action> run)
    {
        foreach (string resource in new[] { "2019.3.0.14561972", "2019.3.15.5898046", "2021.3.17.123456", "6000.0.43.123456", "6000.0.43f1", "2019.3.0b9" })
        {
            string captured = resource;
            run("Automatic detection preserves Unity resource identity " + captured, () =>
                Check(PatchSession.ParseUnityVersion(captured) == captured, "Numeric build identity was rejected or reinterpreted as a release suffix."));
        }
        run("Unity resource parsing rejects partial malformed versions", () =>
        {
            foreach (string resource in new[] { "", "2019.3", "2019.3.0b", "2019.3.0garbage", "2019.3.0.1.2" })
                Check(PatchSession.ParseUnityVersion(resource) == null, "Malformed Unity identity was partially accepted: " + resource);
            Check(PatchSession.ParseUnityVersion("6000.0.43f1 (release)") == "6000.0.43f1", "A resource annotation hid the Unity version.");
        });
        run("Complete shipped feed bootstraps every parser family from numeric resources", () =>
        {
            PatchInfo info = CanonicalInfo();
            foreach ((string resource, int schema) in new[]
            {
                ("2019.3.0.14561972", 24), ("2019.3.15.5898046", 24),
                ("2019.4.16.123456", 24), ("2021.3.17.123456", 29), ("6000.0.43.123456", 31)
            })
            {
                VersionRangeInfo? bootstrap = PatchSession.ResolveUnityBootstrap(info, resource);
                Check(bootstrap?.metadataVersion == schema, "Wrong or absent parser for " + resource);
            }
            Check(PatchSession.ResolveUnityBootstrap(info, "6000.0.99f1") == null, "An unknown Unity release selected known parser settings.");
            foreach (int schema in new[] { 24, 29, 31 })
                Check(PatchSession.ResolveUnityBootstrap(info, null, schema)?.metadataVersion == schema, "Missing UnityPlayer did not use the unambiguous metadata parser family.");
            Check(PatchSession.ResolveUnityBootstrap(info, null, 999) == null, "Unknown metadata selected an arbitrary parser family.");
        });
        run("Unity bootstrap separates parser settings from reader offsets", () =>
        {
            VersionRangeInfo a = Profile("13.0.0", "13.5.1", 0x10);
            VersionRangeInfo b = Profile("14.0.0", "14.0.3", 0x80);
            var info = new PatchInfo { versionRanges = new[] { a, b } };
            Check(ReferenceEquals(PatchSession.ResolveUnityBootstrap(info, "2021.3.17f1"), a), "Shared parser settings were rejected because readers differ.");
            b.metadataVersion = 31;
            Check(PatchSession.ResolveUnityBootstrap(info, "2021.3.17f1") == null, "Conflicting parsers were chosen by manifest order.");
            Check(ReferenceEquals(PatchSession.ResolveUnityBootstrap(info, "2021.3.17f1", 31), b), "Metadata identity did not disambiguate parser settings.");
        });
        run("Numeric Unity identity retains release-channel ambiguity until native detection", () =>
        {
            VersionRangeInfo a = Profile("9.0.0", "9.1.3", 0x10);
            VersionRangeInfo b = Profile("10.0.0", "10.0.6", 0x80);
            a.cleanLauncherPath = "clean_launchers/2019.3.0b9/SCPSL.exe";
            b.cleanLauncherPath = "clean_launchers/2019.3.0f1/SCPSL.exe";
            var info = new PatchInfo { versionRanges = new[] { a, b } };
            VersionRangeInfo[] candidates = PatchSession.GetUnityCandidates(info, "2019.3.0.14561972");
            Check(candidates.Length == 2, "A numeric resource guessed a release channel.");
            Check(PatchSession.GetUnityCandidates(info, "2019.3.0b9").SequenceEqual(new[] { a }), "An explicit release suffix was broadened.");
            var pe = NativeFixture();
            PutVersion(pe, b, new GameVersion(10, 0, 0, 0));
            var selected = Detect(info, candidates, pe);
            Check(ReferenceEquals(selected.Target, b) && selected.Target.cleanLauncherPath == b.cleanLauncherPath, "Unity path selected the game/launcher before native identity.");
        });
        foreach ((string version, int majorOffset, int schema, bool auto, byte typeField) in new[]
        {
            ("10.2.0", 52, 24, false, (byte)3),
            ("11.1.5", 52, 24, false, (byte)3),
            ("13.4.2", 125, 29, false, (byte)4),
            ("13.6.9", 152, 29, true, (byte)4),
            ("14.0.2", 152, 29, true, (byte)4),
            ("14.1.0", 173, 31, true, (byte)4),
            ("14.1.3", 158, 31, true, (byte)4)
        })
        {
            string capturedVersion = version;
            run("Complete shipped feed automatically selects native profile and launcher for " + capturedVersion, () =>
            {
                PatchInfo info = CanonicalInfo();
                Version numeric = new(capturedVersion);
                VersionRangeInfo expected = PatchTargetResolver.Resolve(info, UnknownHash, numeric);
                string unity = expected.cleanLauncherPath.Replace('\\', '/').Split('/')[2];
                VersionRangeInfo? bootstrap = PatchSession.ResolveUnityBootstrap(info, unity, schema);
                Check(bootstrap?.metadataVersion == schema, "Wrong shared metadata parser.");
                var pe = NativeFixture();
                var emitted = Profile(capturedVersion, capturedVersion, majorOffset, auto);
                emitted.methods.gameVersionMethod!.minorOffset = majorOffset + 18;
                emitted.methods.gameVersionMethod.revisionOffset = majorOffset + 36;
                emitted.methods.gameVersionMethod.typeOffset = typeField == 3 ? majorOffset + 54 : majorOffset + 72;
                PutVersion(pe, emitted, new GameVersion((byte)numeric.Major, (byte)numeric.Minor, (byte)numeric.Build, 0), typeField);
                var selected = Detect(info, PatchSession.GetUnityCandidates(info, unity), pe);
                Check(ReferenceEquals(selected.Target, expected) && selected.Version?.ToString() == capturedVersion,
                    "Wrong final target/version with the full canonical feed.");
                Check(selected.Target.metadataVersion == schema, "A different parser family selected the final target.");
            });
        }
        run("Automatic native detection rejects plausible raw version bytes without instruction evidence", () =>
        {
            VersionRangeInfo target = Profile("14.0.0", "14.0.3", 0x10);
            var info = new PatchInfo { versionRanges = new[] { target } };
            var pe = NativeFixture();
            GameVersionMethodInfo reader = target.methods.gameVersionMethod!;
            pe.Put(reader.majorOffset, 14);
            pe.Put(reader.minorOffset, 0);
            pe.Put(reader.revisionOffset, 2);
            pe.Put(reader.typeOffset, 0);
            Check(pe.CreatePatcher(target).GetGameVersion().ToString() == "14.0.2", "Fixture does not reproduce the unsafe raw-byte reader.");
            Reject(() => Detect(info, info.versionRanges, pe));
        });
        run("Automatic native detection rejects auto offsets found in the next method", () =>
        {
            VersionRangeInfo target = Profile("14.0.0", "14.0.3", 0x90, auto: true);
            var info = new PatchInfo { versionRanges = new[] { target } };
            var pe = new SyntheticPe(new("GameCore.Version$$.cctor", 0, 0x80), new("Fixture.Other$$.cctor", 0x80, 0x180));
            pe.Image.AsSpan(SyntheticPe.TextRaw, 0x200).Fill(0x90);
            PutVersion(pe, target, new GameVersion(14, 0, 2, 0));
            Reject(() => Detect(info, info.versionRanges, pe));
        });
        run("Automatic native detection rejects real reader ambiguity in either manifest order", () =>
        {
            VersionRangeInfo a = Profile("13.0.0", "13.5.1", 0x10);
            VersionRangeInfo b = Profile("14.0.0", "14.0.3", 0x80);
            var pe = NativeFixture();
            PutVersion(pe, a, new GameVersion(13, 4, 2, 0));
            PutVersion(pe, b, new GameVersion(14, 0, 2, 0));
            foreach (VersionRangeInfo[] order in new[] { new[] { a, b }, new[] { b, a } })
                Reject(() => Detect(new PatchInfo { versionRanges = order }, order, pe));
        });
        run("Native reader cannot bypass exact-version precedence by resolving through a range", () =>
        {
            VersionRangeInfo range = Profile("14.0.0", "14.0.3", 0x10);
            VersionRangeInfo exact = Profile("14.0.2", "14.0.2", 0x80);
            exact.version = "14.0.2";
            exact.versionFrom = exact.versionTo = string.Empty;
            var info = new PatchInfo { versionRanges = new[] { range, exact } };
            var pe = NativeFixture();
            PutVersion(pe, range, new GameVersion(14, 0, 2, 0));
            Reject(() => Detect(info, info.versionRanges, pe));
            PutVersion(pe, exact, new GameVersion(14, 0, 2, 0));
            Check(ReferenceEquals(Detect(info, info.versionRanges, pe).Target, exact), "Exact target lost its precedence or did not confirm through its own reader.");
        });
        run("Native detection preserves hash precedence over reader and Unity ambiguity", () =>
        {
            VersionRangeInfo range = Profile("14.0.0", "14.0.3", 0x10);
            VersionRangeInfo hash = new() { gameAssemblySha256 = UnknownHash, cleanLauncherPath = "hash-launcher.exe", metadataVersion = 24 };
            var info = new PatchInfo { versionRanges = new[] { range, hash } };
            var selected = PatchSession.ResolveDetectedTarget(info, UnknownHash, new[] { range }, target =>
            {
                Check(ReferenceEquals(target, hash), "A version reader ran before the exact native hash was honored.");
                return null;
            });
            Check(ReferenceEquals(selected.Target, hash), "Hash identity did not supply the final target.");
        });
        run("Native detection does not hide duplicate target-selector ambiguity", () =>
        {
            VersionRangeInfo a = Profile("14.0.0", "14.0.3", 0x10);
            VersionRangeInfo b = Profile("14.0.0", "14.0.3", 0x10);
            var info = new PatchInfo { versionRanges = new[] { a, b } };
            var pe = NativeFixture();
            PutVersion(pe, a, new GameVersion(14, 0, 2, 0));
            Reject(() => Detect(info, info.versionRanges, pe));
        });
        run("Auto-reader offset results do not create extra reader identities", () =>
        {
            VersionRangeInfo a = Profile("14.0.0", "14.0.1", 0x10, auto: true);
            VersionRangeInfo b = Profile("14.0.2", "14.0.3", 0x80, auto: true);
            var info = new PatchInfo { versionRanges = new[] { a, b } };
            int reads = 0;
            var selected = PatchSession.ResolveDetectedTarget(info, UnknownHash, info.versionRanges, target =>
            {
                reads++;
                target.methods.gameVersionMethod!.majorOffset = 173;
                return new GameVersion(14, 0, 2, 0);
            });
            Check(reads == 1 && ReferenceEquals(selected.Target, b), "Mutable discovered offsets changed the reader identity or hid the final target.");
        });
    }

    private static PatchInfo CanonicalInfo() => JsonConvert.DeserializeObject<PatchInfo>(
        File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "patchinfo.json")))!;

    private static VersionRangeInfo Profile(string from, string to, int major, bool auto = false) => new()
    {
        versionFrom = from, versionTo = to, metadataVersion = 29,
        cleanLauncherPath = "clean_launchers/2021.3.17f1/SCPSL.exe",
        methods = new() { gameVersionMethod = new() { majorOffset = major, minorOffset = major + 0x10,
            revisionOffset = major + 0x20, typeOffset = major + 0x30, autoFindOffsets = auto } }
    };

    private static SyntheticPe NativeFixture()
    {
        var fixture = new SyntheticPe(new SyntheticPe.Method("GameCore.Version$$.cctor", 0, 0x300));
        fixture.Image.AsSpan(SyntheticPe.TextRaw, 0x300).Fill(0x90);
        return fixture;
    }

    private static void PutVersion(SyntheticPe pe, VersionRangeInfo profile, GameVersion version, byte typeField = 4)
    {
        GameVersionMethodInfo reader = profile.methods.gameVersionMethod!;
        pe.Put(reader.majorOffset - 9, 0x48, 0x8B, 0x88, 0xB8, 0x00, 0x00, 0x00);
        pe.Put(reader.majorOffset - 2, 0xC6, 0x01, version.major);
        pe.Put(reader.minorOffset - 3, 0xC6, 0x41, 1, version.minor);
        pe.Put(reader.revisionOffset - 3, 0xC6, 0x41, 2, version.revision);
        pe.Put(reader.typeOffset - 3, 0xC6, 0x41, typeField, (byte)version.type!.Value);
    }

    private static (VersionRangeInfo Target, GameVersion? Version) Detect(PatchInfo info, IEnumerable<VersionRangeInfo> candidates, SyntheticPe pe) =>
        PatchSession.ResolveDetectedTarget(info, UnknownHash, candidates, target =>
        {
            Patcher reader = pe.CreatePatcher(target);
            if (target.methods.gameVersionMethod!.autoFindOffsets)
                reader.AutoFindGameVersionOffsets();
            reader.VerifyGameVersionReader();
            return reader.GetGameVersion();
        });

    private static void Reject(Action action)
    {
        try { action(); }
        catch (InvalidDataException) { return; }
        throw new InvalidOperationException("Ambiguous or unqualified automatic detection was accepted.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
