using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SCPSL_ModPatch.CommandLine;
using System.Globalization;
using System.Text.Json;

internal static class CliContractRegressionTests
{
    public static void Register(Action<string, Action> run)
    {
        foreach (string syntax in new[] { "comments", "trailing commas", "mixed case", "duplicate case" })
        {
            string capturedSyntax = syntax;
            foreach (bool malformedArguments in new[] { true, false })
            {
                bool capturedMalformed = malformedArguments;
                run($"CLI protects external launchers from reports with {syntax} before {(malformedArguments ? "argument failure" : "profile failure")}", () =>
                {
                    using var fixture = new Fixture();
                    fixture.WriteManifest(capturedSyntax);
                    string[] destinations = capturedSyntax == "duplicate case"
                        ? new[] { fixture.Launcher, fixture.OtherLauncher } : new[] { fixture.Launcher };
                    foreach (string destination in destinations)
                    {
                        byte[] original = File.ReadAllBytes(destination);
                        int code = HeadlessCommand.Run(fixture.Arguments(destination,
                            capturedMalformed ? new[] { "--unknown", "value" } : new[] { "--profile", "nonexistent profile" }));
                        Check(code == 2, "Unsafe report destination was not rejected as an argument error.");
                        Check(File.ReadAllBytes(destination).SequenceEqual(original), "Error reporting overwrote a manifest-referenced input.");
                    }
                    fixture.AssertInputsUnchanged();
                });
            }
            run($"CLI accepts production manifest {syntax} at a safe report destination", () =>
            {
                using var fixture = new Fixture();
                fixture.WriteManifest(capturedSyntax);
                Check(!File.Exists(fixture.Assembly), "Preflight fixture unexpectedly contains an assembly.");
                JsonElement report = fixture.Run(1, "--clean-launcher", fixture.Launcher);
                AssertEnvelope(report, 1);
                Check(report.GetProperty("stage").GetString() == "preflight", "Missing native input did not fail during preflight.");
                Check(report.GetProperty("backend").GetString() == "il2cpp", "Native preflight failure lost its backend identity.");
                Check(report.GetProperty("modifiedFiles").GetArrayLength() == 0, "Missing input reported game modifications.");
                Check(report.GetProperty("error").GetProperty("message").GetString()!
                    .Contains("GameAssembly.dll", StringComparison.Ordinal), "Manifest did not reach native input preflight.");
                fixture.AssertInputsUnchanged();
            });
        }


        foreach (string scenario in new[] { "help", "arguments", "missing game", "missing manifest" })
        {
            string captured = scenario;
            run("CLI leaves backend unknown before detection: " + scenario, () =>
            {
                using var fixture = new Fixture();
                fixture.WriteManifest("plain");
                string[] args;
                int expectedCode;
                if (captured == "help")
                {
                    args = new[] { "--help", "--result", fixture.Report };
                    expectedCode = 0;
                }
                else if (captured == "arguments")
                {
                    args = fixture.Arguments(fixture.Report, "--unknown", "value");
                    expectedCode = 2;
                }
                else
                {
                    if (captured == "missing game") Directory.Delete(fixture.Game, recursive: true);
                    if (captured == "missing manifest") File.Delete(fixture.Manifest);
                    args = fixture.Arguments(fixture.Report);
                    expectedCode = 1;
                }
                Check(HeadlessCommand.Run(args) == expectedCode, "Unexpected exit code before backend detection.");
                JsonElement report = ReadReport(fixture.Report);
                AssertEnvelope(report, expectedCode);
                Check(report.GetProperty("backend").ValueKind == JsonValueKind.Null, "Report claimed a backend before one was detected.");
                Check(report.GetProperty("modifiedFiles").GetArrayLength() == 0, "Early command reported game modifications.");
            });
        }

        run("CLI conversion failures retain the failing manifest field context", () =>
        {
            using var fixture = new Fixture();
            fixture.WriteManifest("invalid metadata");
            JsonElement report = fixture.Run(1);
            AssertEnvelope(report, 1);
            Check(report.GetProperty("stage").GetString() == "preflight", "Invalid field escaped manifest preflight.");
            Check(report.GetProperty("error").GetProperty("message").GetString()!
                .Contains("versionRanges[0].metadataVersion", StringComparison.Ordinal),
                "Conversion failure lost the manifest field that requires correction.");
            fixture.AssertInputsUnchanged();
        });

        run("CLI preserves an existing result when malformed definitions prevent safety discovery", () =>
        {
            using var fixture = new Fixture();
            File.WriteAllText(fixture.Manifest, "{ invalid JSON");
            byte[] original = { 1, 2, 3, 4 };
            File.WriteAllBytes(fixture.Report, original);
            Check(HeadlessCommand.Run(fixture.Arguments(fixture.Report)) == 2, "Unverified result destination was accepted.");
            Check(File.ReadAllBytes(fixture.Report).SequenceEqual(original), "Safety discovery failure replaced the existing result.");
        });

        run("CLI preserves an existing result when definitions cannot be inspected", () =>
        {
            using var fixture = new Fixture();
            fixture.WriteManifest("plain");
            byte[] original = { 5, 6, 7, 8 };
            File.WriteAllBytes(fixture.Report, original);
            using (var locked = new FileStream(fixture.Manifest, FileMode.Open, FileAccess.Read, FileShare.None))
                Check(HeadlessCommand.Run(fixture.Arguments(fixture.Report)) == 2, "Unreadable definitions did not stop report emission.");
            Check(File.ReadAllBytes(fixture.Report).SequenceEqual(original), "Inspection failure replaced the existing result.");
            fixture.AssertInputsUnchanged();
        });
    }

    internal static void AssertEnvelope(JsonElement report, int exitCode)
    {
        Check(report.GetProperty("schemaVersion").GetInt32() == 1, "Unexpected report schema version.");
        Check(report.GetProperty("exitCode").GetInt32() == exitCode && report.GetProperty("success").GetBoolean() == (exitCode == 0),
            "Report status differs from the process result.");
        Check(report.EnumerateObject().All(property => char.IsLower(property.Name[0])), "Report property names are not camelCase.");
        Check(DateTimeOffset.TryParse(report.GetProperty("startedUtc").GetString(), CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind, out DateTimeOffset started), "Invalid report start timestamp.");
        Check(DateTimeOffset.TryParse(report.GetProperty("completedUtc").GetString(), CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind, out DateTimeOffset completed) && completed >= started, "Invalid report completion timestamp.");
        foreach (string property in new[] { "gameVersion", "profile", "metadataMode", "bundleVersion", "help", "error" })
            Check(report.TryGetProperty(property, out _), "Report omitted contract field: " + property);
    }

    private static JsonElement ReadReport(string path)
    {
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(path));
        return document.RootElement.Clone();
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class Fixture : IDisposable
    {
        public string Root { get; } = Path.Combine(Path.GetTempPath(), "ModPatch-cli-contract-" + Guid.NewGuid().ToString("N"));
        public string Game => Path.Combine(Root, "game");
        public string Manifest => Path.Combine(Root, "manifest.json");
        public string Report => Path.Combine(Root, "result.json");
        public string Launcher => Path.Combine(Root, "external launcher.bin");
        public string OtherLauncher => Path.Combine(Root, "other launcher.bin");
        public string Assembly => Path.Combine(Game, "GameAssembly.dll");
        public string AssemblyHash { get; private set; } = new string('A', 64);
        private readonly Dictionary<string, byte[]> inputs = new(StringComparer.OrdinalIgnoreCase);

        public Fixture()
        {
            try
            {
                Directory.CreateDirectory(Game);
                File.WriteAllBytes(Launcher, new byte[] { 0x4D, 0x5A, 0x01, 0x02 });
                File.WriteAllBytes(OtherLauncher, new byte[] { 0x4D, 0x5A, 0x03, 0x04 });
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        public string[] Arguments(string report, params string[] extra) => new[]
        {
            "patch", "--game-dir", Game, "--patch-info", Manifest, "--result", report
        }.Concat(extra).ToArray();

        public JsonElement Run(int expectedCode, params string[] extra)
        {
            Check(HeadlessCommand.Run(Arguments(Report, extra)) == expectedCode, "Unexpected CLI exit code.");
            return ReadReport(Report);
        }


        public void WriteManifest(string syntax)
        {
            var target = new JObject
            {
                ["versionRange"] = "contract fixture",
                ["gameAssemblySha256"] = AssemblyHash,
                ["metadataVersion"] = 24,
                ["cleanLauncherPath"] = Path.GetFileName(Launcher),
                ["methods"] = new JObject { ["patchMethods"] = new JArray() }
            };
            if (syntax == "invalid metadata") target["metadataVersion"] = "not an integer";
            if (syntax == "duplicate case")
            {
                target["CLEANLAUNCHERPATH"] = Path.GetFileName(OtherLauncher);
            }
            var manifest = new JObject { ["versionRanges"] = new JArray(target) };
            if (syntax == "mixed case") UppercaseProperties(manifest);
            string json = manifest.ToString(Formatting.Indented);
            if (syntax == "comments") json = "/* production-compatible manifest */\n" + json.Replace("\"versionRanges\":", "\"versionRanges\": /* profiles */");
            if (syntax == "trailing commas") json = json.Insert(json.LastIndexOf('}'), ",\n");
            File.WriteAllText(Manifest, json);
            inputs.Clear();
            foreach (string path in new[] { Launcher, OtherLauncher, Assembly, Manifest })
                if (File.Exists(path)) inputs[path] = File.ReadAllBytes(path);
        }

        private static void UppercaseProperties(JToken token)
        {
            if (token is JObject value)
                foreach (JProperty property in value.Properties().ToArray())
                {
                    UppercaseProperties(property.Value);
                    property.Replace(new JProperty(property.Name.ToUpperInvariant(), property.Value));
                }
            else if (token is JArray array)
                foreach (JToken child in array) UppercaseProperties(child);
        }

        public void AssertInputsUnchanged()
        {
            foreach (var input in inputs)
                Check(File.ReadAllBytes(input.Key).SequenceEqual(input.Value), "CLI changed an input on failure: " + input.Key);
        }

        public void Dispose()
        {
            if (Directory.Exists(Root)) Directory.Delete(Root, recursive: true);
        }
    }
}
