using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using SCPSL_ModPatch.CommandLine;
using SCPSL_ModPatch.PatchUtils;

internal static class UnityBundleVersionCorrectionTests
{
    public static int RunFocused()
    {
        int passed = 0, failed = 0;
        Register((name, test) =>
        {
            try { test(); passed++; Console.WriteLine("PASS " + name); }
            catch (Exception error) { failed++; Console.Error.WriteLine("FAIL " + name + ": " + error); }
        });
        Console.WriteLine($"Bundle version: {passed} passed, {failed} failed.");
        return failed == 0 ? 0 : 1;
    }

    public static void Register(Action<string, Action> run)
    {
        run("bundle mode parser preserves existing behavior unless correction is requested", () =>
        {
            string[] basic = { "patch", "--game-dir", System.IO.Path.GetTempPath(), "--result", System.IO.Path.Combine(System.IO.Path.GetTempPath(), "unused-result.json") };
            Check(CliOptions.Parse(basic).BundleVersionMode == "preserve", "Bundle correction is no longer opt-in.");
            Check(CliOptions.Parse(basic.Concat(new[] { "--bundle-version-mode", "correct" }).ToArray()).BundleVersionMode == "correct",
                "Correction option was not selected.");
            try { CliOptions.Parse(basic.Concat(new[] { "--bundle-version-mode", "unexpected" }).ToArray()); }
            catch (CliUsageException) { return; }
            throw new InvalidOperationException("Unsupported correction mode was accepted.");
        });
        foreach (string command in new[] { "patch", "--help", "invalid-command" })
        {
            string captured = command;
            run("bundle asset cannot be used for the JSON result during " + captured, () =>
            {
                using var file = new AssetFixture("14.1.0");
                string game = System.IO.Path.GetDirectoryName(file.Path)!;
                string protectedAsset = System.IO.Path.Combine(game, "SCPSL_Data", "globalgamemanagers");
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(protectedAsset)!);
                byte[] original = File.ReadAllBytes(file.Path);
                File.WriteAllBytes(protectedAsset, original);
                int code = HeadlessCommand.Run(new[] { captured, "--game-dir", game, "--result", protectedAsset });
                Check(code == 2, "Unsafe report path was not rejected before command parsing.");
                Check(File.ReadAllBytes(protectedAsset).SequenceEqual(original), "CLI report output changed the protected asset.");
            });
        }
        run("bundle correction prepares bytes without writing its input", () =>
        {
            using var file = new AssetFixture("14.1.0");
            byte[] original = File.ReadAllBytes(file.Path);
            var correction = UnityBundleVersionCorrection.Prepare(file.Path, "14.2.8");
            Check(correction.Path == System.IO.Path.GetFullPath(file.Path), "Correction did not retain its absolute destination.");
            Check(correction.Before == "14.1.0" && correction.After == "14.2.8" && correction.Status == "applied", "Incorrect correction identity.");
            Check(correction.OriginalSha256 == Convert.ToHexString(SHA256.HashData(original)), "Prepared input hash differs from its bytes.");
            Check(File.ReadAllBytes(file.Path).SequenceEqual(original), "Preparation wrote to the input.");
            correction.Save();
            byte[] expected = (byte[])original.Clone();
            Encoding.ASCII.GetBytes("14.2.8").CopyTo(expected, 16);
            Check(File.ReadAllBytes(file.Path).SequenceEqual(expected), "Correction changed bytes outside the serialized version.");
        });
        run("already correct bundle does not change bytes or modification time", () =>
        {
            using var file = new AssetFixture("14.2.8");
            byte[] original = File.ReadAllBytes(file.Path);
            File.SetLastWriteTimeUtc(file.Path, new DateTime(2003, 4, 5, 6, 7, 8, DateTimeKind.Utc));
            DateTime before = File.GetLastWriteTimeUtc(file.Path);
            var correction = UnityBundleVersionCorrection.Prepare(file.Path, "14.2.8");
            Check(correction.Before == correction.After && correction.Status == "already-correct", "Correct version was reported as changed.");
            correction.Save();
            Check(File.GetLastWriteTimeUtc(file.Path) == before, "No-op correction wrote the file.");
            Check(File.ReadAllBytes(file.Path).SequenceEqual(original), "No-op correction changed file bytes.");
        });
        run("bundle correction preserves the next field when shortening within the same alignment", () =>
        {
            using var file = new AssetFixture("14.10.0");
            byte[] original = File.ReadAllBytes(file.Path);
            var correction = UnityBundleVersionCorrection.Prepare(file.Path, "14.2.8");
            correction.Save();
            byte[] result = File.ReadAllBytes(file.Path);
            Check(result.Length == original.Length && BinaryPrimitives.ReadInt32LittleEndian(result.AsSpan(12)) == 6,
                "Serialized string length or file length is wrong.");
            Check(Encoding.ASCII.GetString(result, 16, 6) == "14.2.8" && result[22] == 0, "Shortened version or cleared tail is incorrect.");
            Check(result[..12].SequenceEqual(original[..12]) && result[24..].SequenceEqual(original[24..]),
                "Shortening changed surrounding serialized bytes.");
        });
        foreach ((string original, string replacement) in new[] { ("14.1.0", "14.2.10"), ("114.111.0", "14.2.8") })
        {
            string previous = original, next = replacement;
            run($"bundle correction rejects unsafe string storage change {previous} to {next}", () =>
            {
                using var file = new AssetFixture(previous);
                byte[] original = File.ReadAllBytes(file.Path);
                ExpectInvalid(() => UnityBundleVersionCorrection.Prepare(file.Path, next));
                Check(File.ReadAllBytes(file.Path).SequenceEqual(original), "Unsafe correction changed the input.");
            });
        }
        foreach (string kind in new[] { "absent", "ambiguous", "truncated" })
        {
            string captured = kind;
            run("bundle correction rejects " + captured + " serialized version slots", () =>
            {
                using var file = new AssetFixture("14.1.0");
                byte[] bytes = File.ReadAllBytes(file.Path);
                bytes = captured switch
                {
                    "absent" => Enumerable.Repeat((byte)0xa5, 80).ToArray(),
                    "ambiguous" => bytes.Concat(bytes).ToArray(),
                    _ => bytes[..20]
                };
                File.WriteAllBytes(file.Path, bytes);
                ExpectInvalid(() => UnityBundleVersionCorrection.Prepare(file.Path, "14.2.8"));
                Check(File.ReadAllBytes(file.Path).SequenceEqual(bytes), "Rejected asset was written.");
            });
        }
        foreach (string version in new[] { "9.2.8", "14.256.8", "14.2.8.1", " 14.2.8" })
        {
            string captured = version;
            run("bundle correction rejects unsupported target version " + captured, () =>
            {
                using var file = new AssetFixture("14.1.0");
                byte[] original = File.ReadAllBytes(file.Path);
                ExpectInvalid(() => UnityBundleVersionCorrection.Prepare(file.Path, captured));
                Check(File.ReadAllBytes(file.Path).SequenceEqual(original), "Invalid version changed the asset.");
            });
        }
        run("bundle correction refuses a destination changed since preparation", () =>
        {
            using var file = new AssetFixture("14.1.0");
            var correction = UnityBundleVersionCorrection.Prepare(file.Path, "14.2.8");
            byte[] changed = File.ReadAllBytes(file.Path);
            changed[3] ^= 0x10;
            File.WriteAllBytes(file.Path, changed);
            ExpectInvalid(correction.Save);
            Check(File.ReadAllBytes(file.Path).SequenceEqual(changed), "Stale correction overwrote another writer's data.");
        });
    }

    private static void ExpectInvalid(Action action)
    {
        try { action(); }
        catch (InvalidDataException) { return; }
        catch (IOException) { return; }
        throw new InvalidOperationException("Unsafe correction was accepted.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class AssetFixture : IDisposable
    {
        private readonly string directory = System.IO.Path.Combine(
            Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_WORK_DIR") ?? System.IO.Path.GetTempPath(),
            "modpatch-bundle-test-" + Guid.NewGuid().ToString("N"));
        public string Path => System.IO.Path.Combine(directory, "globalgamemanagers");

        public AssetFixture(string version)
        {
            Directory.CreateDirectory(directory);
            byte[] bytes = Enumerable.Repeat((byte)0xa5, 80).ToArray();
            BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(12), version.Length);
            Encoding.ASCII.GetBytes(version).CopyTo(bytes, 16);
            File.WriteAllBytes(Path, bytes);
        }

        public void Dispose() => Directory.Delete(directory, recursive: true);
    }
}
