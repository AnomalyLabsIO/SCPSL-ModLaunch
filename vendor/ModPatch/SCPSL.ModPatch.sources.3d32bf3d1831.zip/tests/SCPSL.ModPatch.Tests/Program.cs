using Newtonsoft.Json;
using SCPSL_ModPatch;
using SCPSL_ModPatch.PatchUtils;

internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static int Main(string[] args)
    {
        if (args.Length > 0)
        {
            if (args[0] == "--package-smoke")
                return PackageSmokeTests.Run(args);
            if (args[0] == "--probe-noninteractive-worker")
                return NoninteractiveTests.RunWorkerProbe(args);
            if (args[0] == "--audit-version-readers")
                return VersionReaderAudit.Run(args);
            if (args[0] == "--bundle-version")
                return UnityBundleVersionCorrectionTests.RunFocused();
            return RealBinaryQualification.Run(args);
        }
        Run("one legacy-shaped manifest mixes offset and pattern patches", MixedManifestPatches);
        PatchTargetTests.Register(Run);
        TargetedFeedTests.Register(Run);
        OlderFeedTests.Register(Run);
        NoninteractiveTests.Register(Run);
        HeadlessCliTests.Register(Run);
        CliContractRegressionTests.Register(Run);
        NativeAliasTests.Register(Run);
        UnityBundleVersionCorrectionTests.Register(Run);
        LegacyReleaseVersionTests.Register(Run);
        ConsolidationTests.Register(Run);
        PatchInfoUpdateTests.Register(Run);
        ReleaseSafetyTests.Register(Run);
        PatchInfo manifest = JsonConvert.DeserializeObject<PatchInfo>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "legacy-patchinfo.json")))!;
        foreach (VersionRangeInfo range in manifest.versionRanges)
        {
            VersionRangeInfo captured = range;
            Run($"legacy patches execute unchanged: {range.versionFrom} through {range.versionTo}", () => ApplyLegacyRange(captured));
        }

        Run("omitted legacy patchOffset means method start", () =>
        {
            var fixture = new SyntheticPe();
            PatchMethodInfo patch = ReadPatch("{\"name\":\"Fixture.A$$Run\",\"patchData\":\"[RET]\"}");
            Check(patch.patchOffset == null, "Omitted patchOffset was unexpectedly populated.");
            ExpectWrites(fixture, new[] { patch }, (0, new byte[] { 0xC3 }));
        });
        Run("explicit legacy offset and NOP padding use raw file mapping", () =>
            ExpectWrites(new SyntheticPe(), new[] { Legacy(SyntheticPe.B, 5, "B8 01-00 00 00", 8) },
                (0x45, new byte[] { 0xB8, 1, 0, 0, 0, 0x90, 0x90, 0x90 })));
        Run("user JSON pattern omits legacy offset and pads patchSize", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(7, 0x48, 0x8B, 0x80, 0xB8, 0, 0, 0, 0x48, 0x8B, 0x48, 8, 0x8B, 1);
            var patch = ReadPatch("{\"name\":\"Fixture.A$$Run\",\"patchPattern\":\"48 8B 80 B8 00 00 00 48 8B 48 08 8B 01\",\"patchData\":\"B8 01 00 00 00\",\"patchSize\":13}");
            Check(patch.patchOffset == null, "Pattern JSON acquired a legacy offset.");
            byte[] replacement = Enumerable.Repeat((byte)0x90, 13).ToArray();
            new byte[] { 0xB8, 1, 0, 0, 0 }.CopyTo(replacement, 0);
            ExpectWrites(fixture, new[] { patch }, (7, replacement));
        });
        Run("unique method match ignores identical neighboring bytes", () =>
        {
            var fixture = WithPattern();
            fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (4, new byte[] { 0xC3 }));
        });
        Run("wildcards and separated or compact hex reach actual patcher", () =>
        {
            var fixture = WithPattern();
            ExpectWrites(fixture, new[] { Pattern(pattern: "de-?\tBE??") }, (4, new byte[] { 0xC3 }));
        });
        Run("pattern at final legal method position is found", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(0x3C, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (0x3C, new byte[] { 0xC3 }));
        });
        Run("pattern may begin at method start", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(0, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (0, new byte[] { 0xC3 }));
        });
        Run("missing local pattern rejects a match in neighboring method", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "not found", Pattern());
        });
        Run("multiple local matches reject ambiguous location", () =>
        {
            var fixture = WithPattern();
            fixture.Put(0x14, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "more than once", Pattern());
        });
        Run("overlapping pattern matches reject ambiguous location", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(4, 0xAA, 0xAA, 0xAA);
            RejectUnchanged(fixture, "more than once", Pattern(pattern: "AA AA"));
        });
        Run("pattern longer than method is absent", () =>
            RejectUnchanged(new SyntheticPe(), "not found", Pattern(pattern: string.Concat(Enumerable.Repeat("CC", 65)))));
        Run("pattern cannot straddle adjacent methods", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Put(0x3E, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "not found", Pattern());
        });

        Run("positive patternOffset applies from matched bytes", () =>
            ExpectWrites(WithPattern(), new[] { Pattern(patternOffset: 2) }, (6, new byte[] { 0xC3 })));
        Run("negative patternOffset remains inside method", () =>
            ExpectWrites(WithPattern(), new[] { Pattern(patternOffset: -2) }, (2, new byte[] { 0xC3 })));
        Run("negative patternOffset outside method rejects", () =>
            RejectUnchanged(WithPattern(), "outside the matched native method", Pattern(patternOffset: -5)));
        Run("patternOffset and patch size cannot cross method end", () =>
            RejectUnchanged(WithPattern(), "outside the matched native method", Pattern(patternOffset: 59, size: 2)));
        Run("patternOffset checked arithmetic rejects overflow", () =>
            RejectUnchanged(WithPattern(), "overflow", Pattern(patternOffset: int.MaxValue)));
        Run("patternOffset requires pattern", () =>
        {
            var patch = Legacy(SyntheticPe.A, 0, "C3");
            patch.patternOffset = 1;
            RejectUnchanged(new SyntheticPe(), "requires patchPattern", patch);
        });
        Run("pattern and explicit patchOffset zero are incompatible", () =>
        {
            var patch = Pattern();
            patch.patchOffset = 0;
            RejectUnchanged(WithPattern(), "either patchPattern or patchOffset", patch);
        });
        Run("truncating pattern patchSize rejects data loss", () =>
            RejectUnchanged(WithPattern(), "at least its data length", Pattern(data: "B801000000", size: 4)));
        Run("truncating legacy patchSize rejects data loss", () =>
            RejectUnchanged(new SyntheticPe(), "at least its data length", Legacy(SyntheticPe.A, 0, "B801000000", 4)));
        Run("zero patchSize rejects", () =>
            RejectUnchanged(WithPattern(), "at least its data length", Pattern(size: 0)));
        Run("negative patchSize rejects", () =>
            RejectUnchanged(WithPattern(), "at least its data length", Pattern(size: -1)));
        Run("empty replacement data rejects", () =>
            RejectUnchanged(WithPattern(), "nonempty data", Pattern(data: "")));
        Run("malformed replacement hex rejects", () =>
            RejectUnchanged(WithPattern(), "aren't valid", Pattern(data: "Q0")));
        Run("legacy negative offset rejects", () =>
            RejectUnchanged(new SyntheticPe(), "cannot be negative", Legacy(SyntheticPe.A, -1, "C3")));
        Run("legacy offset checked arithmetic rejects overflow", () =>
            RejectUnchanged(new SyntheticPe(), "overflow", Legacy(SyntheticPe.A, int.MaxValue, "C3")));
        Run("legacy write beyond binary rejects", () =>
            RejectUnchanged(new SyntheticPe(), "outside the binary", Legacy(SyntheticPe.A, SyntheticPe.PdataRaw + 0x200, "C3")));
        Run("unmapped PE method RVA rejects instead of patching DOS header", () =>
        {
            var fixture = new SyntheticPe(new SyntheticPe.Method(SyntheticPe.A, 0, 0x40, AddressOverride: 0x7000));
            RejectUnchanged(fixture, "does not map to the PE image", Legacy(SyntheticPe.A, 0, "C3"));
        });
        Run("overlapping legacy and pattern writes reject atomically", () =>
            RejectUnchanged(WithPattern(), "overlaps patch", Legacy(SyntheticPe.A, 3, "B801", 3), Pattern()));
        Run("adjacent patch writes are allowed", () =>
            ExpectWrites(WithPattern(), new[] { Legacy(SyntheticPe.A, 3, "90"), Pattern() }, (3, new byte[] { 0x90, 0xC3 })));
        Run("later missing pattern preserves earlier valid patch bytes", () =>
            RejectUnchanged(WithPattern(), "not found", Legacy(SyntheticPe.B, 1, "C3"), Pattern(pattern: "12 34 56")));
        Run("all patterns inspect original image before any writes", () =>
        {
            var fixture = WithPattern();
            fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern(), Pattern(name: SyntheticPe.B) },
                (4, new byte[] { 0xC3 }), (0x44, new byte[] { 0xC3 }));
        });
        Run("duplicate method names with distinct native addresses reject", () =>
        {
            var fixture = new SyntheticPe(new(SyntheticPe.A, 0, 0x40), new(SyntheticPe.A, 0x40, 0x40));
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "more than one native address", Pattern());
        });
        Run("duplicate method names sharing one native address are accepted", () =>
        {
            var fixture = new SyntheticPe(new(SyntheticPe.A, 0, 0x40), new(SyntheticPe.A, 0, 0x40));
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (4, new byte[] { 0xC3 }));
        });
        Run("required missing pattern method throws without modal UI", () =>
            RejectUnchanged(WithPattern(), "Couldn't find", Pattern(name: "Fixture.Missing$$Run")));
        Run("nowarning permits missing optional pattern and legacy methods", () =>
        {
            var fixture = WithPattern();
            var optionalPattern = Pattern(name: "Fixture.Missing$$Run");
            optionalPattern.nowarning = true;
            var optionalLegacy = Legacy("Fixture.OtherMissing$$Run", 0, "C3");
            optionalLegacy.nowarning = true;
            ExpectWrites(fixture, new[] { optionalPattern, optionalLegacy, Pattern() }, (4, new byte[] { 0xC3 }));
        });
        Run("patchifnotexists skips pattern when named method exists", () =>
        {
            var patch = Pattern(pattern: "invalid pattern");
            patch.patchifnotexists = SyntheticPe.B;
            ExpectWrites(WithPattern(), new[] { patch });
        });
        Run("patchifnotexists runs pattern when named method is absent", () =>
        {
            var patch = Pattern();
            patch.patchifnotexists = "Fixture.Missing$$Run";
            ExpectWrites(WithPattern(), new[] { patch }, (4, new byte[] { 0xC3 }));
        });

        foreach (string malformed in new[] { "", " \t-\r\n", "A", "A G0", "0G", "A?", "?A", "AA?", "??", "? ?", "????" })
        {
            string captured = malformed;
            Run($"invalid pattern rejected: {JsonConvert.SerializeObject(captured)}", () =>
                RejectUnchanged(WithPattern(), null, Pattern(pattern: captured)));
        }
        Run("null parser argument rejects", () => Throws<ArgumentNullException>(() => BytePattern.Parse(null!)));

        NativeMapTests();
        ChainedUnwindTests();
        Console.WriteLine($"{_passed} passed, {_failed} failed. Offline checks only; no game was launched.");
        return _failed == 0 ? 0 : 1;
    }

    private static void ChainedUnwindTests()
    {
        Run("chained unwind group includes later native fragments", () =>
        {
            var fixture = ChainedFixture();
            fixture.Put(0x84, 0xDE, 0xAD, 0xBE, 0xEF);
            NativeMethodRange range = new NativeMethodMap(fixture.Image).GetMethodRange(SyntheticPe.TextRaw);
            Check(range.Length == 0xC0, "Chained method omitted a fragment.");
            ExpectWrites(fixture, new[] { Pattern() }, (0x84, new byte[] { 0xC3 }));
        });
        Run("recursive chained unwind links resolve to one method root", () =>
        {
            var fixture = ChainedFixture(recursive: true);
            fixture.Put(0x84, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (0x84, new byte[] { 0xC3 }));
        });
        Run("chained unwind trailer follows aligned odd code count", () =>
        {
            var fixture = ChainedFixture(recursive: true);
            fixture.Chain(2, 1, oddCodeCount: true);
            fixture.Put(0x84, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (0x84, new byte[] { 0xC3 }));
        });
        Run("pattern may span contiguous fragments in one chained method", () =>
        {
            var fixture = ChainedFixture();
            fixture.Put(0x3E, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern(data: "01 02 03 04", size: 4) }, (0x3E, new byte[] { 1, 2, 3, 4 }));
        });
        Run("chained search counts duplicate root and fragment matches", () =>
        {
            var fixture = ChainedFixture();
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            fixture.Put(0x84, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "more than once", Pattern());
        });
        Run("chained method search excludes unrelated adjacent root", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Chain(1, 0);
            fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
            fixture.Put(0x84, 0xDE, 0xAD, 0xBE, 0xEF);
            ExpectWrites(fixture, new[] { Pattern() }, (0x44, new byte[] { 0xC3 }));
        });
        Run("pattern cannot straddle chained group and unrelated root", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Chain(1, 0);
            fixture.Put(0x7E, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, "not found", Pattern());
        });
        Run("chained fragment start cannot impersonate method root", () =>
        {
            var fixture = ChainedFixture();
            fixture.Put(0x44, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, null, Pattern(name: SyntheticPe.B));
        });
        Run("cyclic chained unwind links reject atomically", () =>
        {
            var fixture = ChainedFixture();
            fixture.Chain(0, 1);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("self-referential chained unwind link rejects atomically", () =>
        {
            var fixture = ChainedFixture();
            fixture.Chain(0, 0);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("chain link requires exact recorded parent range", () =>
        {
            var fixture = ChainedFixture();
            fixture.Write32(SyntheticPe.UnwindInfoRaw(1) + 4, SyntheticPe.TextRva + 1);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("chain link requires exact recorded parent unwind pointer", () =>
        {
            var fixture = ChainedFixture();
            fixture.Write32(SyntheticPe.UnwindInfoRaw(1) + 12, SyntheticPe.UnwindInfoRva(0) + 4);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("chained fragments separated by a native byte gap reject", () =>
        {
            var fixture = new SyntheticPe(new(SyntheticPe.A, 0, 0x20), new(SyntheticPe.B, 0x40, 0x20));
            fixture.Chain(1, 0);
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("chained group cannot absorb an unrelated method between fragments", () =>
        {
            var fixture = new SyntheticPe();
            fixture.Chain(2, 0);
            fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("CHAININFO and handler flags cannot be combined", () =>
        {
            var fixture = ChainedFixture();
            fixture.Image[SyntheticPe.UnwindInfoRaw(1)] = 0x29;
            RejectUnchanged(fixture, null, Pattern());
        });
        Run("missing unwind info pointer rejects pattern method bounds", () =>
        {
            var fixture = WithPattern();
            fixture.Write32(SyntheticPe.PdataRaw + 8, 0);
            RejectUnchanged(fixture, null, Pattern());
        });
    }

    private static SyntheticPe ChainedFixture(bool recursive = false)
    {
        var fixture = new SyntheticPe();
        fixture.Chain(1, 0);
        fixture.Chain(2, recursive ? 1 : 0);
        return fixture;
    }

    private static void NativeMapTests()
    {
        Run("native method map uses exact file-backed function ranges", () =>
        {
            var fixture = new SyntheticPe();
            var map = new NativeMethodMap(fixture.Image);
            NativeMethodRange range = map.GetMethodRange(SyntheticPe.TextRaw + 0x40);
            Check(range.Offset == SyntheticPe.TextRaw + 0x40 && range.Length == 0x40, "Wrong .pdata extent.");
            Throws<InvalidDataException>(() => map.GetMethodRange(SyntheticPe.TextRaw + 1));
        });
        Run("exception directory and unwind data may be in executable section", () =>
        {
            var fixture = WithPattern();
            fixture.Write32(SyntheticPe.SectionHeaders + 40 + 36, unchecked((int)0x60000040));
            NativeMethodRange bounds = new NativeMethodMap(fixture.Image).GetMethodRange(SyntheticPe.TextRaw);
            Check(bounds.Length == 0x40, "Executable unwind data changed method bounds.");
            ExpectWrites(fixture, new[] { Pattern() }, (4, new byte[] { 0xC3 }));
        });
        MapReject("missing exception directory", fixture => fixture.Write32(SyntheticPe.OptionalHeader + 112 + 3 * 8, 0));
        MapReject("incomplete runtime function entry", fixture => fixture.Write32(SyntheticPe.OptionalHeader + 112 + 3 * 8 + 4, 13));
        MapReject("reversed runtime function range", fixture => fixture.Write32(SyntheticPe.PdataRaw + 4, SyntheticPe.TextRva - 1));
        MapReject("unsorted runtime function entries", fixture => fixture.Write32(SyntheticPe.PdataRaw + 12, SyntheticPe.TextRva - 1));
        MapReject("duplicate runtime function starts", fixture => fixture.Write32(SyntheticPe.PdataRaw + 12, SyntheticPe.TextRva));
        MapReject("overlapping runtime functions", fixture => fixture.Write32(SyntheticPe.PdataRaw + 4, SyntheticPe.TextRva + 0x41));
        MapReject("function in nonexecutable section", fixture =>
        {
            fixture.Write32(SyntheticPe.PdataRaw, SyntheticPe.PdataRva);
            fixture.Write32(SyntheticPe.PdataRaw + 4, SyntheticPe.PdataRva + 0x10);
        });
        MapReject("function lacks file backing", fixture =>
        {
            fixture.Write32(SyntheticPe.SectionHeaders + 16, 0x200);
            fixture.Write32(SyntheticPe.PdataRaw + 24, SyntheticPe.TextRva + 0x300);
            fixture.Write32(SyntheticPe.PdataRaw + 28, SyntheticPe.TextRva + 0x340);
        });
        MapReject("overlapping PE raw sections", fixture => fixture.Write32(SyntheticPe.SectionHeaders + 40 + 20, SyntheticPe.TextRaw));
        MapReject("overlapping PE virtual sections", fixture => fixture.Write32(SyntheticPe.SectionHeaders + 40 + 12, SyntheticPe.TextRva));
        MapReject("section extends beyond file", fixture => fixture.Write32(SyntheticPe.SectionHeaders + 16, fixture.Image.Length));
        Run("unsupported PE architecture rejects pattern patching", () =>
        {
            var fixture = WithPattern();
            fixture.Write16(0x84, 0x14C);
            RejectUnchanged(fixture, "AMD64", Pattern());
        });
        Run("leaf method without exact unwind entry rejects pattern patch", () =>
        {
            var fixture = WithPattern();
            fixture.Write32(SyntheticPe.PdataRaw, SyntheticPe.TextRva + 1);
            RejectUnchanged(fixture, "No exact PE runtime function entry", Pattern());
        });
    }

    private static void MapReject(string description, Action<SyntheticPe> corrupt) => Run($"malformed PE rejects: {description}", () =>
    {
        var fixture = WithPattern();
        corrupt(fixture);
        RejectUnchanged(fixture, null, Pattern());
    });

    private static void MixedManifestPatches()
    {
        const string json = @"{
          ""versionRanges"": [{
            ""versionFrom"": ""14.1.0"", ""versionTo"": ""Current"", ""metadataVersion"": 31,
            ""methods"": { ""patchMethods"": [
              { ""name"": ""Fixture.A$$Run"", ""patchOffset"": 5, ""patchData"": ""[RET]"", ""patchSize"": 2 },
              { ""name"": ""Fixture.B$$Run"", ""patchPattern"": ""DE AD ?? EF"", ""patternOffset"": 2,
                ""patchData"": ""33 C0"", ""patchSize"": 3 },
              { ""name"": ""Fixture.C$$Run"", ""patchData"": ""[RET]"" }
            ] }
          }]
        }";
        PatchInfo manifest = JsonConvert.DeserializeObject<PatchInfo>(json)!;
        var fixture = new SyntheticPe();
        fixture.Put(0x48, 0xDE, 0xAD, 0xBE, 0xEF);
        VersionRangeInfo selected = PatchTargetResolver.Resolve(manifest,
            PatchTargetResolver.ComputeSha256(fixture.Image), new Version(14, 2, 8));
        PatchMethodInfo[] patches = selected.methods.patchMethods;
        Check(patches.Length == 3 && patches[0].patchOffset == 5 && patches[0].patchPattern == null &&
            patches[1].patchOffset == null && patches[1].patchPattern == "DE AD ?? EF" && patches[1].patternOffset == 2 &&
            patches[2].patchOffset == null && patches[2].patchPattern == null,
            "A mixed manifest changed a patch location or populated an omitted field.");
        ExpectWrites(fixture, patches, (5, new byte[] { 0xC3, 0x90 }),
            (0x4A, new byte[] { 0x33, 0xC0, 0x90 }), (0x80, new byte[] { 0xC3 }));
    }

    private static void ApplyLegacyRange(VersionRangeInfo range)
    {
        string[] names = range.methods.patchMethods.Select(patch => patch.name).Distinct().ToArray();
        var fixture = new SyntheticPe(names.Select((name, index) => new SyntheticPe.Method(name, index * 0x800, 0x800)).ToArray());
        byte[] expected = (byte[])fixture.Image.Clone();
        foreach (PatchMethodInfo patch in range.methods.patchMethods)
        {
            if (!string.IsNullOrEmpty(patch.patchifnotexists) && names.Contains(patch.patchifnotexists))
                continue;
            byte[] data = Convert.FromHexString(patch.patchData.Replace("[RET]", "C3").Replace("[NOP]", "90").Replace(" ", "").Replace("-", ""));
            int size = patch.patchSize ?? data.Length;
            int offset = SyntheticPe.TextRaw + Array.IndexOf(names, patch.name) * 0x800 + (patch.patchOffset ?? 0);
            expected.AsSpan(offset, size).Fill(0x90);
            data.CopyTo(expected, offset);
        }
        fixture.Apply(range.methods.patchMethods);
        Check(fixture.Image.SequenceEqual(expected), "Legacy range output differs from documented offsets/replacements.");
    }

    private static SyntheticPe WithPattern()
    {
        var fixture = new SyntheticPe();
        fixture.Put(4, 0xDE, 0xAD, 0xBE, 0xEF);
        return fixture;
    }

    private static PatchMethodInfo ReadPatch(string json) =>
        JsonConvert.DeserializeObject<PatchMethodInfo>(json)!;

    private static PatchMethodInfo Legacy(string name, int offset, string data, int? size = null) =>
        new() { name = name, patchOffset = offset, patchData = data, patchSize = size };

    private static PatchMethodInfo Pattern(string name = SyntheticPe.A, string pattern = "DE AD BE EF", string data = "C3", int? size = null, int patternOffset = 0) =>
        new() { name = name, patchPattern = pattern, patchData = data, patchSize = size, patternOffset = patternOffset };

    private static void ExpectWrites(SyntheticPe fixture, PatchMethodInfo[] patches, params (int Offset, byte[] Bytes)[] writes)
    {
        byte[] expected = (byte[])fixture.Image.Clone();
        foreach (var write in writes)
            write.Bytes.CopyTo(expected, SyntheticPe.TextRaw + write.Offset);
        fixture.Apply(patches);
        Check(fixture.Image.SequenceEqual(expected), "Bytes outside the expected replacement changed, or replacement was incorrect.");
    }

    private static void RejectUnchanged(SyntheticPe fixture, string? message, params PatchMethodInfo[] patches)
    {
        byte[] before = (byte[])fixture.Image.Clone();
        InvalidDataException exception = Throws<InvalidDataException>(() => fixture.Apply(patches));
        if (message != null)
            Check(exception.ToString().Contains(message, StringComparison.OrdinalIgnoreCase), $"Expected error containing '{message}', got: {exception.Message}");
        Check(fixture.Image.SequenceEqual(before), "Rejected patch modified the caller's image.");
    }

    private static T Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T exception) { return exception; }
        throw new Exception($"Expected {typeof(T).Name}.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }

    private static void Run(string name, Action test)
    {
        string? filter = Environment.GetEnvironmentVariable("SCPSL_MODPATCH_TEST_FILTER");
        if (!string.IsNullOrEmpty(filter) && !name.Contains(filter, StringComparison.OrdinalIgnoreCase)) return;
        try
        {
            test();
            _passed++;
            Console.WriteLine($"PASS {name}");
        }
        catch (Exception exception)
        {
            _failed++;
            Console.WriteLine($"FAIL {name}: {exception}");
        }
    }
}
