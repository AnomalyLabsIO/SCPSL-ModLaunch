#Requires -Version 7.0
# The GUI and CLI now share one executable and the same two release packages.
[CmdletBinding()]
param(
    [string]$NuGetSource,
    [string]$SourceRevision,
    [string]$DotNet = 'dotnet',
    [string]$OutputDirectory,
    [ValidateSet('Both', 'Standalone', 'Compatibility')]
    [string]$Package = 'Both',
    [string]$StandaloneRuntimeVersion = '10.0.13',
    [string]$CompatibilityRuntimeVersion = '6.0.36'
)

& (Join-Path $PSScriptRoot 'package.ps1') @PSBoundParameters
