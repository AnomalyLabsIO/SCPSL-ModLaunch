#Requires -Version 7.0
[CmdletBinding()]
param(
    [string]$NuGetSource,
    [string]$SourceRevision,
    [string]$DotNet = 'dotnet',
    [string]$OutputDirectory,
    [ValidateSet('Both', 'Standalone', 'Compatibility')]
    [string]$Package = 'Both',
    [ValidatePattern('^10\.0\.[0-9]+$')]
    [string]$StandaloneRuntimeVersion = '10.0.13',
    [ValidatePattern('^6\.0\.[0-9]+$')]
    [string]$CompatibilityRuntimeVersion = '6.0.36'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $repoRoot 'artifacts/release' }
$output = [IO.Path]::GetFullPath($OutputDirectory)
$stage = Join-Path $repoRoot ('artifacts/package/' + [guid]::NewGuid().ToString('N'))

$sdkVersion = & $DotNet --version
if ($LASTEXITCODE -ne 0 -or $sdkVersion -notmatch '^([0-9]+)\.' -or [int]$Matches[1] -lt 10) {
    throw 'Release packaging requires a .NET 10 SDK or newer. Select it with -DotNet.'
}

$sourceDirty = $null
$git = Get-Command git -ErrorAction SilentlyContinue
if ($git -and (Test-Path -LiteralPath (Join-Path $repoRoot '.git'))) {
    $head = & $git.Source -C $repoRoot rev-parse HEAD
    if ($LASTEXITCODE -ne 0) { throw 'Could not read the source revision.' }
    $head = $head.Trim()
    if ($SourceRevision -and $SourceRevision -ine $head) {
        throw 'SourceRevision must match this checkout HEAD; working tree changes are recorded separately.'
    }
    $SourceRevision = $head
    $status = @(& $git.Source -C $repoRoot status --porcelain --untracked-files=normal)
    if ($LASTEXITCODE -ne 0) { throw 'Could not read the source working tree status.' }
    $sourceDirty = $status.Count -ne 0
}
if ($SourceRevision -cnotmatch '^[0-9a-fA-F]{40}$') {
    throw 'Supply a full Git commit hash with -SourceRevision when building an exported source archive.'
}

function Write-Archive([string]$Root, [string[]]$Files, [string]$Destination) {
    $stream = [IO.File]::Open($Destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $zip = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $true)
        try {
            foreach ($file in ($Files | Sort-Object)) {
                $relative = [IO.Path]::GetRelativePath($Root, $file).Replace('\', '/')
                if ([IO.Path]::IsPathRooted($relative) -or $relative -eq '..' -or $relative.StartsWith('../')) {
                    throw 'Archive input escaped source root.'
                }
                $entry = $zip.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = [DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
                $input = [IO.File]::OpenRead($file)
                $target = $entry.Open()
                try { $input.CopyTo($target) }
                finally { $target.Dispose(); $input.Dispose() }
            }
        }
        finally { $zip.Dispose() }
    }
    finally { $stream.Dispose() }
}

function Write-Sha256([string]$Path) {
    $hash = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText(($Path + '.sha256'), "$hash  $([IO.Path]::GetFileName($Path))`n", [Text.UTF8Encoding]::new($false))
}

function Copy-PackageNotices([string]$PackagePath, [string[]]$PackageFolders, [string]$Destination) {
    $packageRoot = $null
    foreach ($folder in $PackageFolders) {
        $candidate = Join-Path $folder $PackagePath
        if (Test-Path -LiteralPath $candidate -PathType Container) {
            $packageRoot = [IO.Path]::GetFullPath($candidate)
            break
        }
    }
    if (-not $packageRoot) { throw "Cannot find restored package $PackagePath to collect its licenses." }

    $notices = @(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | Where-Object {
        $_.Name -match '^(licen[cs]e|copying|copyright|.*notices?|.*eula)([._ -]|$)'
    } | Select-Object -ExpandProperty FullName)
    # A package can declare a license file whose name does not follow a common convention.
    $nuspec = @(Get-ChildItem -LiteralPath $packageRoot -File -Filter '*.nuspec')
    if ($nuspec.Count -ne 1) { throw "Package $PackagePath has no unique NuGet manifest." }
    [xml]$metadata = Get-Content -LiteralPath $nuspec[0].FullName -Raw
    foreach ($license in $metadata.SelectNodes('//*[local-name()="license" and @type="file"]')) {
        $notices += [IO.Path]::GetFullPath((Join-Path $packageRoot $license.InnerText))
    }
    if ($notices.Count -eq 0) { throw "Package $PackagePath has no license text; add its upstream notices before packaging." }
    foreach ($notice in ($notices | Sort-Object -Unique)) {
        $relative = [IO.Path]::GetRelativePath($packageRoot, $notice)
        if ([IO.Path]::IsPathRooted($relative) -or $relative -eq '..' -or $relative.StartsWith('..' + [IO.Path]::DirectorySeparatorChar)) {
            throw "License file escaped restored package $PackagePath."
        }
        $target = Join-Path $Destination $relative
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
        Copy-Item -LiteralPath $notice -Destination $target
    }
}

function Copy-ReleaseLicenses([string]$BinaryStage, [string]$BuildStage, [string]$AssetsPath) {
    Copy-Item -LiteralPath (Join-Path $repoRoot 'licenses') -Destination $BinaryStage -Recurse
    $licenseRoot = Join-Path $BinaryStage 'licenses'
    $projectLicense = Join-Path $licenseRoot 'SCPSL-ModPatch'
    New-Item -ItemType Directory -Path $projectLicense -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $repoRoot 'LICENSE') -Destination (Join-Path $projectLicense 'LICENSE.txt')

    $dependencyFiles = @(Get-ChildItem -LiteralPath $BuildStage -Recurse -File -Filter 'SCPSL ModPatch.deps.json')
    if ($dependencyFiles.Count -ne 1) { throw 'The published dependency manifest was not uniquely produced.' }
    $dependencies = Get-Content -LiteralPath $dependencyFiles[0].FullName -Raw | ConvertFrom-Json -AsHashtable
    $assets = Get-Content -LiteralPath $AssetsPath -Raw | ConvertFrom-Json -AsHashtable
    foreach ($library in ($dependencies.libraries.GetEnumerator() | Sort-Object Key)) {
        switch ($library.Value.type) {
            'package' {
                Copy-PackageNotices $library.Value.path @($assets.packageFolders.Keys) (Join-Path $licenseRoot ('NuGet/' + $library.Key))
            }
            'runtimepack' {
                $package = $library.Key -replace '^runtimepack\.', ''
                Copy-PackageNotices $package.ToLowerInvariant() @($assets.packageFolders.Keys) (Join-Path $licenseRoot ('runtime/' + $package))
            }
            'reference' {
                $name = $library.Key.Split('/')[0]
                if (-not (Test-Path -LiteralPath (Join-Path $licenseRoot "$name/LICENSE.txt") -PathType Leaf)) {
                    throw "Vendored dependency $name needs a license in licenses/$name/LICENSE.txt."
                }
            }
        }
    }
}

function Get-SourceFiles {
    foreach ($folder in @('SCPSL ModPatch', 'Shared_Files', 'tests', 'scripts', 'tools', 'docs', 'licenses')) {
        $folderPath = Join-Path $repoRoot $folder
        if (Test-Path -LiteralPath $folderPath) {
            Get-ChildItem -LiteralPath $folderPath -Recurse -File |
                Where-Object { $_.FullName -notmatch '[\\/](bin|obj|artifacts|Build_Binaries|__pycache__|\.idea)[\\/]' -and $_.Name -notmatch '\.(user|suo|pyc|pyo)$' } |
                Select-Object -ExpandProperty FullName
        }
    }
    foreach ($name in @('LICENSE', 'README.md', 'SCPSL ModPatch.sln', '.gitignore', '.gitattributes', 'global.json')) {
        $file = Join-Path $repoRoot $name
        if (Test-Path -LiteralPath $file) { $file }
    }
}

New-Item -ItemType Directory -Path $stage -Force | Out-Null
# Snapshot the actual build inputs, including local changes; omit generated output and IDE state.
$sourceFiles = @(Get-SourceFiles)
$sourceHashes = @{}
foreach ($file in $sourceFiles) { $sourceHashes[$file] = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash }
$sourceZip = Join-Path $stage 'SCPSL.ModPatch.sources.zip'
Write-Archive $repoRoot $sourceFiles $sourceZip
$sourceSha256 = (Get-FileHash -LiteralPath $sourceZip -Algorithm SHA256).Hash
$namedSourceZip = Join-Path $stage ("SCPSL.ModPatch.sources.$($sourceSha256.Substring(0, 12).ToLowerInvariant()).zip")
Move-Item -LiteralPath $sourceZip -Destination $namedSourceZip
$sourceZip = $namedSourceZip
Write-Sha256 $sourceZip

$releases = @(
    @{ Name = 'Standalone'; Framework = 'net10.0-windows'; RuntimeVersion = $StandaloneRuntimeVersion; SelfContained = 'true'; SingleFile = 'true'; Compress = 'true'; Archive = 'SCPSL.ModPatch.Standalone.x64.zip' },
    @{ Name = 'Compatibility'; Framework = 'net6.0-windows'; RuntimeVersion = $CompatibilityRuntimeVersion; SelfContained = 'false'; SingleFile = 'true'; Compress = 'false'; Archive = 'SCPSL.ModPatch.dotnet6.0.zip' }
)
$completed = @($sourceZip)
foreach ($release in $releases) {
    if ($Package -ne 'Both' -and $Package -ne $release.Name) { continue }
    $binaryStage = Join-Path $stage $release.Name
    # Publishing one target must not replace the IDE's multi-target restore assets.
    $intermediateStage = (Join-Path $stage ($release.Name + '-obj')).Replace('\', '/') + '/'
    $buildStage = (Join-Path $stage ($release.Name + '-bin')).Replace('\', '/') + '/'
    $publishArgs = @(
        'publish', (Join-Path $repoRoot 'SCPSL ModPatch/SCPSL ModPatch.csproj'),
        '-c', 'Release', '-f', $release.Framework, '-r', 'win-x64',
        '--self-contained', $release.SelfContained, '-o', $binaryStage,
        '-p:Platform=x64', "-p:TargetFrameworks=$($release.Framework)",
        "-p:PublishSingleFile=$($release.SingleFile)", '-p:PublishTrimmed=false',
        "-p:EnableCompressionInSingleFile=$($release.Compress)",
        '-p:DebugType=None', '-p:DebugSymbols=false', '-p:UseSharedCompilation=false',
        "-p:BaseIntermediateOutputPath=$intermediateStage", "-p:BaseOutputPath=$buildStage",
        '-p:DefaultItemExcludesInProjectFolder=**/obj/**'
    )
    if ($release.Name -eq 'Compatibility') {
        # RuntimeFrameworkVersion also overrides the SDK's ILLink tool version. For
        # net6, use the final runtime patch while retaining the SDK-selected tools.
        $publishArgs += '-p:TargetLatestRuntimePatch=true'
    }
    else { $publishArgs += "-p:RuntimeFrameworkVersion=$($release.RuntimeVersion)" }
    if ($release.SingleFile -eq 'true') { $publishArgs += '-p:IncludeNativeLibrariesForSelfExtract=true' }
    if ($NuGetSource) { $publishArgs += "-p:RestoreSources=$NuGetSource" }
    & $DotNet @publishArgs
    if ($LASTEXITCODE -ne 0) { throw "ModPatch $($release.Name) publish failed." }
    if (-not (Test-Path -LiteralPath (Join-Path $binaryStage 'SCPSL ModPatch.exe'))) {
        throw "ModPatch $($release.Name) executable was not published."
    }
    $runtimeConfigs = @(Get-ChildItem -LiteralPath $buildStage -Recurse -File -Filter 'SCPSL ModPatch.runtimeconfig.json')
    if ($runtimeConfigs.Count -ne 1) { throw "ModPatch $($release.Name) runtime configuration was not uniquely produced." }
    $runtimeOptions = (Get-Content -LiteralPath $runtimeConfigs[0].FullName -Raw | ConvertFrom-Json).runtimeOptions
    $frameworkProperty = if ($release.SelfContained -eq 'true') { 'includedFrameworks' } else { 'frameworks' }
    $frameworks = @($runtimeOptions.$frameworkProperty)
    if ($frameworks.Count -ne 2 -or @($frameworks | Where-Object { $_.version -ne $release.RuntimeVersion }).Count -ne 0) {
        throw "ModPatch $($release.Name) did not select runtime $($release.RuntimeVersion). Use an SDK providing that runtime patch."
    }
    if (@(Get-ChildItem -LiteralPath $binaryStage -File | Where-Object {
        $_.Extension -in @('.dll', '.pdb') -or $_.Name -match '\.(deps|runtimeconfig)\.json$'
    }).Count -ne 0) {
        throw "ModPatch $($release.Name) was not published as a single executable."
    }

    Copy-ReleaseLicenses $binaryStage $buildStage (Join-Path $intermediateStage 'project.assets.json')
    Copy-Item -LiteralPath (Join-Path $repoRoot 'README.md') -Destination $binaryStage
    Copy-Item -LiteralPath (Join-Path $repoRoot 'Shared_Files/patchinfo.json') -Destination $binaryStage
    Copy-Item -LiteralPath (Join-Path $repoRoot 'Shared_Files/clean_launchers') -Destination $binaryStage -Recurse

    $files = @(Get-ChildItem -LiteralPath $binaryStage -Recurse -File | Sort-Object FullName | ForEach-Object {
        [ordered]@{
            relativePath = [IO.Path]::GetRelativePath($binaryStage, $_.FullName).Replace('\', '/')
            sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
        }
    })
    $identity = [ordered]@{
        schemaVersion = 2
        sourceRepository = 'AnomalyLabsIO/SCPSL-ModPatch'
        sourceRevision = $SourceRevision
        sourceDirty = $sourceDirty
        sourceArchive = [IO.Path]::GetFileName($sourceZip)
        sourceSha256 = $sourceSha256
        sdkVersion = $sdkVersion.Trim()
        targetFramework = $release.Framework
        runtimeFrameworkVersion = $release.RuntimeVersion
        runtimeIdentifier = 'win-x64'
        selfContained = $release.SelfContained -eq 'true'
        singleFile = $release.SingleFile -eq 'true'
        compressedAssemblies = $release.Compress -eq 'true'
        entryPoint = 'SCPSL ModPatch.exe'
        modes = @('GUI', 'CLI')
        capabilities = @('bundle-version-correction')
        files = $files
    }
    [IO.File]::WriteAllText((Join-Path $binaryStage 'bundle.json'), ($identity | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    $binaryZip = Join-Path $stage $release.Archive
    Write-Archive $binaryStage @(Get-ChildItem -LiteralPath $binaryStage -Recurse -File | Select-Object -ExpandProperty FullName) $binaryZip
    Write-Sha256 $binaryZip
    $completed += $binaryZip
}

# Avoid attributing binaries to a snapshot changed while the compiler was running.
$currentSourceFiles = @(Get-SourceFiles)
if ($currentSourceFiles.Count -ne $sourceFiles.Count) { throw 'Source files changed during packaging; rerun with a stable working tree.' }
foreach ($file in $currentSourceFiles) {
    if (-not $sourceHashes.ContainsKey($file) -or $sourceHashes[$file] -ne (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash) {
        throw 'Source files changed during packaging; rerun with a stable working tree.'
    }
}

# Publish completed archives only after every selected build succeeds.
New-Item -ItemType Directory -Path $output -Force | Out-Null
foreach ($archive in $completed) {
    Copy-Item -LiteralPath $archive, ($archive + '.sha256') -Destination $output -Force
}
Write-Host "Release packages: $output"
