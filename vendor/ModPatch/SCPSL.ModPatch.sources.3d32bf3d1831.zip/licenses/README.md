# Licenses and notices

Release archives collect license texts and notices in this directory:

- `SCPSL-ModPatch/LICENSE.txt`: copied from the repository's root `LICENSE`.
- `Il2CppDumper/LICENSE.txt`: [upstream license](https://github.com/Perfare/Il2CppDumper/blob/master/LICENSE) for the vendored Il2CppDumper DLL.
- `Mono.Cecil/LICENSE.txt`: [upstream license](https://github.com/jbevain/cecil/blob/master/LICENSE.txt) for the vendored Mono.Cecil DLLs.
- `Unity/NOTICE.txt`: attribution and software-terms link for the bundled clean Unity launchers.
- `NuGet/<package>/<version>/`: license texts, EULAs, and third-party notices copied verbatim from each shipped NuGet dependency's restored package, including transitive dependencies.
- `runtime/<package>/<version>/`: notices from the .NET runtime packs embedded in the standalone executable. The framework-dependent package does not redistribute these runtimes.

Unlicense and optional FASM executables are supplied separately by the user and are not included in the release archives.
